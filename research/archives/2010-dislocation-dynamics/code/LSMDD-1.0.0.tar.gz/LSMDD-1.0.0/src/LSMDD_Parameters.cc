/*
 * File:        LSMDD_Parameters.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Implementation file for the LSMDD_Parameters class
 */


#include "LSMDD_Parameters.h"

/*
 * Default values for user-defined parameters
 */
#define LSMDD_DEFAULT_MIN_DISLOCATION_SEGMENT        (1.0e-8)
#define LSMDD_DEFAULT_MAX_ANGLE_FOR_PURE_SCREW       (0.1)


namespace LSMDD {


/* Constructor */
LSMDD_Parameters::LSMDD_Parameters(
  Pointer<Database> input_db)
{
  initializeParametersFromDatabase(input_db);
}


/* initializeParametersFromDatabase */
void LSMDD_Parameters::initializeParametersFromDatabase(
  Pointer<Database> database)
{
  // get shear modulus and poisson ratio
  d_shear_modulus = database->getDouble("shear_modulus");
  d_poisson_ratio = database->getDouble("poisson_ratio");

  // get glide and climb mobilities
  d_glide_mobility = database->getDouble("glide_mobility");
  d_climb_mobility = database->getDouble("climb_mobility");

  // get dislocation core radius
  d_core_radius = database->getDouble("core_radius");

  // get minimum dislocation segment length for considering two endpoints 
  // of a dislocation line segment as numerically distinct
  d_min_dislocation_segment_length = database->getDoubleWithDefault(
    "min_dislocation_segment_length",
    LSMDD_DEFAULT_MIN_DISLOCATION_SEGMENT);

  // get maximum angle between the Burgers vector and tangent vector in 
  // order to consider a dislocation line segment to have pure screw
  // character
  d_max_angle_for_pure_screw = database->getDoubleWithDefault(
    "max_angle_for_pure_screw",
    LSMDD_DEFAULT_MAX_ANGLE_FOR_PURE_SCREW);

  // get debug flag
  d_lsmdd_debug_on = database->getBoolWithDefault("debug_on", false);
}


/* printClassData() */
void LSMDD_Parameters::printClassData(ostream& os) const
{
  os << "LSMDD_Parameters" << endl;
  os << "----------------" << endl;
  os << "d_shear_modulus = " << d_shear_modulus << endl;
  os << "d_poisson_ratio = " << d_poisson_ratio << endl;
  os << "d_glide_mobility = " << d_glide_mobility << endl;
  os << "d_climb_mobility = " << d_climb_mobility << endl;
  os << "d_core_radius = " << d_core_radius << endl;
  os << "d_min_dislocation_segment_length = " 
     << d_min_dislocation_segment_length << endl;
  os << "d_max_angle_for_pure_screw = " 
     << d_max_angle_for_pure_screw << endl;
  os << "d_lsmdd_debug_on = " <<
     ((d_lsmdd_debug_on) ?  "TRUE" : "FALSE") << endl;

}


} // end LSMDD namespace
