/*
 * File:        PeriodicDislocationArrayElasticStressModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Header file for the 
 *              PeriodicDislocationArrayElasticStressModule class
 */

#ifndef included_PeriodicDislocationArrayElasticStressModule_h
#define included_PeriodicDislocationArrayElasticStressModule_h

/*! \class LSMDD::PeriodicDislocationArrayElasticStressModule
 *
 * \brief
 * The PeriodicDislocationArrayElasticStressModule class provides 
 * functionality to compute the elastic stress field due to periodic 
 * arrays of dislocation lines.  The elastic stress field is computed 
 * using the Fourier transform technique discussed in Xiang et. al. (2003).
 *
 *
 * <h3> User-specified parameters (input database field) </h3>
 *
 * When using the PeriodicDislocationArrayElasticStressModule, it is 
 * possible to modify the behavior of the module through an input file.  
 * The input data parameters available for the user are described below.
 *
 * <h4> 
 *   PeriodicDislocationArrayElasticStressModule Input Database Parameters 
 * </h4>
 *
 * - conserve_memory               = flag to indicate whether or not
 *                                   memory should be conserved when
 *                                   compute elastic stress field due
 *                                   to dislocations; memory usage is
 *                                   traded-off with computation time.
 *                                   (default = FALSE)
 * - use_dynamic_memory_allocation = flag to indicate whether or not
 *                                   dynamic memory allocation should
 *                                   be used (default = TRUE)
 *
 * <h4> Sample Input File </h4>
 *
 *  <pre>
 *  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *
 *  PeriodicDislocationArrayElasticStressModule {
 *    conserve_memory = TRUE
 *    use_dynamic_memory_allocation = FALSE
 *  }
 *
 *  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *  </pre>
 *
 *
 * <h3> NOTES </h3>
 *
 *  - this class depends on the parallel FFT software written by 
 *    S. Plimpton and on the parallel version of FFTW.
 * 
 * 
 * <h3> USAGE </h3>
 *
 *
 */

// MPI Headers
#include "mpi.h"

// System Headers
#include <string>
#include <ostream>
#include <vector>

// FFTW Headers
extern "C" {
  #include "fft_3d.h"
}

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "Patch.h"
#include "PatchHierarchy.h"
#include "Box.h"
#include "tbox/Database.h"
#include "tbox/Pointer.h"

// LSMDD Headers
#include "LSMDD_config.h"
#include "LSMDD_Types.h"
#include "BurgersVector.h"
#include "LSMDD_Parameters.h"
#include "ElasticStressStrategy.h"

// namespaces
using namespace std;
using namespace SAMRAI;
using namespace hier;
using namespace tbox;


/******************************************************************
 *
 * PeriodicDislocationArrayElasticStressModule Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class PeriodicDislocationArrayElasticStressModule:
  public ElasticStressStrategy
{
public:

  //! @{
  /*!
   ****************************************************************
   *    
   * @name Constructor and destructor
   *    
   ****************************************************************/ 
  
  /*!
   * The constructor for the PeriodicDislocationArrayElasticStressModule 
   * sets up the elastic stress calculation using parameters read from the
   * input database.
   * 
   * Arguments:  
   *  - input_db (in):         input database containing user-defined 
   *                           parameters 
   *  - patch_hierarchy (in):  PatchHierarchy for computation
   *
   */
  PeriodicDislocationArrayElasticStressModule(
    Pointer<Database> input_db,
    Pointer< PatchHierarchy<3> > patch_hierarchy);

  /*!
   * The destructor for PeriodicDislocationArrayElasticStressModule frees 
   * memory used to store the stress field, the FFT data, and the plan 
   * used by S. Plimpton's parallel FFT software.
   */
  virtual ~PeriodicDislocationArrayElasticStressModule();

  //! @}


  //! @{
  /*!
   ****************************************************************
   *    
   * @name Methods for accessing elastic stress field data
   *
   ****************************************************************/

  /*!
   * getStressFieldHandle() returns the PatchData handle for the
   * elastic stress field.
   *
   * Arguments:     none
   *   
   * Return value:  PatchData handle for stress field
   *
   */
  virtual inline int getStressFieldHandle() {
    return d_stress_field_handle;
  }

  //! @}


  //! @{
  /*!
   ****************************************************************
   *
   * @name Methods for computing elastic stress field
   *
   ****************************************************************/

  /*!
   * setStressFieldToZero() sets the stress field equal to zero
   * everywhere.
   *
   * Arguments:     none
   * 
   * Return value:  none
   *
   */
  virtual void setStressFieldToZero();

  /*!
   * addStressFieldForDislocationLine() adds the stress field due to the
   * specified dislocation line to the total elastic stress field.
   *
   * Arguments:
   *  - dislocation_line_field_handle (in):  PatchData handle for dislocation 
   *                                         line for which to compute stress
   *                                         field contribution
   *  - burgers_vector (in):                 Burgers vector of dislocation
   *                                         line
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   * 
   * Return value:                           none
   *
   */
  virtual void addStressFieldForDislocationLine(
    const int dislocation_line_handle,
    const BurgersVector& burgers_vector,
    const LSMDD_Parameters& lsmdd_params);

  /*!
   * addAuxiliaryStressField() adds specified auxiliary stress field to the 
   * total elastic stress field.             
   *  
   * Arguments:                              
   *  - auxiliary_stress_field_handle (in):  PatchData handle for auxiliary
   *                                         stress field
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   *
   * Return value:                           none
   *
   */
  virtual void addAuxiliaryStressField(
    const int auxiliary_stress_field_handle,
    const LSMDD_Parameters& lsmdd_params);

  /*!
   * addAuxiliaryStressFieldComponent() adds the component of the specified
   * auxiliary stress field to the total elastic stress field.
   *
   * Arguments:
   *  - auxiliary_stress_field_handle (in):  PatchData handle for auxiliary
   *                                         stress field
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   *  - component (in):                      component of auxiliary stress
   *                                         field to update
   *
   * Return value:                           none
   *
   * NOTES:
   *  - component is the component of stress field to add to 
   *
   *  - auxiliary stress data is assumed to be contained in the component
   *    of PatchData corresponding to auxiliary_stress_field_handle
   */
  virtual void addAuxiliaryStressFieldComponent(
    const int auxiliary_stress_field_handle,
    const LSMDD_Parameters& lsmdd_params,
    const int component);

  //! @}


  //! @{
  /*!
   *******************************************************************
   *
   *  @name Accessor methods for object state
   *
   *******************************************************************/

  /*!
   * printClassData() prints the current state of the ElasticStressStrategy
   * object to the specified output stream.
   *
   * Arguments:
   *  - os (in):    output stream for class data 
   *
   * Return value:  none
   *
   */
  virtual void printClassData(ostream& os) const;

  //! @}


protected:

  //! @{
  /*!
   ****************************************************************
   *    
   * @name Utility methods
   *    
   ****************************************************************/ 

  /*!
   * getFromInput() configures the 
   * PeriodicDislocationArrayElasticStressModule object from 
   * parameters in the specified input database.
   *
   * Arguments:     
   *  - db (in):    input database from which to take parameter
   *                values
   * 
   * Return value:  none
   *
   */
  virtual void getFromInput(Pointer<Database> input_db);

  /*!
   * computeStressOnPatchTimeEfficient() computes the stress fields
   * (in frequency space) on the specified patch.  This function 
   * trades-off greater memory usage for more time efficiency in the
   * computation of the stress fields.
   *
   * Arguments:     
   *  - patch (in):                          reference to Patch on which
   *                                         to compute stress fields 
   *  - dislocation_line_field_handle (in):  PatchData handle for dislocation 
   *                                         line for which to compute stress
   *                                         field contribution
   *  - burgers_vector (in):                 Burgers vector of dislocation
   *                                         line
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   * 
   * Return value:                           none
   *
   */
  virtual void computeStressOnPatchTimeEfficient(
    Pointer< Patch<3> > patch,
    const int dislocation_line_handle,
    const BurgersVector& burgers_vector,
    const LSMDD_Parameters& lsmdd_params);

  /*!
   * computeStressOnPatchMemoryEfficient() computes the stress fields
   * (in frequency space) on the specified patch.  This function 
   * trades-off greater computation time for more efficient memory 
   * usage in the calculation of the stress fields.
   *
   * Arguments:     
   *  - patch (in):                          reference to Patch on which
   *                                         to compute stress fields 
   *  - stress_field_component (in):         component of stress field to 
   *                                         compute
   *  - dislocation_line_field_handle (in):  PatchData handle for dislocation 
   *                                         line for which to compute stress
   *                                         field contribution
   *  - burgers_vector (in):                 Burgers vector of dislocation
   *                                         line
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   * 
   * Return value:                           none
   *
   */
  virtual void computeStressOnPatchMemoryEfficient(
    Pointer< Patch<3> > patch,
    LSMDD::STRESS_COMPONENT_TYPE stress_field_component,
    FFT_DATA *stress_field_fft_data,
    const int dislocation_line_handle,
    const BurgersVector& burgers_vector,
    const LSMDD_Parameters& lsmdd_params);

  /*!
   * allocateFFTData() allocates FFT_DATA that stores the dislocation
   * line field and stress field in frequency space.
   *
   * Arguments:     none
   * 
   * Return value:  none
   *
   */
  virtual void allocateFFTData();

  /*!
   * deallocateFFTData() deallocates FFT_DATA that stores the dislocation
   * line field and stress field in frequency space.
   *
   * Arguments:     none
   * 
   * Return value:  none
   *
   */
  virtual void deallocateFFTData();

  /*!
   * addStressFieldToSAMRAIPatchData() adds the current elastic stress 
   * field stored in the d_stress_field_fft_data FFT_DATA structures to 
   * the stress field stored in the SAMRAI PatchData associated with 
   * d_stress_field_handle.
   *
   * Arguments:     
   *  - patch (in):                        patch on which to accumulate 
   *                                       stress field data
   *  - lsmdd_params (in):                 parameters for dislocation
   *                                       dynamics simulation
   * 
   * Return value:                         none
   *
   * NOTES:
   *  - This method should only be used when memory conservation
   *    is NOT being used (i.e. the FFT data of each stress component 
   *    has its own memory).
   *
   */
  virtual void addStressFieldToSAMRAIPatchData(
    Pointer< Patch<3> > patch,
    const LSMDD_Parameters& lsmdd_params);


  /*!
   * addStressFieldComponentToSAMRAIPatchData() adds the current 
   * elastic stress field stored in the d_stress_field_fft_data
   * FFT_DATA structures to the stress field stored in the SAMRAI 
   * PatchData associated with d_stress_field_handle.
   *
   * Arguments:     
   *  - patch (in):                        patch on which to accumulate 
   *                                       stress field data
   *  - stress_field_fft_data (in):        pointer to FFT_DATA that holds
   *                                       the contribution to the stress
   *                                       field
   *  - stress_component (in):             component of stress field to 
   *                                       accumulate
   *  - lsmdd_params (in):                 parameters for dislocation
   *                                       dynamics simulation
   * 
   * Return value:              none
   *
   */
  virtual void addStressFieldComponentToSAMRAIPatchData(
    Pointer< Patch<3> > patch,
    FFT_DATA *stress_field_fft_data,
    const LSMDD::STRESS_COMPONENT_TYPE stress_component,
    const LSMDD_Parameters& lsmdd_params);

  /*!
   * initializeElasticStressModule() completes the initialization of 
   * the PeriodicDislocationArrayElasticStressModule before any
   * elastic stress fields are calculated.
   *
   * Arguments:     none
   * 
   * Return value:  none
   *
   */
  virtual void initializeElasticStressModule();

  //! @}


  /****************************************************************
   *    
   * Data members
   *    
   ****************************************************************/ 

  // pointer to PatchHierarchy
  Pointer< PatchHierarchy<3> > d_patch_hierarchy;

  // memory usage flags
  bool d_conserve_memory;
  bool d_use_dynamic_memory_allocation;

  // PatchData handle for stress field
  int d_stress_field_handle;

  // global index space 
  Box<3> d_global_box;

  // index space owned by the local processor
  Box<3> d_local_box;

  // pointers to FFT data (required to compute complex FFT using FFTW)
  FFT_DATA *d_dislocation_line_fft_data[3];
  FFT_DATA *d_stress_field_fft_data[6];
  bool d_fft_data_allocated;

  // 3D FFT plan
  struct fft_plan_3d *d_fft_plan;

  // Fourier transform parameters
  double d_fft_scale_factor;   // scale factor relating Fourier transforms
                               // defined in terms of angular and oscillation 
                               // frequencies

  // flag to indicate whether the PeriodicDislocationArrayElasticStressModule 
  // initialization has been completed
  bool d_initialization_complete;

private:

  /*
   * Private copy constructor to prevent use.
   * 
   * Arguments:     
   *  - rhs (in):  PeriodicDislocationArrayElasticStressModule object to copy
   * 
   */
  PeriodicDislocationArrayElasticStressModule(const 
    PeriodicDislocationArrayElasticStressModule& rhs){}
  
  /*
   * Private assignment operator to prevent use.
   * 
   * Arguments:     
   *  - rhs (in):    PeriodicDislocationArrayElasticStressModule object to copy
   * 
   * Return value:   *this
   * 
   */
  const PeriodicDislocationArrayElasticStressModule& operator=(
    const PeriodicDislocationArrayElasticStressModule& rhs) 
  {
    return *this;
  }
  
};

} // end LSMDD namespace

#endif

