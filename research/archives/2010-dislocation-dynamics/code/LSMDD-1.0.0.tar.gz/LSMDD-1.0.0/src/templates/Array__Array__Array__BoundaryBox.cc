/*
 * File:        Array__Array__Array__BoundaryBox.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Explicit template instantiation of LSMDD classes 
 */

#include "SAMRAI_config.h"
#include "BoundaryBox.h"
#include "BoundaryBox.C"
#include "tbox/Array.h"
#include "tbox/Array.C"

template class SAMRAI::tbox::Array< SAMRAI::tbox::Array< 
  SAMRAI::tbox::Array< SAMRAI::hier::BoundaryBox<3> > 
> >;
