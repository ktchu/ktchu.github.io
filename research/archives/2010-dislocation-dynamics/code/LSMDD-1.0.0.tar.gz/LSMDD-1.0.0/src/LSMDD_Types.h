/*
 * File:        LSMDD_Types.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Header file containing type and constant definitions for LSMDD
 */

#ifndef included_LSMDD_Types_h
#define included_LSMDD_Types_h

/*! \file LSMDD_Types.h
 *
 * \brief
 * LSMDD_Types.h defines types and constants used throughout the 
 * LSMDD library.
 *
 */


/******************************************************************
 *
 * DislocationDynamicsModule Class Definition
 *
 ******************************************************************/

namespace LSMDD {

  //! @{
  /*!
   ****************************************************************
   *
   * @name Type and constant definitions
   *
   ****************************************************************/
 

  /*! \enum STRESS_COMPONENT_TYPE
   * 
   * Enumerated type for stress field components.
   * 
   */
  typedef enum { SIGMA_11 = 0,
                 SIGMA_22 = 1,
                 SIGMA_33 = 2,
                 SIGMA_23 = 3,
                 SIGMA_31 = 4,
                 SIGMA_12 = 5 } STRESS_COMPONENT_TYPE;

  //! @}

} // end LSMDD namespace

#endif

