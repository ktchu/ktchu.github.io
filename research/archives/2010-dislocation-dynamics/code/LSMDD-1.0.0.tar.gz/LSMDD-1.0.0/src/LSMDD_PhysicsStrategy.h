/*
 * File:        LSMDD_PhysicsStrategy.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 381 $
 * Modified:    $Date: 2007-08-07 10:36:19 -0400 (Tue, 07 Aug 2007) $
 * Description: Header file for the LSMDD_PhysicsStrategy class
 */

#ifndef included_LSMDD_PhysicsStrategy_h
#define included_LSMDD_PhysicsStrategy_h


/*! \class LSMDD::LSMDD_PhysicsStrategy
 *
 * \brief
 * The LSMDD_PhysicsStrategy defines the interface for user-defined
 * functions required for dislocation dynamics simulations.  In 
 * particular, this class defines the interfaces for specifying the 
 * dislocation configuration, initializing and setting the boundary 
 * conditions for the level set functions that represent dislocation 
 * lines, calculating forces and velocities on dislocations, computing 
 * auxiliary stress fields that affect dislocation motion, and computing 
 * the stable time step size to use for numerical time integration.
 * 
 */


// System headers
#include <float.h>
#include <vector>

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "IntVector.h"
#include "Patch.h"

// Level Set Method Headers
#include "LSMLIB_config.h"
#include "LevelSetMethodToolbox.h"

// LSMDD Headers
#include "LSMDD_config.h"
#include "BurgersVector.h"
#include "LSMDD_Parameters.h"

// headers for level set method geometry functions (required 
// for finding dislocation line within in tetrahedra)
extern "C" {
  #include "lsm_geometry3d.h"
}

// namespaces
using namespace SAMRAI;
using namespace hier;
using namespace LSMLIB;


/******************************************************************
 *
 * LSMDD_PhysicsStrategy Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class LSMDD_PhysicsStrategy
{
public:

  //! @{
  /*!
   ****************************************************************
   *    
   * @name Empty constructor and destructor
   *     
   ****************************************************************/

  LSMDD_PhysicsStrategy(){}
  virtual ~LSMDD_PhysicsStrategy(){}
 
  //! @}


  //! @{
  /*!
   ***********************************************************************
   *
   * @name Methods for accessing dislocation line information
   *
   ***********************************************************************/

  /*!
   * numberOfDislocationLines() should return the number of 
   * distinct dislocation lines in the simulation.  Algorithmically,
   * dislocation lines are considered distinct if they are represented 
   * by a different pair of level set functions.
   *
   * Arguments:     none
   *
   * Return value:  number of distinct dislocation lines 
   *
   */
  virtual int numberOfDislocationLines() const = 0;

  /*!
   * getBurgersVector() should return the Burgers vector of the
   * specified dislocation line.
   *
   * Arguments:
   *  - dislocation_line_handle (in):  handle of the dislocation line
   *                                   of the requested Burgers vector
   *
   * Return value:                     Burgers vector
   * 
   * NOTES:
   *  - The dislocation line handles should lie in the range 
   *    {0,..., number of dislocation lines}
   *
   */
  virtual const BurgersVector& getBurgersVector(
    const int dislocation_line_handle) const = 0;

  /*!
   * getBoundaryConditions() should set the boundary conditions for
   * for the specified dislocation line and level set function.
   *
   * Arguments:
   *  - lower_bc (out):                vector of integers specifying the
   *                                   type of boundary conditions to impose
   *                                   on the lower face of the computational
   *                                   domain in each coordinate direction.
   *                                   The i-th entry will be set to contain 
   *                                   the type of boundary condition to 
   *                                   impose at the lower boundary in the 
   *                                   i-th coordinate direction.
   *  - upper_bc (out):                vector of integers specifying the
   *                                   type of boundary conditions to impose
   *                                   on the upper face of the computational
   *                                   domain in each coordinate direction.
   *                                   The i-th entry will be set to contain 
   *                                   the type of boundary condition to 
   *                                   impose at the upper boundary in the 
   *                                   i-th coordinate direction.
   *  - dislocation_line_handle (in):  handle of the dislocation line
   *                                   for which boundary conditions
   *                                   have been requested
   *  - level_set_fcn (in):            level set function (i.e. LSMLIB::PHI 
   *                                   or LSMLIB::PSI) for which to get 
   *                                   boundary conditions
   *
   * Return value:                     none
   * 
   * NOTES:
   *  - The dislocation line handles should lie in the range 
   *    {0,..., number of dislocation lines}
   *
   *  - The boundary condition types are as follows:
   *    - NONE/PERIODIC:                0
   *    - HOMOEGENEOUS_NEUMANN:         1
   *    - LINEAR_EXTRAPOLATION:         2
   *    - SIGNED_LINEAR_EXTRAPOLATION:  3
   *    - ANTI_PERIODIC:                4
   *
   *    For more information about these boundary conditions, see
   *    the BoundaryConditionModule class in LSMLIB.
   * 
   *    By default, the boundary condition type is set to 
   *    NONE/PERIODIC, which means that no boundary conditions are 
   *    imposed at any non-periodic boundary of the computational 
   *    domain and periodic boundary conditions are imposed at 
   *    periodic boundaries.
   *
   * - To impose periodic boundary conditions in a coordinate direction,
   *   set that coordinate direction to be a periodic direction for the
   *   CartesianGridGeometry object (may be set in the input file) and
   *   set the boundary condition type to NONE. 
   *
   *  - It is acceptable to impose non-periodic boundary conditions 
   *    at boundaries that are specified to be periodic directions
   *    for the GridGeometry object associated with the
   *    PatchHierarchy set in the constructor.  The non-periodic
   *    boundary conditions will override the periodic boundary
   *    conditions.
   *
   *  - In order to use custom boundary conditions at a particular
   *    boundary location, the boundary condition type for that
   *    boundary location MUST be set to NONE.  Otherwise, the
   *    boundary condition will be overwritten by specified boundary
   *    condition type.
   *
   *  - This method has a default implementation so that users
   *    do not need to provide an implementation if the default
   *    boundary conditions (i.e. homogeneous Neumann BCs for
   *    non-periodic boundaries) are sufficient for their problem.
   *
   */
  virtual void getBoundaryConditions(
    IntVector<3>& lower_bc,
    IntVector<3>& upper_bc,
    const int dislocation_line_handle,
    const LEVEL_SET_FCN_TYPE level_set_fcn) const
  {
    lower_bc = IntVector<3>(0);
    upper_bc = IntVector<3>(0);
  }

  //! @}


  //! @{
  /*!
   ***********************************************************************
   *
   * @name Methods for setting initial and boundary conditions 
   *
   * These methods set the initial and boundary conditions for the 
   * level set functions used to represent dislocation lines.
   *
   ***********************************************************************/

  /*!
   * initializeLevelSetFunctionsOnPatch() should set the initial 
   * values of the level set functions associated with ALL of the 
   * dislocation lines.
   *
   * Arguments:
   *  - patch (in):       Patch on which to set initial values 
   *                      for level set functions
   *  - time (in):        simulation time at which level set 
   *                      functions are initialized
   *  - phi_handle (in):  PatchData handle for phi
   *  - psi_handle (in):  PatchData handle for psi
   *
   * Return value:        none
   *
   */
  virtual void initializeLevelSetFunctionsOnPatch(
    Patch<3>& patch, 
    const double time,
    const int phi_handle,
    const int psi_handle) = 0;

  /*!
   * setLevelSetFunctionBoundaryConditions() is intended to allow the
   * user to impose custom/arbitrary boundary conditions for the level 
   * set functions.  It should set the boundary conditions for the level
   * set functions associated with ALL of the dislocation lines.
   *
   * Arguments:
   *  - patch (in):                Patch on which to set boundary conditions
   *                               for level set functions
   *  - time (in):                 simulation time at which boundary conditions
   *                               are being set
   *  - phi_handle (in):           PatchData handle for phi
   *  - psi_handle (in):           PatchData handle for psi
   *  - ghost_width_to_fill (in):  number of ghost cells to fill in each
   *                               coordinate direction
   *
   * Return value:                 none
   *
   * NOTES:
   *  - In order to impose custom boundary conditions at a 
   *    particular boundary location, the boundary condition type 
   *    for that boundary location MUST be set to NONE.  Otherwise, 
   *    the boundary condition will be overwritten by specified 
   *    boundary condition type.
   *
   *  - This method has a default implementation so that users
   *    do not need to provide an implementation if they do not 
   *    require custom boundary conditions.
   *
   */
  virtual void setLevelSetFunctionBoundaryConditions(
    Patch<3>& patch, 
    const double time,
    const int phi_handle,
    const int psi_handle,
    const IntVector<3>& ghost_width_to_fill) {};

  //! @}


  //! @{
  /*!
   ***********************************************************************
   *
   * @name Methods for computing forces and velocities on dislocation lines
   *
   ***********************************************************************/

  /*!
   * computeForceOnDislocationLineOnPatch() computes the force on
   * the specified dislocation line on a single patch.
   *
   * Arguments:
   *  - patch (in):                   Patch on which to compute force 
   *                                  field
   *  - force_handle (out):           PatchData handle of the force field
   *  - stress_field_handle (in):     PatchData handle of the stress field
   *  - tangent_vector_handles (in):  PatchData handle of the tangent
   *                                  vector fields
   *  - phi_handle (in):              PatchData handle of the phi field
   *  - psi_handle (in):              PatchData handle of the psi field
   *  - line_handle (in):             handle of the dislocation line for 
   *                                  which to compute force
   *  - time (in):                    time that force is to be computed
   *  - lsmdd_params (in):            parameters for dislocation
   *                                  dynamics simulation
   *
   * Return value:                    none
   *
   * NOTES:
   *  - For convenience, several methods for computing forces on
   *    dislocation lines are provided by the LSMDD physics modules:
   *    BasicDislocationPhysicsModule, DislocationReactionModule, 
   *    and RestrictedSlipPlaneModule.
   *
   * - When computing forces on dislocation lines, the tangent vector
   *   used is typically computed as grad(phi) cross grad(psi).  The 
   *   dislocation line is NOT explicitly calculated.  
   *
   *  - This method does NOT need to take care of filling the ghostcells
   *    of the force data.  Ghostcells for the force data are filled
   *    using the SAMRAI communication algorithms after the force data
   *    has been computed on all patches.
   *
   *  - It is safe to assume that the ghostcells of the tangent
   *    vector data have been filled.
   *
   *  - The number of ghostcells for the data associated with the
   *    PatchData handles are as follows:
   *    - force_handle:            1
   *    - stress_field_handle:     0
   *    - tangent_vector_handles:  1
   *
   */
  virtual void computeForceOnDislocationLineOnPatch(
    Patch<3>& patch,
    const int force_handle,
    const int stress_field_handle,
    const vector<int>& tangent_vector_handles,
    const int phi_handle,
    const int psi_handle,
    const int line_handle,
    const double time,
    const LSMDD_Parameters& lsmdd_params) = 0;


  /*!
   * computeVelocityForDislocationLineOnPatch() computes the velocity for
   * the specified dislocation line on a single patch.
   *
   * Arguments:
   *  - patch (in):                   Patch on which to compute velocity 
   *                                  field
   *  - velocity_handle (out):        PatchData handle for the velocity
   *                                  field
   *  - force_handle (in):            PatchData handle for the force
   *  - tangent_vector_handles (in):  PatchData handle for the tangent 
   *                                  vector fields
   *  - distance_handle (in):         PatchData handle for the closest
   *                                  distance from the nearest 
   *                                  dislocation line to the center of 
   *                                  the grid cell
   *  - phi_handle (in):              PatchData handle for phi
   *  - psi_handle (in):              PatchData handle for psi
   *  - line_handle (in):             handle for the dislocation line 
   *                                  for which to compute velocity
   *  - time (in):                    time that velocity is to be 
   *                                  computed
   *  - lsmdd_params (in):            parameters for dislocation
   *                                  dynamics simulation
   *
   * Return value:                    none
   *
   * NOTES:
   *  - For convenience, several methods for computing velocities on
   *    dislocation lines are provided by the LSMDD physics modules:
   *    BasicDislocationPhysicsModule, DislocationReactionModule, 
   *    and RestrictedSlipPlaneModule.
   *
   * - When computing velocities on dislocation lines, the tangent 
   *   vector used to determine the character of the dislocation
   *   segment (i.e. pure screw vs. mixed vs. pure edge) is typically
   *   grad(phi) cross grad(psi).  The tangent vector associated with 
   *   the explicit dislocation line segment extracted from the level
   *   set functions is typically only used when interpolating the 
   *   force from grid points to the explicit dislocation segment.
   *
   *  - The number of ghostcells for the data associated with the
   *    PatchData handles are as follows:
   *    - velocity_handle:         1
   *    - force_handle:            1
   *    - tangent_vector_handles:  1
   *    - distance_handle:         1
   *    - phi_handle:            > 1
   *    - psi_handle:            > 1
   *
   *  - The data associated with phi_handle and psi_handle are stored
   *    in the zero-th component, NOT the (line_handle)-th component.
   *
   *  - The velocity and distance data are provided with a ghostcell
   *    width of one so that grid cells on faces, edges, and corners
   *    do NOT need to be treated as special cases when the nearest
   *    point on the dislocation line lies in a cell that includes
   *    the centers of ghostcells.
   *
   *  - The data associated with distance handle is guaranteed to be
   *    initialized to DBL_MAX.
   *
   */
  virtual void computeVelocityForDislocationLineOnPatch(
    Patch<3>& patch,
    const int velocity_handle,
    const int force_handle,
    const vector<int>& tangent_vector_handles,
    const int distance_handle,
    const int phi_handle,
    const int psi_handle,
    const int line_handle,
    const double time,
    const LSMDD_Parameters& lsmdd_params) = 0;

  //! @}


  //! @{
  /*!
   ***********************************************************************
   *
   * @name Methods related to auxiliary stress fields
   *
   ***********************************************************************/

  /*!
   * providesAuxiliaryStressField() returns true if the
   * LSMDD_PhysicsStrategy provides an auxiliary stress field.
   *
   * NOTES:
   *  - This method is NOT pure virtual so that the user need not
   *    concern him/herself with it if it not necessary.  By default,
   *    this method returns false indicating that no external stress
   *    is provided by this class.
   *
   * Arguments:     none
   *
   * Return value:  true if class provides an external stress field;
   *                false otherwise
   *
   * NOTES:
   */
  virtual inline bool providesAuxiliaryStressField() const
  {
    return false;
  }


  /*!
   * computeAuxiliaryStressFieldOnPatch() computes any auxiliary 
   * stress field that should be added to the stress field due to 
   * the dislocations.
   *
   * Arguments:
   *  - patch (in):                      Patch on which to compute 
   *                                     external stress field
   *  - auxiliary_stress_handle (out):   PatchData handle for 
   *                                     external stress field
   *  - dislocation_stress_handle (in):  PatchData handle for 
   *                                     stress due to dislocations
   *  - time (in):                       current simulation time
   *  - lsmdd_params (in):               parameters for dislocation
   *                                     dynamics simulation
   *
   * Return value:                       none
   *
   * NOTES:
   *  - The auxiliary stress field PatchData has zero ghostcells.
   *
   *  - This method is NOT pure virtual so that the user need not
   *    concern him/herself with it if it not necessary.  By default,
   *    this method does nothing.
   *
   */
  virtual inline void computeAuxiliaryStressFieldOnPatch(
    Patch<3>& patch,
    const int auxiliary_stress_field_handle,
    const int dislocation_stress_field_handle,
    const double time, 
    const LSMDD_Parameters& lsmdd_params){};

  //! @}


  //! @{
  /*!
   ***********************************************************************
   *
   * @name Methods related to time integration
   *
   ***********************************************************************/

  /*!
   * computeStableDtOnPatch() should return a user-specified stable time 
   * step for advancing the level set functions associated with the 
   * specified dislocation line.
   *
   * Arguments:
   *  - patch (in):  Patch on which to compute stable dt.
   *
   * Return value:   user-specified time step size
   *
   * NOTES:
   *  - This method is intended to give the user arbitrary control over
   *    the time step size.  
   *
   *  - This method is NOT pure virtual so that the user need not
   *    concern him/herself with it if it not necessary.  The default
   *    value is the largest double value available on the machine so 
   *    that it will not interfere with than any other numerical time 
   *    step constraints computed by the LevelSetMethodAlgorithm class.
   *
   */
  virtual inline double computeStableDtOnPatch(Patch<3>& patch) 
  {
    return DBL_MAX;
  } 

  //! @}


  //! @{
  /*!
   ***********************************************************************
   *
   * @name Methods for pre/postprocessing data during time advance of
   *       dislocations
   *
   * These methods are used to preprocess data before advancing 
   * dislocations in time or postprocessing data after the dislocations
   * have been advanced in time.  
   *
   ***********************************************************************/

  /*!
   * preprocessAdvanceDislocations() may be used to preprocess data
   * before advancing dislocations in time.
   *
   * Arguments:
   *  - hierarchy (in):     PatchHierarchy on which to 
   *                        preprocess data
   *  - phi_handle (in):    PatchData handle for phi
   *  - psi_handle (in):    PatchData handle for psi
   *  - lsmdd_params (in):  parameters for dislocation
   *                        dynamics simulation
   *  - time (in):          current simulation time 
   *
   * Return value:          none
   *
   * NOTES:
   *  - This method is NOT pure virtual so that the user need not
   *    concern him/herself with it if it not necessary.  The 
   *    default behavior is to do nothing.
   *
   */
  virtual void preprocessAdvanceDislocations(
    PatchHierarchy<3>& hierarchy, 
    const int phi_handle,
    const int psi_handle,
    const LSMDD_Parameters& lsmdd_params,
    const double time) {}

  /*!
   * postprocessAdvanceDislocations() may be used to postprocess data
   * after dislocations have been advanced in time.
   *
   * Arguments:
   *  - hierarchy (in):     PatchHierarchy on which to 
   *                        postprocess data
   *  - phi_handle (in):    PatchData handle for phi
   *  - psi_handle (in):    PatchData handle for psi
   *  - lsmdd_params (in):  parameters for dislocation
   *                        dynamics simulation
   *  - time (in):          current simulation time 
   *
   * Return value:          none
   *
   * NOTES:
   *  - This method is NOT pure virtual so that the user need not
   *    concern him/herself with it if it not necessary.  The 
   *    default behavior is to do nothing.
   *
   */
  virtual void postprocessAdvanceDislocations(
    PatchHierarchy<3>& hierarchy, 
    const int phi_handle,
    const int psi_handle,
    const LSMDD_Parameters& lsmdd_params,
    const double time) {}

  //! @}

};

} // end LSMDD namespace

#endif
