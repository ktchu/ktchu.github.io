/*
 * File:        BasicDislocationPhysicsModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 317 $
 * Modified:    $Date: 2007-07-06 23:22:25 -0400 (Fri, 06 Jul 2007) $
 * Description: Implementation file for the BasicDislocationPhysicsModule class
 */

#include "BasicDislocationPhysicsModule.h"

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "CellData.h"
#include "CartesianPatchGeometry.h"

// LSMDD Headers
#include "LSMDD_Utilities.h"

// namespaces
using namespace SAMRAI;
using namespace tbox;
using namespace pdat;


namespace LSMDD {


void BasicDislocationPhysicsModule::computePKForce(
  double &force_x,
  double &force_y,
  double &force_z,
  double b_x,
  double b_y,
  double b_z,
  double tangent_vector_x,
  double tangent_vector_y,
  double tangent_vector_z,
  double sigma11,
  double sigma22,
  double sigma33,
  double sigma23,
  double sigma31,
  double sigma12,
  const double *X,
  bool verbose_mode)
{
  // compute force using the formula:
  // f = (sigma dot burgers_vector) cross tangent_vector
  double sigma_dot_b_x = sigma11*b_x + sigma12*b_y + sigma31*b_z;
  double sigma_dot_b_y = sigma12*b_x + sigma22*b_y + sigma23*b_z;
  double sigma_dot_b_z = sigma31*b_x + sigma23*b_y + sigma33*b_z;
               
  force_x = sigma_dot_b_y*tangent_vector_z
          - sigma_dot_b_z*tangent_vector_y;
  force_y = sigma_dot_b_z*tangent_vector_x
          - sigma_dot_b_x*tangent_vector_z;
  force_z = sigma_dot_b_x*tangent_vector_y
          - sigma_dot_b_y*tangent_vector_x;

  if (verbose_mode) {
    plog << "computePKForce(): " << endl;
    plog << "  position = ("
         << X[0] << ","
         << X[1] << ","
         << X[2] << ")" << endl;
    plog << "  sigma = ("
         << sigma11 << ","
         << sigma22 << ","
         << sigma33 << ","
         << sigma23 << ","
         << sigma31 << ","
         << sigma12 << ")" << endl;
    plog << "  force = ("
         << force_x << ","
         << force_y << ","
         << force_z << ")" << endl;
  }

}


void BasicDislocationPhysicsModule::computeVelocityUsingBasicFormula(
  double &velocity_x,
  double &velocity_y,
  double &velocity_z,
  double force_x, double force_y, double force_z,
  double b_x, double b_y, double b_z,
  double tangent_vector_x,
  double tangent_vector_y,
  double tangent_vector_z,
  double glide_mobility,
  double climb_mobility,
  double max_angle_for_pure_screw,
  const double *X,
  bool verbose_mode)
{
  // compute the component of the Burgers vector 
  // normal to the dislocation line
  double b_dot_tangent = b_x*tangent_vector_x
                       + b_y*tangent_vector_y
                       + b_z*tangent_vector_z;
  double b_normal_x = b_x - b_dot_tangent*tangent_vector_x;
  double b_normal_y = b_y - b_dot_tangent*tangent_vector_y;
  double b_normal_z = b_z - b_dot_tangent*tangent_vector_z;
  double b_normal_length =
    sqrt( b_normal_x*b_normal_x
        + b_normal_y*b_normal_y
        + b_normal_z*b_normal_z );

  if (verbose_mode) {
    plog << "computeVelocityUsingBasicFormula():"
         << endl;
    plog << "  position = ("
         << X[0] << ","
         << X[1] << ","
         << X[2] << ")" << endl;
    plog << "  b_normal_length: " << b_normal_length
         << endl;
    plog << "  b_tangent_length: " << b_dot_tangent
         << endl;
  }

  // compute velocity from force
  bool segment_is_pure_screw = false;
  CHECK_FOR_PURE_SCREW_SCREW_DISLOCATION(
    segment_is_pure_screw, max_angle_for_pure_screw,
    b_x, b_y, b_z,
    tangent_vector_x,
    tangent_vector_y,
    tangent_vector_z);
  if (segment_is_pure_screw) {

    // case: pure screw dislocation
    if (verbose_mode) {
      plog << "  SCREW DISLOCATION" << endl;
    }

    // compute component of force tangent to dislocation
    // line so that it can be removed from velocity 
    // calculation
    double tangent_force_magnitude =
        force_x*tangent_vector_x
      + force_y*tangent_vector_y
      + force_z*tangent_vector_z;

    // compute velocity 
    velocity_x = glide_mobility 
               * (force_x - tangent_force_magnitude*tangent_vector_x);
    velocity_y = glide_mobility
               * (force_y - tangent_force_magnitude*tangent_vector_y);
    velocity_z = glide_mobility
               * (force_z - tangent_force_magnitude*tangent_vector_z);

  } else { // case: mixed dislocation

    if (verbose_mode) {
      plog << "  MIXED DISLOCATION" << endl;
    }

    // normalize b_normal for projection purposes
    double inv_b_normal_length = 1.0/b_normal_length;
    b_normal_x *= inv_b_normal_length;
    b_normal_y *= inv_b_normal_length;
    b_normal_z *= inv_b_normal_length;

    // compute component of force that contributes to glide 
    double glide_force_magnitude =
        force_x*b_normal_x
      + force_y*b_normal_y
      + force_z*b_normal_z;

    // compute component of force tangent to dislocation
    // line so its contribution can be removed from
    // velocity calculation
    double tangent_force_magnitude =
        force_x*tangent_vector_x
      + force_y*tangent_vector_y
      + force_z*tangent_vector_z;

    // compute velocity due to glide and climb
    // force
    velocity_x =
        glide_mobility*glide_force_magnitude*b_normal_x
      + climb_mobility*
        ( force_x - glide_force_magnitude*b_normal_x
        - tangent_force_magnitude*tangent_vector_x);
    velocity_y =
        glide_mobility*glide_force_magnitude*b_normal_y
      + climb_mobility*
        ( force_y - glide_force_magnitude*b_normal_y
        - tangent_force_magnitude*tangent_vector_y);
    velocity_z =
        glide_mobility*glide_force_magnitude*b_normal_z
      + climb_mobility*
        ( force_z - glide_force_magnitude*b_normal_z
        - tangent_force_magnitude*tangent_vector_z);

  }
}


} // end LSMDD namespace
