/*
 * File:        BasicDislocationPhysicsModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 317 $
 * Modified:    $Date: 2007-07-06 23:22:25 -0400 (Fri, 06 Jul 2007) $
 * Description: Header file for the BasicDislocationPhysicsModule class
 */

#ifndef included_BasicDislocationPhysicsModule_h
#define included_BasicDislocationPhysicsModule_h

/*! \class LSMDD::BasicDislocationPhysicsModule
 *
 * \brief
 * The BasicDislocationPhysicsModule provides a collection of methods 
 * for computing forces and velocities on dislocation lines using only
 * basic dislocation physics (e.g. Peach-Koehler force).
 * 
 */


// SAMRAI Headers
#include "SAMRAI_config.h"
#include "Patch.h"

// LSMDD Headers
#include "LSMDD_config.h"


/******************************************************************
 *
 * BasicDislocationPhysicsModule Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class BasicDislocationPhysicsModule
{
public:

  /*!
   * computePKForce() computes the Peach-Koehler force for the given
   * dislocation line segment. 
   *
   * Arguments:
   *  - force_* (out):          components of force on dislocation
   *                            line segment
   *  - b_x, b_y, b_z (in):     Burgers vector of dislocation
   *  - tangent_vector_* (in):  segment components of tangent vector
   *                            for dislocation line segment
   *  - sigma* (in):            components of stress on dislocation
   *                            segment
   *  - X (in):                 coordinates of position of center of 
   *                            grid cell where force is being computed
   *  - verbose_mode (in):      flag indicating whether status
   *                            information should be output
   *                            (default = false)
   *
   * Return value:              none
   *
   */
  static void computePKForce(
    double &force_x,
    double &force_y,
    double &force_z,
    double b_x,
    double b_y,
    double b_z,
    double tangent_vector_x,
    double tangent_vector_y,
    double tangent_vector_z,
    double sigma11,
    double sigma22,
    double sigma33,
    double sigma23,
    double sigma31,
    double sigma12,
    const double *X,
    bool verbose_mode = false);

  /*!
   * computeVelocityUsingBasicFormula() computes the velocity
   * on a dislocation line segment using the basic formula 
   * relating the velocity to the force per unit length.
   *
   * Arguments:
   *  - velocity_* (out):               components of velocity on 
   *                                    dislocation line segment
   *  - force_* (in):                   components of force on 
   *                                    dislocation line segment
   *  - b_x, b_y, b_z (in):             Burgers vector of dislocation
   *  - tangent_vector_* (in):          segment components of tangent
   *                                    vector for dislocation line 
   *                                    segment
   *  - glide_mobility (in):            glide mobility for dislocations
   *  - climb_mobility (in):            climb mobility for dislocations
   *  - max_angle_for_pure_screw (in):  maximum angle between the Burgers
   *                                    vector and tangent vector for
   *                                    considering a dislocation line
   *                                    segment to be pure screw
   *  - X (in):                         coordinates of position of center 
   *                                    of grid cell where velocity is 
   *                                    being computed
   *  - verbose_mode (in):              flag indicating whether status
   *                                    information should be output
   *                                    (default = false)
   *
   * Return value:                      none
   *
   */
  static void computeVelocityUsingBasicFormula(
    double &velocity_x,
    double &velocity_y,
    double &velocity_z,
    double force_x, double force_y, double force_z,
    double b_x, double b_y, double b_z,
    double tangent_vector_x,
    double tangent_vector_y,
    double tangent_vector_z,
    double glide_mobility,
    double climb_mobility,
    double max_angle_for_pure_screw,
    const double *X,
    bool verbose_mode = false);


private:

  /*
   * Private default constructor to prevent use.
   *
   * Arguments:  none
   *
   */
  BasicDislocationPhysicsModule(){}

  /*
   * Private copy constructor to prevent use.
   *
   * Arguments:
   *  - rhs (in):  BasicDislocationPhysicsModule object to copy
   *
   */
  BasicDislocationPhysicsModule(const BasicDislocationPhysicsModule& rhs){}

  /*
   * Private assignment operator to prevent use.
   *
   * Arguments:
   *  - rhs (in):   BasicDislocationPhysicsModule object to copy
   *
   * Return value:  *this
   *
   */
  const BasicDislocationPhysicsModule& operator=(
    const BasicDislocationPhysicsModule& rhs){ return *this; }

};

} // end LSMDD namespace

#endif
