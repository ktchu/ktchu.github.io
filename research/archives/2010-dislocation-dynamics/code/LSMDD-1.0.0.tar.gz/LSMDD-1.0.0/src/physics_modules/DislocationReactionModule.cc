/*
 * File:        DislocationReactionModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   S.S. Jerry Quek, Kevin T. Chu
 * Revision:    $Revision: 1.12 $
 * Modified:    $Date: 2006/10/17 20:36:16 $
 * Description: Implementation file for DislocationReactionModule
 */


#include "DislocationReactionModule.h"

// System Headers
#include <sstream>

// SAMRAI Headers
#include "CellVariable.h"
#include "CellData.h"

// LSMDD Headers
#include "BasicDislocationPhysicsModule.h"

extern "C" {
  #include <math.h>
}

// namespaces
using namespace pdat;

namespace LSMDD {

void DislocationReactionModule::setupReactionData(
  int& rxn_status_handle,
  int& rxn_line_number_handle)
{

  // get pointer to VariableDatabase and set up ghostcell width
  VariableDatabase<3> *var_db = VariableDatabase<3>::getDatabase();
  IntVector<3> one_ghostcell_width(1);

  // create variables for reaction data
  Pointer< CellVariable<3,int> > rxn_status_variable =
    new CellVariable<3,int>("reaction status (LSMDD)",1);
  Pointer< CellVariable<3,int> > rxn_line_number_variable =
    new CellVariable<3,int>("reaction line number (LSMDD)",1);

  // create context for reaction data
  Pointer<VariableContext> reaction_context =
    var_db->getContext("LSMDD_REACTION_CONTEXT");

  // register PatchData handle for reaction status data
  rxn_status_handle = var_db->registerVariableAndContext(
    rxn_status_variable, reaction_context, one_ghostcell_width);

  // register PatchData handle for reaction line number data
  rxn_line_number_handle = var_db->registerVariableAndContext(
    rxn_line_number_variable, reaction_context, one_ghostcell_width);

}


void DislocationReactionModule::allocateReactionData(
  PatchHierarchy<3>& hierarchy,
  int& rxn_status_handle,
  int& rxn_line_number_handle)
{
  const int num_levels = hierarchy.getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = hierarchy.getPatchLevel(ln);
    
    // allocate memory for reaction data
    level->allocatePatchData(rxn_status_handle);
    level->allocatePatchData(rxn_line_number_handle);
    
    // loop over patches and fill reaction status with 0.
    for (PatchLevelIterator<3> pi(level); pi; pi++) { 
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      Pointer< CellData<3,int> > rxn_status_data =
        patch->getPatchData( rxn_status_handle );
      rxn_status_data->fillAll(0);
    } 
  }

}


void DislocationReactionModule::deallocateReactionData(
  PatchHierarchy<3>& hierarchy,
  int& rxn_status_handle,
  int& rxn_line_number_handle)
{
  const int num_levels = hierarchy.getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = hierarchy.getPatchLevel(ln);
    
    // deallocate memory for reaction data
    level->deallocatePatchData(rxn_status_handle);
    level->deallocatePatchData(rxn_line_number_handle);
    
  }

}


int DislocationReactionModule::computeForceOnDislocationLineWithReactions(
  double &force_x,
  double &force_y,
  double &force_z,
  int &rxn_line_num,
  double **phi,
  double **psi,
  double *tangent_vectors_x,
  double *tangent_vectors_y,
  double *tangent_vectors_z,
  Array< BurgersVector >& burgers_vectors,
  double  sigma11,
  double  sigma22,
  double  sigma33,
  double  sigma23,
  double  sigma31,
  double  sigma12,
  int *level_set_fcn_box_dims,
  int *level_set_fcn_ghostcell_width,
  int i,
  int j,
  int k,
  const double *X,
  const double *dX,
  const int line_handle,
  const LSMDD_Parameters& lsmdd_params,
  double interaction_force_strength)
{
  // set default value for rxn_line_num
  rxn_line_num = line_handle;

  // set up to check if a dislocation reaction occurs 
  // involving the current dislocation line
  double b_x = 0.0;
  double b_y = 0.0;
  double b_z = 0.0;

  // compute reaction distance tolerance
  double rxn_dist_tol = lsmdd_params.getCoreRadius();

  // initialize relative position to 0
  double relative_position_x = 0.0;
  double relative_position_y = 0.0;
  double relative_position_z = 0.0;

  // check if a dislocation reaction occurs involving the 
  // current dislocation line
  //
  // rxn_status = 0 -> no reaction
  // rxn_status = 1 or -1 -> reaction: b=b1+b2 or b=b1-b2
  // rxn_status = 2 or -2 -> interpolate force between 
  //                         reaction and no reaction
  // minus sign in rxn_status indicates that the tangent vectors 
  // of reacting segments are opposite
  int rxn_status = checkForReaction(
                         rxn_line_num,
                         relative_position_x,
                         relative_position_y,
                         relative_position_z,
                         phi,
                         psi,
                         tangent_vectors_x,
                         tangent_vectors_y,
                         tangent_vectors_z,
                         burgers_vectors,
                         level_set_fcn_box_dims,
                         level_set_fcn_ghostcell_width,
                         i, j, k,
                         X,
                         dX,
                         line_handle,
                         lsmdd_params );

  // get tangent vector corresponding to line_handle
  double active_tangent_vector_x = tangent_vectors_x[line_handle];
  double active_tangent_vector_y = tangent_vectors_y[line_handle];
  double active_tangent_vector_z = tangent_vectors_z[line_handle];

  // get shear modulus and poisson ratio
  double shear_modulus = lsmdd_params.getShearModulus();
  double poisson_ratio = lsmdd_params.getPoissonRatio();

  // compute force depending on reaction status
  if (rxn_status != 0 && rxn_line_num != line_handle) {
    // case: reaction occurs

    /*
     * compute analytical interaction force per unit length
     * between two general straight dislocation lines
     */
    // compute b1 x tangent vector
    double b1_cross_tangent_vector_x =
        burgers_vectors[line_handle][1]*active_tangent_vector_z
      - burgers_vectors[line_handle][2]*active_tangent_vector_y;
    double b1_cross_tangent_vector_y =
        burgers_vectors[line_handle][2]*active_tangent_vector_x
      - burgers_vectors[line_handle][0]*active_tangent_vector_z;
    double b1_cross_tangent_vector_z =
        burgers_vectors[line_handle][0]*active_tangent_vector_y
      - burgers_vectors[line_handle][1]*active_tangent_vector_x;
    // compute b2 x tangent vector
    double b2_cross_tangent_vector_x =
        burgers_vectors[rxn_line_num][1]*active_tangent_vector_z
      - burgers_vectors[rxn_line_num][2]*active_tangent_vector_y;
    double b2_cross_tangent_vector_y =
        burgers_vectors[rxn_line_num][2]*active_tangent_vector_x
      - burgers_vectors[rxn_line_num][0]*active_tangent_vector_z;
    double b2_cross_tangent_vector_z =
        burgers_vectors[rxn_line_num][0]*active_tangent_vector_y
      - burgers_vectors[rxn_line_num][1]*active_tangent_vector_x;
    // compute (b1 x tangent vector) dot (b2 x tangent vector)
    double temp_dot =
        b1_cross_tangent_vector_x*b2_cross_tangent_vector_x
      + b1_cross_tangent_vector_y*b2_cross_tangent_vector_y
      + b1_cross_tangent_vector_z*b2_cross_tangent_vector_z;
    // compute b1 dot tangent vector
    double b1_dot_tangent_vector =
       burgers_vectors[line_handle][0]*active_tangent_vector_x
     + burgers_vectors[line_handle][1]*active_tangent_vector_y
     + burgers_vectors[line_handle][2]*active_tangent_vector_z;
    // compute b2 dot tangent vector
    double b2_dot_tangent_vector =
       burgers_vectors[rxn_line_num][0]*active_tangent_vector_x
     + burgers_vectors[rxn_line_num][1]*active_tangent_vector_y
     + burgers_vectors[rxn_line_num][2]*active_tangent_vector_z;
    // compute radial interaction force at reaction tolerance
    double analytical_radial_force =
       (shear_modulus/2.0/3.14159/rxn_dist_tol)
     * ( (b1_dot_tangent_vector*b2_dot_tangent_vector)
       + temp_dot/(1.0-poisson_ratio) );

    // scale analytical radial interaction force
    analytical_radial_force *= interaction_force_strength;

    // compute absolute distance between dislocations
    double abs_distance = sqrt(relative_position_x*relative_position_x
                              +relative_position_y*relative_position_y
                              +relative_position_z*relative_position_z);

    // interpolate linearly between zero force at center to 
    // analytical_radial_force at reaction tolerance
    double radial_force_interpolate =
        analytical_radial_force*abs_distance/rxn_dist_tol;

    // compute total force depending on how close 
    // reacting dislocation lines are
    if (rxn_status == 1 || rxn_status == -1) {
      if (rxn_status == 1) {
        // case: tangent vectors same sign
        b_x = burgers_vectors[line_handle][0]
            + burgers_vectors[rxn_line_num][0];
        b_y = burgers_vectors[line_handle][1]
            + burgers_vectors[rxn_line_num][1];
        b_z = burgers_vectors[line_handle][2]
            + burgers_vectors[rxn_line_num][2];
      } else {
        // case: tangent vectors opposite in sign
        b_x = burgers_vectors[line_handle][0]
            - burgers_vectors[rxn_line_num][0];
        b_y = burgers_vectors[line_handle][1]
            - burgers_vectors[rxn_line_num][1];
        b_z = burgers_vectors[line_handle][2]
            - burgers_vectors[rxn_line_num][2];
      }

      // compute PK-force
      BasicDislocationPhysicsModule::computePKForce(
        force_x, force_y, force_z,
        b_x, b_y, b_z,
        active_tangent_vector_x,
        active_tangent_vector_y,
        active_tangent_vector_z,
        sigma11,
        sigma22,
        sigma33,
        sigma23,
        sigma31,
        sigma12,
        X, false); // false indicates that verbose mode is off

      // add interaction force
      force_x +=
        fabs(radial_force_interpolate)*relative_position_x/abs_distance;
      force_y +=
        fabs(radial_force_interpolate)*relative_position_y/abs_distance;
      force_z +=
        fabs(radial_force_interpolate)*relative_position_z/abs_distance;

    } // end of rxn_status = 1 or -1 

    else if (rxn_status == 2 || rxn_status == -2) {

      if (rxn_status == 2) {
        // case: tangent vectors same sign
        b_x = burgers_vectors[line_handle][0]
            + burgers_vectors[rxn_line_num][0];
        b_y = burgers_vectors[line_handle][1]
            + burgers_vectors[rxn_line_num][1];
        b_z = burgers_vectors[line_handle][2]
            + burgers_vectors[rxn_line_num][2];
      } else {
        // case: tangent vectors opposite in sign
        b_x = burgers_vectors[line_handle][0]
            - burgers_vectors[rxn_line_num][0];
        b_y = burgers_vectors[line_handle][1]
            - burgers_vectors[rxn_line_num][1];
        b_z = burgers_vectors[line_handle][2]
            - burgers_vectors[rxn_line_num][2];
      }

      // compute PK-force 
      BasicDislocationPhysicsModule::computePKForce(
        force_x, force_y, force_z,
        b_x, b_y, b_z,
        active_tangent_vector_x,
        active_tangent_vector_y,
        active_tangent_vector_z,
        sigma11,
        sigma22,
        sigma33,
        sigma23,
        sigma31,
        sigma12,
        X, false);  // false indicates that verbose mode is off

      // add interaction force
      force_x +=
        fabs(radial_force_interpolate)*relative_position_x/abs_distance;
      force_y +=
        fabs(radial_force_interpolate)*relative_position_y/abs_distance;
      force_z +=
        fabs(radial_force_interpolate)*relative_position_z/abs_distance;

      // next consider without reaction
      // get Burgers vector
      b_x = burgers_vectors[line_handle][0];
      b_y = burgers_vectors[line_handle][1];
      b_z = burgers_vectors[line_handle][2];

      double force_x_no_rxn;
      double force_y_no_rxn;
      double force_z_no_rxn;

      // compute PK-force 
      BasicDislocationPhysicsModule::computePKForce(
        force_x_no_rxn, force_y_no_rxn, force_z_no_rxn,
        b_x, b_y, b_z,
        active_tangent_vector_x,
        active_tangent_vector_y,
        active_tangent_vector_z,
        sigma11,
        sigma22,
        sigma33,
        sigma23,
        sigma31,
        sigma12,
        X, false);  // false indicates that verbose mode is off

      // interpolation parameter to linearly interpolate between 
      // force on single dislocation and force acting on merged 
      // dislocations
      double interpolation_param =
        (2.0*rxn_dist_tol-abs_distance)/rxn_dist_tol;
      force_x = force_x*interpolation_param
              + (1.0-interpolation_param)*force_x_no_rxn;
      force_y = force_y*interpolation_param
              + (1.0-interpolation_param)*force_y_no_rxn;
      force_z = force_z*interpolation_param
              + (1.0-interpolation_param)*force_z_no_rxn;

    }  // end of rxn_status = 2 or -2

  } // end of rxn_status != 0 (reaction)

  else {
    // case: no reaction

    // get Burgers vector
    b_x = burgers_vectors[line_handle][0];
    b_y = burgers_vectors[line_handle][1];
    b_z = burgers_vectors[line_handle][2];

    // compute PK-force 
    BasicDislocationPhysicsModule::computePKForce(
      force_x, force_y, force_z,
      b_x, b_y, b_z,
      active_tangent_vector_x,
      active_tangent_vector_y,
      active_tangent_vector_z,
      sigma11,
      sigma22,
      sigma33,
      sigma23,
      sigma31,
      sigma12,
      X, false);  // false indicates that verbose mode is off

  } // end of no reaction


  return rxn_status;
}


int DislocationReactionModule::checkForReaction(
  int& rxn_line_num,
  double& relative_position_x,
  double& relative_position_y,
  double& relative_position_z,
  double **phi,
  double **psi,
  double *tangent_vectors_x,
  double *tangent_vectors_y,
  double *tangent_vectors_z,
  Array< BurgersVector >& burgers_vectors,
  int *level_set_fcn_box_dims,
  int *level_set_fcn_ghostcell_width,
  int i,
  int j,
  int k,
  const double *X,
  const double *dX,
  const int line_handle,
  const LSMDD_Parameters& lsmdd_params)
{
  // set rxn_status value if there is no reaction
  int rxn_status = 0;

  // set rxn_line_num to line_handle if there is no reaction
  rxn_line_num = line_handle;

  // cache dx, dy, dz 
  const double dx = dX[0];
  const double dy = dX[1];
  const double dz = dX[2];

  // grid position in array
  int idx;
  int idx_x = i + level_set_fcn_ghostcell_width[0];
  int idx_y = j + level_set_fcn_ghostcell_width[1];
  int idx_z = k + level_set_fcn_ghostcell_width[2];

  // increment and decrement in grid index
  int idx_x_plus_1, idx_y_plus_1, idx_z_plus_1;
  int idx_x_minus_1, idx_y_minus_1, idx_z_minus_1;

  // grid position of increment or decrement in array
  int idx_increment, idx_decrement;

  // grid position in array
  idx = idx_x + idx_y*level_set_fcn_box_dims[0]
      + idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];

  // increment or decrement in grid index
  idx_x_plus_1 = idx_x + 1;
  idx_y_plus_1 = idx_y + 1;
  idx_z_plus_1 = idx_z + 1;
  idx_x_minus_1 = idx_x - 1;
  idx_y_minus_1 = idx_y - 1;
  idx_z_minus_1 = idx_z - 1;
  

  // compute reaction tolerances
  double rxn_dist_tol = (dX[0] > dX[1]) ? dX[0] : dX[1];
  rxn_dist_tol = (rxn_dist_tol > dX[2]) ? rxn_dist_tol : dX[2];
  rxn_dist_tol *= 3.0;
  double zero_level_set_tol = rxn_dist_tol*2.0/3.0;
  double parallel_tangent_vectors_tol = 0.1;


  // temporary calculations for calculating position vector
  double temp1, temp2, temp3;
  double alpha, beta;

  // position vectors of segments with phi=0 and psi=0
  double position_vector1_x;
  double position_vector1_y;
  double position_vector1_z;
  double position_vector2_x;
  double position_vector2_y;
  double position_vector2_z;

  // absolute distance between dislocation segments
  double abs_distance;

  // derivatives of phi and psi
  double phix, phiy, phiz;
  double psix, psiy, psiz;

  // components of burgers vectors
  int num_dislocation_lines = burgers_vectors.size();
  double *b_x;
  double *b_y;
  double *b_z;
  b_x = new double[num_dislocation_lines];
  b_y = new double[num_dislocation_lines];
  b_z = new double[num_dislocation_lines];

  // get burgers vectors;
  for (int line_num=0; line_num<num_dislocation_lines; line_num++) {
    b_x[line_num] = burgers_vectors[line_num][0];
    b_y[line_num] = burgers_vectors[line_num][1];
    b_z[line_num] = burgers_vectors[line_num][2];
  }

  // loop through dislocation lines with different burgers vectors
  // to check reaction
  for (int line_num=0; line_num<num_dislocation_lines; line_num++) {
    // perform reaction check only between dislocations with 
    // different burgers vectors.  for same burgers vectors, reaction 
    // is accounted for 

    if (line_num != line_handle) {  
      // compute dot product of tangent vectors of two dislocations
      // with different burgers vectors
      double tangent_vectors_dot = 
         tangent_vectors_x[line_handle]*tangent_vectors_x[line_num] 
       + tangent_vectors_y[line_handle]*tangent_vectors_y[line_num] 
       + tangent_vectors_z[line_handle]*tangent_vectors_z[line_num];
      // calculate distance between segments if all the level set functions
      // are near zero and their tangent vectors are parallel and check against
      // reaction tolerance
      if ( fabs(phi[line_handle][idx]) <= zero_level_set_tol &&
           fabs(psi[line_handle][idx]) <= zero_level_set_tol &&
           fabs(phi[line_num][idx]) <= zero_level_set_tol &&
           fabs(psi[line_num][idx]) <= zero_level_set_tol &&
         (1.0-fabs(tangent_vectors_dot)) <= parallel_tangent_vectors_tol)
      {
        // compute position vector of dislocation (line_handle)
        idx_increment = idx_x_plus_1 + idx_y*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        idx_decrement = idx_x_minus_1 + idx_y*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        phix = (phi[line_handle][idx_increment]-phi[line_handle][idx_decrement])
             / 2.0/dx;
        psix = (psi[line_handle][idx_increment]-psi[line_handle][idx_decrement])
             / 2.0/dx;
    
        idx_increment = idx_x + idx_y_plus_1*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        idx_decrement = idx_x + idx_y_minus_1*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        phiy = (phi[line_handle][idx_increment]-phi[line_handle][idx_decrement])
             / 2.0/dy;
        psiy = (psi[line_handle][idx_increment]-psi[line_handle][idx_decrement])
             / 2.0/dy;
    
        idx_increment = idx_x + idx_y*level_set_fcn_box_dims[0] +
            idx_z_plus_1*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        idx_decrement = idx_x + idx_y*level_set_fcn_box_dims[0] +
            idx_z_minus_1*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        phiz = (phi[line_handle][idx_increment]-phi[line_handle][idx_decrement])
             / 2.0/dz;
        psiz = (psi[line_handle][idx_increment]-psi[line_handle][idx_decrement])
             / 2.0/dz;
    
        temp1 = phix*phix + phiy*phiy + phiz*phiz;
        temp2 = psix*psix + psiy*psiy + psiz*psiz;
        temp3 = phix*psix + phiy*psiy + phiz*psiz;
    
        alpha = -(phi[line_handle][idx]*temp2 - psi[line_handle][idx]*temp3)
              / (temp1*temp2 - temp3*temp3);
        beta = -(psi[line_handle][idx]*temp1 - phi[line_handle][idx]*temp3)
             / (temp1*temp2 - temp3*temp3);
    
        position_vector1_x = X[0] + alpha*phix + beta*psix;
        position_vector1_y = X[1] + alpha*phiy + beta*psiy;
        position_vector1_z = X[2] + alpha*phiz + beta*psiz;
    
        // compute position vector of dislocation (line_num)
        idx_increment = idx_x_plus_1 + idx_y*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        idx_decrement = idx_x_minus_1 + idx_y*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        phix = (phi[line_num][idx_increment]-phi[line_num][idx_decrement])
             / 2.0/dx;
        psix = (psi[line_num][idx_increment]-psi[line_num][idx_decrement])
             / 2.0/dx;
    
        idx_increment = idx_x + idx_y_plus_1*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        idx_decrement = idx_x + idx_y_minus_1*level_set_fcn_box_dims[0] +
            idx_z*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        phiy = (phi[line_num][idx_increment]-phi[line_num][idx_decrement])
             / 2.0/dy;
        psiy = (psi[line_num][idx_increment]-psi[line_num][idx_decrement])
             / 2.0/dy;
    
        idx_increment = idx_x + idx_y*level_set_fcn_box_dims[0] +
            idx_z_plus_1*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        idx_decrement = idx_x + idx_y*level_set_fcn_box_dims[0] +
            idx_z_minus_1*level_set_fcn_box_dims[0]*level_set_fcn_box_dims[1];
        phiz = (phi[line_num][idx_increment]-phi[line_num][idx_decrement])
             / 2.0/dz;
        psiz = (psi[line_num][idx_increment]-psi[line_num][idx_decrement])
             / 2.0/dz;
    
        temp1 = phix*phix + phiy*phiy + phiz*phiz;
        temp2 = psix*psix + psiy*psiy + psiz*psiz;
        temp3 = phix*psix + phiy*psiy + phiz*psiz;
    
        alpha = -(phi[line_num][idx]*temp2 - psi[line_num][idx]*temp3)
              / (temp1*temp2 - temp3*temp3);
        beta = - (psi[line_num][idx]*temp1 - phi[line_num][idx]*temp3)
             / (temp1*temp2 - temp3*temp3);
    
        position_vector2_x = X[0] + alpha*phix + beta*psix;
        position_vector2_y = X[1] + alpha*phiy + beta*psiy;
        position_vector2_z = X[2] + alpha*phiz + beta*psiz;
    
        // position of line_num dislocation taken with respect
        // from the dislocatione line which force is being calculated
        relative_position_x = -(position_vector1_x - position_vector2_x);
        relative_position_y = -(position_vector1_y - position_vector2_y);
        relative_position_z = -(position_vector1_z - position_vector2_z);
    
        // compute the absolute distance between dislocations
        abs_distance = sqrt((relative_position_x)*(relative_position_x)
                           +(relative_position_y)*(relative_position_y)
                           +(relative_position_z)*(relative_position_z));
    
        if (abs_distance < 2.0*rxn_dist_tol && tangent_vectors_dot > 0) {
          // check if reaction is favorable based on Frank's rule
          double b_sum_x = b_x[line_handle] + b_x[line_num];
          double b_sum_y = b_y[line_handle] + b_y[line_num];
          double b_sum_z = b_z[line_handle] + b_z[line_num];
          double b_sum_magnitude = b_sum_x*b_sum_x + b_sum_y*b_sum_y
                                 + b_sum_z*b_sum_z;
          double b1_magnitude = b_x[line_handle]*b_x[line_handle] 
                              + b_y[line_handle]*b_y[line_handle] 
                              + b_z[line_handle]*b_z[line_handle];
          double b2_magnitude = b_x[line_num]*b_x[line_num] 
                              + b_y[line_num]*b_y[line_num] 
                              + b_z[line_num]*b_z[line_num];
          if (b_sum_magnitude < b1_magnitude + b2_magnitude) {
            if (abs_distance < rxn_dist_tol)
              rxn_status = 1;
            else
              rxn_status = 2;
          } 
        } // end of tangent_vectors_dot > 0
        if (abs_distance < 2.0*rxn_dist_tol && tangent_vectors_dot < 0) {
          // check if reaction is favorable based on Frank's rule
          double b_sum_x = b_x[line_handle] - b_x[line_num];
          double b_sum_y = b_y[line_handle] - b_y[line_num];
          double b_sum_z = b_z[line_handle] - b_z[line_num];
          double b_sum_magnitude = b_sum_x*b_sum_x + b_sum_y*b_sum_y
                                    + b_sum_z*b_sum_z;
          double b1_magnitude = b_x[line_handle]*b_x[line_handle] 
                              + b_y[line_handle]*b_y[line_handle] 
                              + b_z[line_handle]*b_z[line_handle];
          double b2_magnitude = b_x[line_num]*b_x[line_num] 
                              + b_y[line_num]*b_y[line_num] 
                              + b_z[line_num]*b_z[line_num];
          if (b_sum_magnitude < b1_magnitude + b2_magnitude) {
            if (abs_distance < rxn_dist_tol)
              rxn_status = -1;
            else
              rxn_status = -2;
          }
        } // end of tangent_vectors_dot < 0
      } // end of calculate distance and check against reaction tolerance
      
      if (rxn_status != 0)
        rxn_line_num = line_num; // set the line number for the reacting
                                    // dislocation once reaction is confirmed

    } // end of if line_num is not line_handle
  } // end of for-loop to loop through number of dislocations lines

  // free memory allocated for burgers vectors
  delete [] b_x;
  delete [] b_y;
  delete [] b_z;

  return rxn_status; 

}

} // end LSMDD namespace

