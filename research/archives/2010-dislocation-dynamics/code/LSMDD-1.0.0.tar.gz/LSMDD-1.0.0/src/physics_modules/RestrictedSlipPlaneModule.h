/*
 * File:        RestrictedSlipPlaneModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   S.S. Jerry Quek, Kevin T. Chu
 * Revision:    $Revision: 317 $
 * Modified:    $Date: 2007-07-06 23:22:25 -0400 (Fri, 06 Jul 2007) $
 * Description: Header file for the RestrictedSlipPlaneModule class
 */

/*! \file RestrictedSlipPlaneModule.h */

#ifndef included_RestrictedSlipPlaneModule_h
#define included_RestrictedSlipPlaneModule_h

/*! \class LSMDD::RestrictedSlipPlaneModule
 *
 * \brief
 * The RestrictedSlipPlaneModule provides a collection of methods
 * for velocities on dislocation lines when dislocation motion is 
 * restricted to specified slip planes.
 * 
 */

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "IntVector.h"

// LSMDD Headers
#include "LSMDD_config.h"

// namespaces
using namespace SAMRAI;
using namespace hier;


/******************************************************************
 *
 * RestrictedSlipPlaneModule Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class RestrictedSlipPlaneModule
{
public:

  /*!
   * findSlipPlaneForDislocationSegment() determines which of the given 
   * set of slip planes a dislocation segment most closely lies on.
   *
   * Arguments:
   *  - tangent_dot_slip_plane_normal (out):  dot product of tangent
   *                                          vector with the normal 
   *                                          vector for the nearest
   *                                          slip plane
   *  - b_x, b_y, b_z (in):                   Burgers vector of
   *                                          dislocation segment
   *  - tangent_vector_* (in):                components of tangent
   *                                          vector for dislocation 
   *                                          segment
   *  - slip_planes (in):                     unit normal vectors for 
   *                                          slip planes to check
   *  - num_slip_planes (in):                 number of slip planes
   *                                          to check
   *  - burgers_vector_in_plane_tol (in):     upper limit of cos(theta)
   *                                          for considering the Burgers 
   *                                          vector to be in a slip
   *                                          plane, where theta is the
   *                                          angle between the Burgers
   *                                          vector and the normal to
   *                                          the slip plane
   *
   * Return value:                            index of slip plane
   *                                          on which the tangent
   *                                          vector has the largest
   *                                          projection
   *
   * NOTES:
   * - slip_planes is a two-dimensional array where the first
   *   index indicates the slip plane and the second index 
   *   indicates the component of the normal vector.  For example, 
   *   the x-, y-, and z-components of the i-th slip plane should
   *   reside in slip_plane[i][0], slip_plane[i][1], and 
   *   slip_plane[i][2] respectively.
   *
   * - The normal vectors for the slip planes MUST be normalized
   *   to have length one.  Otherwise, numerical errors could result.
   *
   */
  static int findSlipPlaneForDislocationSegment(
    double &tangent_dot_slip_plane_normal,
    double b_x, double b_y, double b_z,
    double tangent_vector_x,
    double tangent_vector_y,
    double tangent_vector_z,
    double **slip_planes,
    int num_slip_planes,
    double burgers_vector_in_plane_tol);

  /*!
   * computeVelocityWithSlipPlaneRestrictions() computes the velocity
   * on a dislocation line segment when the motion of dislocations
   * is restricted to specific slip planes (e.g. crystallographic
   * slip planes).
   *
   * Arguments:
   *  - velocity_* (out):                   components of velocity on 
   *                                        dislocation line segment
   *  - force_* (in):                       components of force on 
   *                                        dislocation line segment
   *  - b_x, b_y, b_z (in):                 Burgers vector of dislocation
   *  - tangent_vector_* (in):              segment components of tangent
   *                                        vector for dislocation line 
   *                                        segment
   *  - tangent_vector_data_* (in):         components of tangent vector data
   *                                        (at all grid points) for 
   *                                        dislocation line
   *  - idx_i, idx_j, idx_k (in):           grid index of cell for which 
   *                                        to compute velocity
   *  - tangent_vector_ghostbox_dims (in):  dimensions of ghostbox 
   *                                        for tangent vector data
   *  - slip_planes (in):                   unit normal vectors for 
   *                                        slip planes 
   *  - num_slip_planes (in):               number of slip planes
   *  - glide_mobility (in):                glide mobility for dislocations
   *  - climb_mobility (in):                climb mobility for dislocations
   *  - max_angle_for_pure_screw (in):      maximum angle between the Burgers
   *                                        vector and tangent vector for
   *                                        considering a dislocation line
   *                                        segment to be pure screw
   *  - out_of_slip_plane_tol (in):         tolerance on angle between 
   *                                        dislocation segment and normal
   *                                        to slip plane in order to 
   *                                        consider the dislocation 
   *                                        segment as lying in the 
   *                                        slip plane
   *  - correction_speed (in):              magnitude of correction speed
   *                                        used to sharpen corners where 
   *                                        dislocation line has 
   *                                        cross-slipped into two different
   *                                        slip planes
   *  - X (in):                             coordinates of position of
   *                                        center of grid cell where
   *                                        velocity is being computed
   *  - dX (in):                            grid spacing
   *  - verbose_mode (in):                  flag indicating whether status
   *                                        information should be output
   *                                        (default = false)
   *
   * Return value:                          none
   *
   * NOTES:
   * - slip_planes is a two-dimensional array where the first
   *   index indicates the slip plane and the second index 
   *   indicates the component of the normal vector.  For example, 
   *   the x-, y-, and z-components of the i-th slip plane should
   *   reside in slip_plane[i][0], slip_plane[i][1], and 
   *   slip_plane[i][2] respectively.
   *
   * - The normal vectors for the slip planes MUST be normalized
   *   to have length one.  Otherwise, numerical errors could result.
   *
   */
  static void computeVelocityWithSlipPlaneRestrictions(
    double &velocity_x,
    double &velocity_y,
    double &velocity_z,
    double force_x, double force_y, double force_z,
    double b_x, double b_y, double b_z,
    double tangent_vector_x,
    double tangent_vector_y,
    double tangent_vector_z,
    double *tangent_vector_data_x,
    double *tangent_vector_data_y,
    double *tangent_vector_data_z,
    const IntVector<3>& tangent_vector_ghostbox_dims,
    int tangent_idx_i,
    int tangent_idx_j,
    int tangent_idx_k,
    double **slip_planes,
    int num_slip_planes,
    double glide_mobility,
    double climb_mobility,
    double max_angle_for_pure_screw,
    double out_of_slip_plane_tol,
    double correction_speed,
    const double *X,
    const double *dX,
    bool verbose_mode = false);


private:

  /*
   * Private default constructor to prevent use.
   *
   * Arguments:  none
   *
   */
  RestrictedSlipPlaneModule(){}

  /*
   * Private copy constructor to prevent use.
   *
   * Arguments:
   *  - rhs (in):  RestrictedSlipPlaneModule object to copy
   *
   */
  RestrictedSlipPlaneModule(const RestrictedSlipPlaneModule& rhs){}

  /*
   * Private assignment operator to prevent use.
   *
   * Arguments:
   *  - rhs (in):   RestrictedSlipPlaneModule object to copy
   *
   * Return value:  *this
   *
   */
  const RestrictedSlipPlaneModule& operator=(
    const RestrictedSlipPlaneModule& rhs){ return *this; }

};

} // end LSMDD namespace


#endif
