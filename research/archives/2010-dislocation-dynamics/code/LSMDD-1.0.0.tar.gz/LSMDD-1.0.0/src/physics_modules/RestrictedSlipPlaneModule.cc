/*
 * File:        RestrictedSlipPlaneModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   S.S. Jerry Quek, Kevin T. Chu
 * Revision:    $Revision: 317 $
 * Modified:    $Date: 2007-07-06 23:22:25 -0400 (Fri, 06 Jul 2007) $
 * Description: Implementation file for the RestrictedSlipPlaneModule class
 */

#include "RestrictedSlipPlaneModule.h"

// system headers
#include <float.h>

// SAMRAI Headers
#include "CellData.h"
#include "CartesianPatchGeometry.h"

// LSMDD Headers
#include "LSMDD_Utilities.h"

// namespaces
using namespace tbox;
using namespace pdat;

// Macros and Constants
#define CRYSTALLOGRAPHY_ZERO_TOL  (1e-8)


namespace LSMDD {


int RestrictedSlipPlaneModule::findSlipPlaneForDislocationSegment(
  double &tangent_dot_slip_plane_normal,
  double b_x, double b_y, double b_z,
  double tangent_vector_x,
  double tangent_vector_y,
  double tangent_vector_z,
  double **slip_planes,
  int num_slip_planes,
  double burgers_vector_in_plane_tol)
{
  // cache square of norm of Burgers vector 
  double norm_b_sq = b_x*b_x + b_y*b_y + b_z*b_z;
  
  // we actually need a limit on cos(theta)^2, so square
  // burgers_vector_in_plane_tol
  burgers_vector_in_plane_tol *= burgers_vector_in_plane_tol;

  int slip_plane_idx = -1;
  tangent_dot_slip_plane_normal = DBL_MAX;
  double abs_tangent_dot_slip_plane_normal = DBL_MAX;
  for (int i = 0; i < num_slip_planes; i++) {
    // check that slip-plane contains the Burgers vector
    double b_dot_n_sq = b_x*slip_planes[i][0] 
                      + b_y*slip_planes[i][1]
                      + b_z*slip_planes[i][2];
    b_dot_n_sq *= b_dot_n_sq;

    if ( b_dot_n_sq < norm_b_sq*burgers_vector_in_plane_tol ) {
      // case: Burgers vector lies in current slip plane

      double next_tangent_dot_slip_plane_normal = 
          tangent_vector_x*slip_planes[i][0] 
        + tangent_vector_y*slip_planes[i][1]
        + tangent_vector_z*slip_planes[i][2];

      if ( fabs(next_tangent_dot_slip_plane_normal) < 
           abs_tangent_dot_slip_plane_normal ) {
        slip_plane_idx = i;
        tangent_dot_slip_plane_normal = next_tangent_dot_slip_plane_normal;
        abs_tangent_dot_slip_plane_normal = fabs(tangent_dot_slip_plane_normal);
      }
    } // end case: slip-plane contains Burgers vector 
  }

  return slip_plane_idx;
}

void RestrictedSlipPlaneModule::computeVelocityWithSlipPlaneRestrictions(
  double &velocity_x,
  double &velocity_y,
  double &velocity_z,
  double force_x, double force_y, double force_z,
  double b_x, double b_y, double b_z,
  double tangent_vector_x,
  double tangent_vector_y,
  double tangent_vector_z,
  double *tangent_vector_data_x,
  double *tangent_vector_data_y,
  double *tangent_vector_data_z,
  const IntVector<3>& tangent_vector_ghostbox_dims,
  int idx_i, int idx_j, int idx_k,
  double **slip_planes,
  int num_slip_planes,
  double glide_mobility,
  double climb_mobility,
  double max_angle_for_pure_screw,
  double out_of_slip_plane_tol,
  double correction_speed,
  const double *X,
  const double *dX,
  bool verbose_mode)
{
  if (verbose_mode) {
    plog << "computeVelocityWithSlipPlaneRestrictions():"
         << endl;
    plog << "  position = ("
         << X[0] << ","
         << X[1] << ","
         << X[2] << ")" << endl;
  }

  /* 
   * determine which crystallographic slip-plane dislocation line 
   * segment lies within 
   */
  double tangent_dot_slip_plane_normal = DBL_MAX;
  int slip_plane_idx = findSlipPlaneForDislocationSegment(
    tangent_dot_slip_plane_normal,
    b_x, b_y, b_z,
    tangent_vector_x, tangent_vector_y, tangent_vector_z,
    slip_planes, num_slip_planes, 1e-8);
  if (slip_plane_idx < 0) {
    TBOX_ERROR(  "RestrictedSlipPlaneModule::"
              << "computeVelocityWithSlipPlaneRestrictions(): "
              << "none of the slip planes contain the Burgers "
              << "vector AND the dislocation line segment" );
  }

  // project tangent onto slip-plane and normalize
  double proj_tangent_x = tangent_vector_x -
    tangent_dot_slip_plane_normal*slip_planes[slip_plane_idx][0];
  double proj_tangent_y = tangent_vector_y -
    tangent_dot_slip_plane_normal*slip_planes[slip_plane_idx][1];
  double proj_tangent_z = tangent_vector_z -
    tangent_dot_slip_plane_normal*slip_planes[slip_plane_idx][2];
  double norm_proj_tangent = sqrt( proj_tangent_x*proj_tangent_x
                                 + proj_tangent_y*proj_tangent_y
                                 + proj_tangent_z*proj_tangent_z );
  if (norm_proj_tangent > 1.0e-8) {
    double inv_norm_proj_tangent = 1.0/norm_proj_tangent;
    proj_tangent_x *= inv_norm_proj_tangent;
    proj_tangent_y *= inv_norm_proj_tangent;
    proj_tangent_z *= inv_norm_proj_tangent;
  } else {
    TBOX_WARNING("RestrictedSlipPlaneModule::"
              << "computeVelocityWithSlipPlaneRestrictions(): "
              << "length of projected tangent vector near zero..."
              << "it looks like the slip plane is incorrectly computed"
              << endl);
  }

  // check if dislocation segment is pure screw based on the
  // projected tangent vector
  bool segment_is_pure_screw = false;
  CHECK_FOR_PURE_SCREW_SCREW_DISLOCATION(
    segment_is_pure_screw, max_angle_for_pure_screw,
    b_x, b_y, b_z,
    proj_tangent_x, 
    proj_tangent_y,
    proj_tangent_z);

  if (segment_is_pure_screw) {
                  
    // case: pure screw dislocation
    if (verbose_mode) {
      plog << "  SCREW DISLOCATION" << endl;
    }

    // remove component of force tangent to dislocation line
    double tangent_force_magnitude = force_x*proj_tangent_x
                                   + force_y*proj_tangent_y
                                   + force_z*proj_tangent_z;
    double normal_force_x = 
      force_x - tangent_force_magnitude*proj_tangent_x;
    double normal_force_y = 
      force_y - tangent_force_magnitude*proj_tangent_y;
    double normal_force_z = 
      force_z - tangent_force_magnitude*proj_tangent_z;

    // find slip-plane with largest force projection
    double abs_f_dot_slip_plane_normal = DBL_MAX;
    velocity_x = 0.0;
    velocity_y = 0.0;
    velocity_z = 0.0;
    for (int i = 0; i < num_slip_planes; i++) {

      // check that slip-plane contains the Burgers vector
      if ( fabs( b_x*slip_planes[i][0] 
               + b_y*slip_planes[i][1]
               + b_z*slip_planes[i][2] ) < 1.0e-8 ) {

        double f_dot_slip_plane_normal = 
            normal_force_x*slip_planes[i][0] 
          + normal_force_y*slip_planes[i][1]
          + normal_force_z*slip_planes[i][2];

        if ( fabs(f_dot_slip_plane_normal) < 
             abs_f_dot_slip_plane_normal ) {
          abs_f_dot_slip_plane_normal = fabs(f_dot_slip_plane_normal);

          // compute velocity for current slip-plane because 
          // the force has a larger projection onto it 
          velocity_x = glide_mobility
                     *(force_x-f_dot_slip_plane_normal*slip_planes[i][0]);
          velocity_y = glide_mobility
                     *(force_y-f_dot_slip_plane_normal*slip_planes[i][1]);
          velocity_z = glide_mobility
                     *(force_z-f_dot_slip_plane_normal*slip_planes[i][2]);

        }
      }
    } // end loop over slip planes

  } else { 

    // case: mixed dislocation
    if (verbose_mode) {
      plog << "  MIXED DISLOCATION" << endl;
    }

    // compute the component of the Burgers vector 
    // normal to projected dislocation line
    double b_dot_tangent = b_x*proj_tangent_x
                         + b_y*proj_tangent_y
                         + b_z*proj_tangent_z;
    double b_normal_x = b_x - b_dot_tangent*proj_tangent_x;
    double b_normal_y = b_y - b_dot_tangent*proj_tangent_y;
    double b_normal_z = b_z - b_dot_tangent*proj_tangent_z;
    double b_normal_length = sqrt( b_normal_x*b_normal_x 
                                 + b_normal_y*b_normal_y 
                                 + b_normal_z*b_normal_z );

    // normalize b_normal for projection purposes
    double inv_b_normal_length = 1.0/b_normal_length; 
    b_normal_x *= inv_b_normal_length;
    b_normal_y *= inv_b_normal_length;
    b_normal_z *= inv_b_normal_length;

    // compute component of force that contributes to glide 
    double glide_force_magnitude = force_x*b_normal_x
                                 + force_y*b_normal_y
                                 + force_z*b_normal_z;
 
    // compute component of force tangent to dislocation
    // line so its contribution can be removed from
    // velocity calculation
    double tangent_force_magnitude = force_x*proj_tangent_x
                                   + force_y*proj_tangent_y
                                   + force_z*proj_tangent_z;

    // compute velocity due to glide and climb
    // force
    velocity_x = glide_mobility*glide_force_magnitude*b_normal_x
     + climb_mobility*( force_x - glide_force_magnitude*b_normal_x
                      - tangent_force_magnitude*proj_tangent_x);
    velocity_y = glide_mobility*glide_force_magnitude*b_normal_y
      + climb_mobility*( force_y - glide_force_magnitude*b_normal_y
                       - tangent_force_magnitude*proj_tangent_y);
    velocity_z = glide_mobility*glide_force_magnitude*b_normal_z
      + climb_mobility*( force_z - glide_force_magnitude*b_normal_z
                       - tangent_force_magnitude*proj_tangent_z);

    // if dislocation line is out of slip plane, then add
    // correction velocity to sharpen dislocation corner
    if (fabs(tangent_dot_slip_plane_normal) > out_of_slip_plane_tol) {

      /*
       * compute velocity correction using the direction of 
       * the gradient of (tangent dot slip-plane normal) to 
       * determine if the dislocation line is approaching or 
       * leaving the slip plane.
       */
      int idx_plus, idx_minus;
      double t_dot_n_plus;
      double t_dot_n_minus;

      // compute x-component of grad(tangent dot slip-plane normal)
      idx_plus  = (idx_i+1) + idx_j*tangent_vector_ghostbox_dims(0)
                + idx_k*tangent_vector_ghostbox_dims(0)
                       *tangent_vector_ghostbox_dims(1);
      idx_minus = (idx_i-1) + idx_j*tangent_vector_ghostbox_dims(0)
                + idx_k*tangent_vector_ghostbox_dims(0)
                       *tangent_vector_ghostbox_dims(1);
      t_dot_n_plus  = 
          tangent_vector_data_x[idx_plus]*slip_planes[slip_plane_idx][0]
        + tangent_vector_data_y[idx_plus]*slip_planes[slip_plane_idx][1]
        + tangent_vector_data_z[idx_plus]*slip_planes[slip_plane_idx][2];
      t_dot_n_minus =
          tangent_vector_data_x[idx_minus]*slip_planes[slip_plane_idx][0]
        + tangent_vector_data_y[idx_minus]*slip_planes[slip_plane_idx][1]
        + tangent_vector_data_z[idx_minus]*slip_planes[slip_plane_idx][2];
      double grad_t_dot_n_x = 0.5*(t_dot_n_plus-t_dot_n_minus)/dX[0];

      // compute y-component of grad(tangent dot slip-plane normal)
      idx_plus  = idx_i + (idx_j+1)*tangent_vector_ghostbox_dims(0)
                + idx_k*tangent_vector_ghostbox_dims(0)
                       *tangent_vector_ghostbox_dims(1);
      idx_minus = idx_i + (idx_j-1)*tangent_vector_ghostbox_dims(0)
                + idx_k*tangent_vector_ghostbox_dims(0)
                       *tangent_vector_ghostbox_dims(1);
      t_dot_n_plus  = 
          tangent_vector_data_x[idx_plus]*slip_planes[slip_plane_idx][0]
        + tangent_vector_data_y[idx_plus]*slip_planes[slip_plane_idx][1]
        + tangent_vector_data_z[idx_plus]*slip_planes[slip_plane_idx][2];
      t_dot_n_minus =
          tangent_vector_data_x[idx_minus]*slip_planes[slip_plane_idx][0]
        + tangent_vector_data_y[idx_minus]*slip_planes[slip_plane_idx][1]
        + tangent_vector_data_z[idx_minus]*slip_planes[slip_plane_idx][2];
      double grad_t_dot_n_y = 0.5*(t_dot_n_plus-t_dot_n_minus)/dX[1];

      // compute z-component of grad(tangent dot slip-plane normal)
      idx_plus  = idx_i + idx_j*tangent_vector_ghostbox_dims(0)
                + (idx_k+1)*tangent_vector_ghostbox_dims(0)
                           *tangent_vector_ghostbox_dims(1);
      idx_minus = idx_i + idx_j*tangent_vector_ghostbox_dims(0)
                + (idx_k-1)*tangent_vector_ghostbox_dims(0)
                           *tangent_vector_ghostbox_dims(1);
      t_dot_n_plus  = 
          tangent_vector_data_x[idx_plus]*slip_planes[slip_plane_idx][0]
        + tangent_vector_data_y[idx_plus]*slip_planes[slip_plane_idx][1]
        + tangent_vector_data_z[idx_plus]*slip_planes[slip_plane_idx][2];
      t_dot_n_minus =
          tangent_vector_data_x[idx_minus]*slip_planes[slip_plane_idx][0]
        + tangent_vector_data_y[idx_minus]*slip_planes[slip_plane_idx][1]
        + tangent_vector_data_z[idx_minus]*slip_planes[slip_plane_idx][2];
      double grad_t_dot_n_z = 0.5*(t_dot_n_plus-t_dot_n_minus)/dX[2];

      double norm_grad_t_dot_n = sqrt(grad_t_dot_n_x*grad_t_dot_n_x
                                     +grad_t_dot_n_y*grad_t_dot_n_y
                                     +grad_t_dot_n_z*grad_t_dot_n_z);

      double sgn = 0.0;
      double grad_t_dot_n_dot_proj_tangent =
          grad_t_dot_n_x*proj_tangent_x
        + grad_t_dot_n_y*proj_tangent_y
        + grad_t_dot_n_z*proj_tangent_z;
      if (grad_t_dot_n_dot_proj_tangent 
         > norm_grad_t_dot_n*CRYSTALLOGRAPHY_ZERO_TOL) 
      {
        sgn = 1.0;
      } else {
        sgn = -1.0;
      }

      if (tangent_dot_slip_plane_normal < 0) {
        sgn = -sgn;
      }

      velocity_x += sgn*correction_speed*proj_tangent_x;
      velocity_y += sgn*correction_speed*proj_tangent_y;
      velocity_z += sgn*correction_speed*proj_tangent_z;

    } // end case: dislocation line segment is out of slip plane

  } // end switch on screw vs. non-screw dislocation line

}

} // end LSMDD namespace
