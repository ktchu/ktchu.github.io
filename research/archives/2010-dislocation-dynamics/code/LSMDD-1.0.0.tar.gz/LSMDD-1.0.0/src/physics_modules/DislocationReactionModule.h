/*
 * File:        DislocationReactionModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   S.S. Jerry Quek, Kevin T. Chu
 * Revision:    $Revision:  $
 * Modified:    $Date: $
 * Description: Header file for DislocationReactionModule
 */

#ifndef included_DislocationReactionModule_h
#define included_DislocationReactionModule_h

/*! \class LSMDD::DislocationReactionModule
 *
 * \brief
 * The DislocationReactionModule provides a collection of methods 
 * for simulating dislocation reaction physics.
 *
 *
 * <h3> USAGE: </h3>
 *
 * - Add the two integer data members d_rxn_status_handle 
 *   and d_rxn_line_number_handle to the user-defined
 *   subclass of LSMDD_PhysicsStrategy.
 *
 * - Set d_rxn_status_handle and d_rxn_line_number_handle 
 *   by using setupReactionData().  Note that both  
 *   d_rxn_status_handle and d_rxn_line_number_handle are
 *   passed by reference.
 *
 * - Modify preprocessAdvanceDislocations() and
 *   postprocessAdvanceDislocations() in the LSMDD_PhysicsStrategy
 *   class to respectively allocate and deallocate reaction data.  
 *   Allocation and deallocation of reaction data is handled by the 
 *   allocateReactionData() and deallocateReactionData() methods.
 *
 * - Modify LSMDD_PhysicsStategy::computeForceOnDislocationOnPatch() 
 *   to use computeForceOnDislocationLineWithReactions() to compute 
 *   the force at each grid point account for dislocation reactions
 *   between two dislocation lines.
 *
 * - Modify LSMDD_PhysicsStrategy::computeVelocityForDislocationLineOnPatch()
 *   to use the reaction status and reaction line information generated 
 *   by computeForceOnDislocationLineWithReactions() when computing
 *   the Burgers vector that should be used when computing the velocity
 *   of each dislocation segment.  This requires extracting the reaction 
 *   data PatchData, index space, etc.  
 * 
 * 
 * <h3> NOTES: </h3>
 * - This class currently only supports dislocation reactions 
 *   involving exactly two dislocation lines.
 * 
 */



// System Headers
#include <string>

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "PatchHierarchy.h"
#include "tbox/Array.h"
 
// LSMDD Headers
#include "LSMDD_config.h"
#include "BurgersVector.h"
#include "LSMDD_Parameters.h"

// namespaces
using namespace SAMRAI;
using namespace hier;
using namespace tbox;


/******************************************************************
 *
 * DislocationReactionModule Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class DislocationReactionModule
{
public:

  /*!
   * setupReactionData() creates the SAMRAI PatchData required to 
   * support detection of reactions and computation of forces and 
   * velocities in the presence of dislocation reactions.
   *
   * This method should be called in the constructor of the 
   * user-defined subclass of LSMDD_PhysicsStrategy.
   *
   * Arguments:
   *  - rxn_status_handle (out):       PatchData handle for 
   *                                   integer status data
   *  - rxn_line_number_handle (out):  PatchData handle for 
   *                                   integer data that stores
   *                                   which dislocation line
   *                                   reacts with the dislocation
   *                                   line whose forces and 
   *                                   velocities are currently 
   *                                   being computed
   *
   * Return value:                     none
   *
   */
  static void setupReactionData(int& rxn_status_handle, 
                                int& rxn_line_number_handle);

  /*!
   * allocateReactionData() allocates the data required to support
   * simulation of dislocation reactions.
   *
   * This method should be called in the preprocessAdvanceDislocations()
   * method of the user-defined subclass of LSMDD_PhysicsStrategy.
   *
   * Arguments:
   *  - hierarchy (in):               PatchHierarchy containing
   *                                  data
   *  - rxn_status_handle (in):       PatchData handle for 
   *                                  integer status data
   *  - rxn_line_number_handle (in):  PatchData handle for 
   *                                  integer data that stores
   *                                  which dislocation line
   *                                  reacts with the dislocation
   *                                  line whose forces and 
   *                                  velocities are currently 
   *                                  being computed
   *
   * Return value:                    none
   *
   */
  static void allocateReactionData(PatchHierarchy<3>& hierarchy,
                                   int& rxn_status_handle, 
                                   int& rxn_line_number_handle);

  /*!
   * deallocateReactionData() deallocates the data required to support
   * simulation of dislocation reactions.
   *
   * This method should be called in the postprocessAdvanceDislocations()
   * method of the user-defined subclass of LSMDD_PhysicsStrategy.
   *
   * Arguments:
   *  - hierarchy (in):               PatchHierarchy containing
   *                                  data
   *  - rxn_status_handle (in):       PatchData handle for 
   *                                  integer status data
   *  - rxn_line_number_handle (in):  PatchData handle for 
   *                                  integer data that stores
   *                                  which dislocation line
   *                                  reacts with the dislocation
   *                                  line whose forces and 
   *                                  velocities are currently 
   *                                  being computed
   *
   * Return value:                    none
   *
   */
  static void deallocateReactionData(PatchHierarchy<3>& hierarchy,
                                     int& rxn_status_handle, 
                                     int& rxn_line_number_handle);

  /*!
   * computeForceOnDislocationLineWithReactions() computes the force
   * on the dislocation line associated with line_handle taking into 
   * account reactions with other dislocation lines. 
   *
   * Arguments:
   *  - force_* (out):                       components of force at current
   *                                         grid point
   *  - rxn_line_num (out):                  if there is a reaction, this
   *                                         argument is set to the line 
   *                                         handle of dislocation line that
   *                                         reacts with the dislocation
   *                                         corresponding to line_handle;
   *                                         otherwise it is set to 
   *                                         line_handle
   *  - phi_data (in):                       array of pointers to data arrays 
   *                                         for phi
   *  - psi_data (in):                       array of pointers to data arrays 
   *                                         for psi
   *  - tangent_vectors_x (in):              x-components of tangent vector 
   *                                         of all dislocation lines at the
   *                                         current grid point
   *  - tangent_vectors_y (in):              y-components of tangent vector 
   *                                         of all dislocation lines at the
   *                                         current grid point
   *  - tangent_vectors_z (in):              z-components of tangent vector 
   *                                         of all dislocation lines at the
   *                                         current grid point
   *  - burgers_vectors (in):                Array of BurgersVector
   *                                         objects
   *  - sigma* (in):                         components of stress at current
   *                                         grid point
   *  - level_set_fcn_box_dims (in):         integer array of dimensions of
   *                                         grid (including ghostcells) for 
   *                                         level set function data
   *  - level_set_fcn_ghostcell_width (in):  integer array containing the
   *                                         width of the ghostcell layer 
   *                                         in each coordinate direction
   *  - i, j, k (in):                        index of grid position within 
   *                                         the patch (relative to the lower
   *                                         corner of the patch)
   *  - X (in):                              physical coordinates of center
   *                                         of current grid cell
   *                                         grid position
   *  - dX (in):                             grid spacing in the three 
   *                                         directions
   *  - line_handle (in):                    handle for the dislocation line 
   *                                         for which to compute force
   *  - lsmdd_params (in):                   parameters for dislocation 
   *                                         dynamics simulation
   *  - interaction_force_strength (in):     strength of interaction force
   *
   * Return value:                           reaction status (minus sign 
   *                                           indicates 180deg opposite 
   *                                           tangent vectors):
   *                                         0 -> no reaction
   *                                         1 or -1 -> reaction (b=b1+b2)
   *                                         2 or -2 -> interpolate force 
   *                                                    between rxn and
   *                                                    no rxn cases
   *
   * NOTES:
   * - This method currently only supports dislocation reactions involving
   *   exactly two dislocation lines.
   *
   */
  static int computeForceOnDislocationLineWithReactions(
    double &force_x,
    double &force_y,
    double &force_z,
    int &rxn_line_num,
    double **phi_data,
    double **psi_data,
    double *tangent_vectors_x,
    double *tangent_vectors_y,
    double *tangent_vectors_z,
    Array< BurgersVector >& burgers_vectors,
    double sigma11,
    double sigma22,
    double sigma33,
    double sigma23,
    double sigma31,
    double sigma12,
    int *level_set_fcn_box_dims,
    int *level_set_fcn_ghostcell_width,
    int idx_x,
    int idx_y,
    int idx_z,
    const double *X,
    const double *dX,
    const int line_handle,
    const LSMDD_Parameters& lsmdd_params,
    double interaction_force_strength);


protected:

  /*!
   * checkForReaction() determines whether there is a dislocation 
   * reaction involving the dislocation associated with line_handle.
   * It returns 0 if there is no reaction and 1 or 2 if there has
   * been a reaction.  checkForReaction() also returns the dislocation 
   * line that reacts with the dislocation line associated with 
   * line_handle and the relative position of the reacting segment 
   * via arguments that are passed by reference.
   *
   * Arguments:
   *  - rxn_line_num (out):                  if there is a reaction, this
   *                                         argument is set to the line 
   *                                         handle of dislocation line that
   *                                         reacts with the dislocation
   *                                         corresponding to line_handle;
   *                                         otherwise it is set to 
   *                                         line_handle
   *  - relative_position_x (out):           relative x-direction of reacting 
   *                                         segment to dislocation
   *  - relative_position_y (out):           relative y-direction of 
   *                                         reacting segment to dislocation
   *  - relative_position_z (out):           relative z-direction of 
   *                                         reacting segment to dislocation
   *  - phi_data (in):                       array of pointers to data arrays 
   *                                         for phi
   *  - psi_data (in):                       array of pointers to data arrays 
   *                                         for psi
   *  - tangent_vectors_x (in):              x-components of tangent vector 
   *                                         of all dislocation lines at the
   *                                         current grid point
   *  - tangent_vectors_y (in):              y-components of tangent vector 
   *                                         of all dislocation lines at the
   *                                         current grid point
   *  - tangent_vectors_z (in):              z-components of tangent vector 
   *                                         of all dislocation lines at the
   *                                         current grid point
   *  - burgers_vectors (in):                Array of BurgersVector
   *                                         objects
   *                                         (size of array is the number of 
   *                                         dislocations involved in reaction
   *                                         - currently only reactions 
   *                                         between 2 dislocations considered)
   *  - level_set_fcn_box_dims (in):         integer array of dimensions of
   *                                         local grid (including ghostcells)
   *                                         for level set function data
   *  - level_set_fcn_ghostcell_width (in):  integer array containing the
   *                                         width of the ghostcell layer 
   *                                         in each coordinate direction
   *  - i, j, k (in):                        index of grid position within 
   *                                         the patch (relative to the lower
   *                                         corner of the patch)
   *  - X (in):                              physical coordinates of center
   *                                         of current grid cell
   *  - dX (in):                             grid spacing in the three 
   *                                         spatial directions
   *  - line_handle (in):                    handle for the dislocation line 
   *                                         for which to check for reactions
   *  - lsmdd_params (in):                   parameters for dislocation 
   *                                         dynamics simulation
   *
   * Return value:                           reaction status (minus sign 
   *                                         indicates 180deg opposite 
   *                                         tangent vectors):
   *                                           0 -> no reaction
   *                                           1 or -1 -> reaction (b=b1+b2)
   *                                           2 or -2 -> interpolate force 
   *                                                      between react and
   *                                                      no react
   *
   */
  static int checkForReaction(
    int& rxn_line_num,
    double& relative_position_x,
    double& relative_position_y,
    double& relative_position_z,
    double **phi_data,
    double **psi_data,
    double *tangent_vectors_x,
    double *tangent_vectors_y,
    double *tangent_vectors_z,
    Array< BurgersVector >& burgers_vectors,
    int *level_set_fcn_box_dims,
    int *level_set_fcn_ghostcell_width,
    int idx_x,
    int idx_y,
    int idx_z,
    const double *X,
    const double *dX,
    const int line_handle,
    const LSMDD_Parameters& lsmdd_params);


private:

  /*
   * Private default constructor to prevent use.
   *
   * Arguments:  none
   *
   */
  DislocationReactionModule(){}

  /* 
   * Private copy constructor to prevent use.
   * 
   * Arguments:
   *  - rhs (in):  DislocationReactionModule object to copy
   *
   */
  DislocationReactionModule(const DislocationReactionModule& rhs){}
  
  /* 
   * Private assignment operator to prevent use.
   * 
   * Arguments:
   *  - rhs (in):   DislocationReactionModule object to copy
   * 
   * Return value:  *this
   *
   */
  const DislocationReactionModule& operator=(
    const DislocationReactionModule& rhs){ return *this; }

};

} // end LSMDD namespace

#endif
