/*
 * File:        LSMDD_Utilities.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 398 $
 * Modified:    $Date: 2007-08-07 15:24:02 -0400 (Tue, 07 Aug 2007) $
 * Description: Header file for the LSMDD_Utilities class
 */

/*! \file LSMDD_Utilities.h 
 *
 * \brief
 * The LSMDD_Utilities provides a collection of macros and static 
 * methods that can be useful when computing forces and velocities 
 * on dislocation lines.
 *
 */ 

#ifndef included_LSMDD_Utilities_h
#define included_LSMDD_Utilities_h

/*! \class LSMDD::LSMDD_Utilities
 *
 * \brief
 * The LSMDD_Utilities provides a collection of macros and static 
 * methods that can be useful when computing forces and velocities 
 * on dislocation lines.
 *
 */

// LSMDD Headers
#include "LSMDD_config.h"


/******************************************************************
 *
 * LSMDD_Utilities Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class LSMDD_Utilities
{
public:


private:

  /*
   * Private default constructor to prevent use.
   *
   * Arguments:  none
   *
   */
  LSMDD_Utilities(){}

  /*
   * Private copy constructor to prevent use.
   *
   * Arguments:
   *  - rhs (in):  LSMDD_Utilities object to copy
   *
   */
  LSMDD_Utilities(const LSMDD_Utilities& rhs){}

  /*
   * Private assignment operator to prevent use.
   *
   * Arguments:
   *  - rhs (in):   LSMDD_Utilities object to copy
   *
   * Return value:  *this
   *
   */
  const LSMDD_Utilities& operator=(
    const LSMDD_Utilities& rhs){ return *this; }

};

} // end LSMDD namespace


// LSMDD_Utilities Macros 
// NOTE:  These are written as macros to ensure performance because
//        the "inline" keyword is only a suggestion to the compiler.

/*! 
 * GET_TETRAHEDRON() sets the coordinates and values of the level set
 * functions at the vertices of the specified tetrahedron within the 
 * specified cell with corners given by the centers of the cells in 
 * the index space [(i,j,k),(i+1,j+1,k+1)].  This information is used to 
 * find the dislocation line within the grid cell using the 
 * LSM3D_findLineInTetrahedron() function in the LSMLIB library.
 * 
 * Arguments:
 * - x1, x2, x3, x4 (out):    Coordinates of the four vertices of the 
 *                            tetrahedron.  These should all be double 
 *                            arrays with at least three elements.
 * - phi_tet, psi_tet (out):  double arrays storing the values of 
 *                            phi and psi at the vertices of the 
 *                            tetrahedron.
 * - tet_num (in):            integer between 0 and 5 (inclusive) 
 *                            indicating which tetrahedron within the
 *                            cell for which to extract data
 * - i, j, k (in):            grid index for grid point at lower corner
 *                            of cell containing tetrahedra
 * - X (in):                  double array holding the physical coordinates 
 *                            for the center of the grid cell with index
 *                            (i,j,k)
 * - dX (in):                 double array holding the grid spacing in
 *                            the three coordinate directions
 * - phi, psi (in):           double arrays holding the phi and psi
 *                            data for the entire Patch
 * - idx_phi, idx_psi (in):   indices of grid index (i,j,k) in linear 
 *                            data arrays for phi and psi, respectively
 * - phi_ghostbox_dims (in):  IntVector holding the dimensions of the 
 *                            ghostbox for phi
 * - psi_ghostbox_dims (in):  IntVector holding the dimensions of the 
 *                            ghostbox for psi
 *
 * NOTES:
 * - All arguments passed into this macro MUST be variables NOT 
 *   expressions.  If expressions are passed in as arguments, 
 *   this macro may yield incorrect results!
 *
 */
#define GET_TETRAHEDRON(x1, x2, x3, x4, phi_tet, psi_tet,                    \
                        tet_num, i, j, k,                                    \
                        X, dX, phi, psi, idx_phi, idx_psi,                   \
                        phi_ghostbox_dims, psi_ghostbox_dims)                \
{                                                                            \
  if ( (i+j)%2 == 0 ) {                                                      \
    switch(tet_num) {                                                        \
      case 0: {                                                              \
        x1[0]  = X[0];                                                       \
        x1[1]  = X[1];                                                       \
        x1[2]  = X[2];                                                       \
        phi_tet[0] = phi[idx_phi];                                           \
        psi_tet[0] = psi[idx_psi];                                           \
                                                                             \
        x2[0] = X[0] + dX[0];                                                \
        x2[1] = X[1] + dX[1];                                                \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi + 1 + phi_ghostbox_dims(0)];                \
        psi_tet[1] = psi[idx_psi + 1 + psi_ghostbox_dims(0)];                \
                                                                             \
        x3[0] = X[0] + dX[0];                                                \
        x3[1] = X[1];                                                        \
        x3[2] = X[2];                                                        \
        phi_tet[2] = phi[idx_phi + 1];                                       \
        psi_tet[2] = psi[idx_psi + 1];                                       \
                                                                             \
        x4[0] = X[0];                                                        \
        x4[1] = X[1];                                                        \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi +                                           \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi +                                           \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 1: {                                                              \
        x1[0] = X[0] + dX[0];                                                \
        x1[1] = X[1];                                                        \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + 1];                                       \
        psi_tet[0] = psi[idx_psi + 1];                                       \
                                                                             \
        x2[0] = X[0];                                                        \
        x2[1] = X[1];                                                        \
        x2[2] = X[2] + dX[2];                                                \
        phi_tet[1] = phi[idx_phi +                                           \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[1] = psi[idx_psi +                                           \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x3[0] = X[0] + dX[0];                                                \
        x3[1] = X[1] + dX[1];                                                \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi + 1 + phi_ghostbox_dims(0) +                \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi + 1 + psi_ghostbox_dims(0) +                \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0] + dX[0];                                                \
        x4[1] = X[1];                                                        \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + 1 +                                       \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + 1 +                                       \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 2: {                                                              \
        x1[0] = X[0] + dX[0];                                                \
        x1[1] = X[1] + dX[1];                                                \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + 1 + phi_ghostbox_dims(0)];                \
        psi_tet[0] = psi[idx_psi + 1 + psi_ghostbox_dims(0)];                \
                                                                             \
        x2[0] = X[0] + dX[0];                                                \
        x2[1] = X[1];                                                        \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi + 1];                                       \
        psi_tet[1] = psi[idx_psi + 1];                                       \
                                                                             \
        x3[0] = X[0];                                                        \
        x3[1] = X[1];                                                        \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi +                                           \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi +                                           \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0] + dX[0];                                                \
        x4[1] = X[1] + dX[1];                                                \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + 1 + phi_ghostbox_dims(0) +                \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + 1 + psi_ghostbox_dims(0) +                \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 3: {                                                              \
        x1[0] = X[0];                                                        \
        x1[1] = X[1];                                                        \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi];                                           \
        psi_tet[0] = psi[idx_psi];                                           \
                                                                             \
        x2[0] = X[0] + dX[0];                                                \
        x2[1] = X[1] + dX[1];                                                \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi + 1 + phi_ghostbox_dims(0)];                \
        psi_tet[1] = psi[idx_psi + 1 + psi_ghostbox_dims(0)];                \
                                                                             \
        x3[0] = X[0];                                                        \
        x3[1] = X[1] + dX[1];                                                \
        x3[2] = X[2];                                                        \
        phi_tet[2] = phi[idx_phi + phi_ghostbox_dims(0)];                    \
        psi_tet[2] = psi[idx_psi + psi_ghostbox_dims(0)];                    \
                                                                             \
        x4[0] = X[0];                                                        \
        x4[1] = X[1];                                                        \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi +                                           \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi +                                           \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 4: {                                                              \
        x1[0] = X[0];                                                        \
        x1[1] = X[1] + dX[1];                                                \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + phi_ghostbox_dims(0)];                    \
        psi_tet[0] = psi[idx_psi + psi_ghostbox_dims(0)];                    \
                                                                             \
        x2[0] = X[0];                                                        \
        x2[1] = X[1];                                                        \
        x2[2] = X[2] + dX[2];                                                \
        phi_tet[1] = phi[idx_phi +                                           \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[1] = psi[idx_psi +                                           \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x3[0] = X[0] + dX[0];                                                \
        x3[1] = X[1] + dX[1];                                                \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi + 1 + phi_ghostbox_dims(0) +                \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi + 1 + psi_ghostbox_dims(0) +                \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0];                                                        \
        x4[1] = X[1] + dX[1];                                                \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + phi_ghostbox_dims(0) +                    \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + psi_ghostbox_dims(0) +                    \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 5: {                                                              \
        x1[0] = X[0] + dX[0];                                                \
        x1[1] = X[1] + dX[1];                                                \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + 1 + phi_ghostbox_dims(0)];                \
        psi_tet[0] = psi[idx_psi + 1 + psi_ghostbox_dims(0)];                \
                                                                             \
        x2[0] = X[0];                                                        \
        x2[1] = X[1] + dX[1];                                                \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi + phi_ghostbox_dims(0)];                    \
        psi_tet[1] = psi[idx_psi + psi_ghostbox_dims(0)];                    \
                                                                             \
        x3[0] = X[0];                                                        \
        x3[1] = X[1];                                                        \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi +                                           \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi +                                           \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0] + dX[0];                                                \
        x4[1] = X[1] + dX[1];                                                \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + 1 + phi_ghostbox_dims(0) +                \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + 1 + psi_ghostbox_dims(0) +                \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      default: {                                                             \
        TBOX_ERROR(  "LSMDD_Utilities::"                        \
                  << "GET_TETRAHEDRON_DATA(): "                              \
                  << "  tet_num OUT OF RANGE...SHOULD BE 0 <= tet_num <= 5!" \
                  << endl);                                                  \
      }                                                                      \
    }                                                                        \
  } else { /* case: (i+j) != 0) */                                           \
                                                                             \
    switch(tet_num) {                                                        \
                                                                             \
      case 0: {                                                              \
        x1[0] = X[0];                                                        \
        x1[1] = X[1] + dX[1];                                                \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + phi_ghostbox_dims(0)];                    \
        psi_tet[0] = psi[idx_psi + psi_ghostbox_dims(0)];                    \
                                                                             \
        x2[0] = X[0] + dX[0];                                                \
        x2[1] = X[1];                                                        \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi + 1];                                       \
        psi_tet[1] = psi[idx_psi + 1];                                       \
                                                                             \
        x3[0] = X[0];                                                        \
        x3[1] = X[1];                                                        \
        x3[2] = X[2];                                                        \
        phi_tet[2] = phi[idx_phi];                                           \
        psi_tet[2] = psi[idx_psi];                                           \
                                                                             \
        x4[0] = X[0];                                                        \
        x4[1] = X[1] + dX[1];                                                \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + phi_ghostbox_dims(0) +                    \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + psi_ghostbox_dims(0) +                    \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 1: {                                                              \
        x1[0] = X[0];                                                        \
        x1[1] = X[1];                                                        \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi];                                           \
        psi_tet[0] = psi[idx_psi];                                           \
                                                                             \
        x2[0] = X[0];                                                        \
        x2[1] = X[1] + dX[1];                                                \
        x2[2] = X[2] + dX[2];                                                \
        phi_tet[1] = phi[idx_phi + phi_ghostbox_dims(0) +                    \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[1] = psi[idx_psi + psi_ghostbox_dims(0) +                    \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x3[0] = X[0] + dX[0];                                                \
        x3[1] = X[1];                                                        \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi + 1 +                                       \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi + 1 +                                       \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0];                                                        \
        x4[1] = X[1];                                                        \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi +                                           \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi +                                           \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 2: {                                                              \
        x1[0] = X[0] + dX[0];                                                \
        x1[1] = X[1];                                                        \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + 1];                                       \
        psi_tet[0] = psi[idx_psi + 1];                                       \
                                                                             \
        x2[0] = X[0];                                                        \
        x2[1] = X[1];                                                        \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi];                                           \
        psi_tet[1] = psi[idx_psi];                                           \
                                                                             \
        x3[0] = X[0];                                                        \
        x3[1] = X[1] + dX[1];                                                \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi + phi_ghostbox_dims(0) +                    \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi + psi_ghostbox_dims(0) +                    \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0] + dX[0];                                                \
        x4[1] = X[1];                                                        \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + 1 +                                       \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + 1 +                                       \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 3: {                                                              \
        x1[0] = X[0];                                                        \
        x1[1] = X[1] + dX[1];                                                \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + phi_ghostbox_dims(0)];                    \
        psi_tet[0] = psi[idx_psi + psi_ghostbox_dims(0)];                    \
                                                                             \
        x2[0] = X[0] + dX[0];                                                \
        x2[1] = X[1];                                                        \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi + 1];                                       \
        psi_tet[1] = psi[idx_psi + 1];                                       \
                                                                             \
        x3[0] = X[0] + dX[0];                                                \
        x3[1] = X[1] + dX[1];                                                \
        x3[2] = X[2];                                                        \
        phi_tet[2] = phi[idx_phi + 1 + phi_ghostbox_dims(0)];                \
        psi_tet[2] = psi[idx_psi + 1 + psi_ghostbox_dims(0)];                \
                                                                             \
        x4[0] = X[0];                                                        \
        x4[1] = X[1] + dX[1];                                                \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + phi_ghostbox_dims(0) +                    \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + psi_ghostbox_dims(0) +                    \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 4: {                                                              \
        x1[0] = X[0] + dX[0];                                                \
        x1[1] = X[1] + dX[1];                                                \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + 1 + phi_ghostbox_dims(0)];                \
        psi_tet[0] = psi[idx_psi + 1 + psi_ghostbox_dims(0)];                \
                                                                             \
        x2[0] = X[0];                                                        \
        x2[1] = X[1] + dX[1];                                                \
        x2[2] = X[2] + dX[2];                                                \
        phi_tet[1] = phi[idx_phi + phi_ghostbox_dims(0) +                    \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[1] = psi[idx_psi + psi_ghostbox_dims(0) +                    \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x3[0] = X[0] + dX[0];                                                \
        x3[1] = X[1];                                                        \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi + 1 +                                       \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi + 1 +                                       \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0] + dX[0];                                                \
        x4[1] = X[1] + dX[1];                                                \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + 1 + phi_ghostbox_dims(0) +                \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + 1 + psi_ghostbox_dims(0) +                \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      case 5: {                                                              \
        x1[0] = X[0] + dX[0];                                                \
        x1[1] = X[1];                                                        \
        x1[2] = X[2];                                                        \
        phi_tet[0] = phi[idx_phi + 1];                                       \
        psi_tet[0] = psi[idx_psi + 1];                                       \
                                                                             \
        x2[0] = X[0] + dX[0];                                                \
        x2[1] = X[1] + dX[1];                                                \
        x2[2] = X[2];                                                        \
        phi_tet[1] = phi[idx_phi + 1 + phi_ghostbox_dims(0)];                \
        psi_tet[1] = psi[idx_psi + 1 + psi_ghostbox_dims(0)];                \
                                                                             \
        x3[0] = X[0];                                                        \
        x3[1] = X[1] + dX[1];                                                \
        x3[2] = X[2] + dX[2];                                                \
        phi_tet[2] = phi[idx_phi + phi_ghostbox_dims(0) +                    \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[2] = psi[idx_psi + psi_ghostbox_dims(0) +                    \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        x4[0] = X[0] + dX[0];                                                \
        x4[1] = X[1];                                                        \
        x4[2] = X[2] + dX[2];                                                \
        phi_tet[3] = phi[idx_phi + 1 +                                       \
                         phi_ghostbox_dims(0)*phi_ghostbox_dims(1)];         \
        psi_tet[3] = psi[idx_psi + 1 +                                       \
                         psi_ghostbox_dims(0)*psi_ghostbox_dims(1)];         \
                                                                             \
        break;                                                               \
      }                                                                      \
                                                                             \
      default: {                                                             \
        TBOX_ERROR(  "LSMDD_Utilities::"                        \
                  << "GET_TETRAHEDRON_DATA(): "                              \
                  << "  tet_num OUT OF RANGE...SHOULD BE 0 <= tet_num <= 5!" \
                  << endl);                                                  \
      }                                                                      \
    } /* end switch statement */                                             \
  }                                                                          \
}

/*!
 * INTERPOLATE_FORCE() interpolates the forces at the corners 
 * of the cell defined by the centers of the cells in the index space 
 * [(i,j,k),(i+1,j+1,k+1)] to the specified point using trilinear 
 * interpolation.
 * 
 * Arguments:
 * - force_*_pt (out):          components of force at endpoint
 * - pt (in):                   double array holding the physical coordinates
 *                              of the point at which force should be 
 *                              interpolated
 * - X (in):                    double array holding the physical coordinates 
 *                              for the center of the grid cell with index
 *                              (i,j,k)
 * - dX (in):                   double array holding the grid spacing in
 *                              the three coordinate directions
 * - force_* (in):              double arrays holding the components
 *                              of the force for the entire Patch
 * - idx_force (in):            index of grid index (i,j,k) in linear 
 *                              data array for force
 * - force_ghostbox_dims (in):  IntVector holding the dimensions of the 
 *                              ghostbox for force
 *
 * NOTES:
 * - All arguments passed into this macro MUST be variables NOT 
 *   expressions.  If expressions are passed in as arguments, 
 *   this macro may yield incorrect results!
 *
 */
#define INTERPOLATE_FORCE(force_x_pt, force_y_pt, force_z_pt,              \
                          pt,                                              \
                          force_x, force_y, force_z,                       \
                          X, dX,                                           \
                          idx_force, force_ghostbox_dims)                  \
{                                                                          \
  const double inv_dx = 1.0/dX[0];                                         \
  const double inv_dy = 1.0/dX[1];                                         \
  const double inv_dz = 1.0/dX[2];                                         \
  double x_weight_minus, x_weight_plus;                                    \
  double y_weight_minus, y_weight_plus;                                    \
  double z_weight_minus, z_weight_plus;                                    \
                                                                           \
  x_weight_plus = (pt[0] - X[0])*inv_dx;                                   \
  x_weight_minus = 1 - x_weight_plus;                                      \
  y_weight_plus = (pt[1] - X[1])*inv_dy;                                   \
  y_weight_minus = 1 - y_weight_plus;                                      \
  z_weight_plus = (pt[2] - X[2])*inv_dz;                                   \
  z_weight_minus = 1 - z_weight_plus;                                      \
                                                                           \
  force_x_pt =                                                             \
    x_weight_minus * y_weight_minus * z_weight_minus *                     \
    force_x[idx_force]                                                     \
  + x_weight_plus * y_weight_minus * z_weight_minus *                      \
    force_x[idx_force + 1]                                                 \
  + x_weight_minus * y_weight_plus * z_weight_minus *                      \
    force_x[idx_force + force_ghostbox_dims(0)]                            \
  + x_weight_plus * y_weight_plus * z_weight_minus *                       \
    force_x[idx_force + 1 + force_ghostbox_dims(0)]                        \
  + x_weight_minus * y_weight_minus * z_weight_plus *                      \
    force_x[idx_force +                                                    \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_plus * y_weight_minus * z_weight_plus *                       \
    force_x[idx_force + 1 +                                                \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_minus * y_weight_plus * z_weight_plus *                       \
    force_x[idx_force + force_ghostbox_dims(0) +                           \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_plus * y_weight_plus * z_weight_plus *                        \
    force_x[idx_force + 1 + force_ghostbox_dims(0) +                       \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)];                \
                                                                           \
  force_y_pt =                                                             \
    x_weight_minus * y_weight_minus * z_weight_minus *                     \
    force_y[idx_force]                                                     \
  + x_weight_plus * y_weight_minus * z_weight_minus *                      \
    force_y[idx_force + 1]                                                 \
  + x_weight_minus * y_weight_plus * z_weight_minus *                      \
    force_y[idx_force + force_ghostbox_dims(0)]                            \
  + x_weight_plus * y_weight_plus * z_weight_minus *                       \
    force_y[idx_force + 1 + force_ghostbox_dims(0)]                        \
  + x_weight_minus * y_weight_minus * z_weight_plus *                      \
    force_y[idx_force +                                                    \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_plus * y_weight_minus * z_weight_plus *                       \
    force_y[idx_force + 1 +                                                \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_minus * y_weight_plus * z_weight_plus *                       \
    force_y[idx_force + force_ghostbox_dims(0) +                           \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_plus * y_weight_plus * z_weight_plus *                        \
    force_y[idx_force + 1 + force_ghostbox_dims(0) +                       \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)];                \
                                                                           \
  force_z_pt =                                                             \
    x_weight_minus * y_weight_minus * z_weight_minus *                     \
    force_z[idx_force]                                                     \
  + x_weight_plus * y_weight_minus * z_weight_minus *                      \
    force_z[idx_force + 1]                                                 \
  + x_weight_minus * y_weight_plus * z_weight_minus *                      \
    force_z[idx_force + force_ghostbox_dims(0)]                            \
  + x_weight_plus * y_weight_plus * z_weight_minus *                       \
    force_z[idx_force + 1 + force_ghostbox_dims(0)]                        \
  + x_weight_minus * y_weight_minus * z_weight_plus *                      \
    force_z[idx_force +                                                    \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_plus * y_weight_minus * z_weight_plus *                       \
    force_z[idx_force + 1 +                                                \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_minus * y_weight_plus * z_weight_plus *                       \
    force_z[idx_force + force_ghostbox_dims(0) +                           \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)]                 \
  + x_weight_plus * y_weight_plus * z_weight_plus *                        \
    force_z[idx_force + 1 + force_ghostbox_dims(0) +                       \
            force_ghostbox_dims(0)*force_ghostbox_dims(1)];                \
}


/*!
 * CHECK_IF_CELL_NEEDS_VELOCITY_UPDATE() checks to see if the specified
 * grid cell needs to have its velocity updated because the current
 * dislocation line segment is closer than all previous ones that have 
 * been examined.  If so, update_cell is set to true and the force
 * to use for the velocity update is computed.
 * 
 * Arguments:
 * - update_cell (out):                 boolean indicating whether or not the 
 *                                      grid cell needs to have its velocity 
 *                                      updated
 * - force_*_closest (out):             components of the force at the point 
 *                                      on the dislocation segment closest to 
 *                                      the center of the grid cell
 * - tangent_* (in):                    components of the tangent vector 
 *                                      for the dislocation segment defined
 *                                      by (endpt2 - endpt1).
 * - dislocation_segment_length (in):   length of dislocation line segment
 * - min_segment_length (in):           minimum dislocation line segment 
 *                                      length for considering the two 
 *                                      endpoints of the segment to be 
 *                                      numerically distinct
 * - X (in):                            double array holding the physical 
 *                                      coordinates for the center of the 
 *                                      grid cell being examined
 * - dX (in):                           double array holding the grid spacing
 *                                      in the three coordinate directions
 * - endpt1, endpt2 (in):               double arrays holding the physical
 *                                      coordinates of the end points of the 
 *                                      dislocation line segment
 * - force_*_endpt1 (in):               components of force at endpoint 1
 * - force_*_endpt2 (in):               components of force at endpoint 2
 * - distance (in):                     double arrays holding the current
 *                                      distance from the center of each
 *                                      grid cell to the nearest dislocation 
 *                                      line segment for the entire Patch
 * - idx_distance (in):                 index of grid index (i,j,k) in linear 
 *                                      data array for distance
 *
 * NOTES:
 * - the length of the dislocation line segment is passed in as an
 *   argument for performance reasons (i.e. so it doesn't have to 
 *   be recomputed for each neighbor).
 *
 * - All arguments passed into this macro MUST be variables NOT 
 *   expressions.  If expressions are passed in as arguments, 
 *   this macro may yield incorrect results!
 *
 */
#define CHECK_IF_CELL_NEEDS_VELOCITY_UPDATE(                               \
  update_cell, force_x_closest, force_y_closest, force_z_closest,          \
  tangent_x, tangent_y, tangent_z,                                         \
  dislocation_segment_length, min_segment_length,                          \
  X, dX, endpt1, endpt2,                                                   \
  force_x_endpt1, force_y_endpt1, force_z_endpt1,                          \
  force_x_endpt2, force_y_endpt2, force_z_endpt2,                          \
  distance, idx_neighbor_distance)                                         \
{                                                                          \
  update_current_cell = false;                                             \
                                                                           \
  if ( dislocation_segment_length > min_segment_length ) {                 \
                                                                           \
    /* case: dislocation segment long enough to avoid  */                  \
    /*       significant round-off error               */                  \
                                                                           \
    /* compute 1/dislocation_segment_length and */                         \
    /* unit tangent vector                      */                         \
    double inv_dislocation_segment_length = 0.0;                           \
    inv_dislocation_segment_length =                                       \
      1.0/(dislocation_segment_length);                                    \
    double unit_tangent_x = tangent_x*inv_dislocation_segment_length;      \
    double unit_tangent_y = tangent_y*inv_dislocation_segment_length;      \
    double unit_tangent_z = tangent_z*inv_dislocation_segment_length;      \
                                                                           \
    /* find point on dislocation line segment closest to X */              \
    double p_minus_endpt1_dot_dislocation =                                \
        (X[0] - endpt1[0])*unit_tangent_x                                  \
      + (X[1] - endpt1[1])*unit_tangent_y                                  \
      + (X[2] - endpt1[2])*unit_tangent_z;                                 \
    double p_minus_endpt2_dot_dislocation =                                \
      - (X[0] - endpt2[0])*unit_tangent_x                                  \
      - (X[1] - endpt2[1])*unit_tangent_y                                  \
      - (X[2] - endpt2[2])*unit_tangent_z;                                 \
                                                                           \
    if (p_minus_endpt1_dot_dislocation <= 0) {                             \
      distance_to_dislocation_segment =                                    \
        sqrt( (X[0] - endpt1[0])*(X[0] - endpt1[0])                        \
            + (X[1] - endpt1[1])*(X[1] - endpt1[1])                        \
            + (X[2] - endpt1[2])*(X[2] - endpt1[2]) );                     \
                                                                           \
      /* artificially set p_minus_endpt1_dot_dislocation */                \
      /* to 0.0 so that the interpolation weights below  */                \
      /* are correctly computed                          */                \
      p_minus_endpt1_dot_dislocation = 0.0;                                \
                                                                           \
    } else if (p_minus_endpt2_dot_dislocation <= 0) {                      \
                                                                           \
      distance_to_dislocation_segment =                                    \
        sqrt( (X[0] - endpt2[0])*(X[0] - endpt2[0])                        \
            + (X[1] - endpt2[1])*(X[1] - endpt2[1])                        \
            + (X[2] - endpt2[2])*(X[2] - endpt2[2]) );                     \
                                                                           \
      /* artificially set p_minus_endpt1_dot_dislocation     */            \
      /* to dislocation_segment_length so that the           */            \
      /* interpolation weights below are correctly computed  */            \
      p_minus_endpt1_dot_dislocation =                                     \
        dislocation_segment_length;                                        \
                                                                           \
    } else {                                                               \
                                                                           \
      double x_closest = endpt1[0] +                                       \
         p_minus_endpt1_dot_dislocation*unit_tangent_x;                    \
      double y_closest = endpt1[1] +                                       \
         p_minus_endpt1_dot_dislocation*unit_tangent_y;                    \
      double z_closest = endpt1[2] +                                       \
         p_minus_endpt1_dot_dislocation*unit_tangent_z;                    \
                                                                           \
      distance_to_dislocation_segment =                                    \
        sqrt( (X[0] - x_closest)*(X[0] - x_closest)                        \
            + (X[1] - y_closest)*(X[1] - y_closest)                        \
            + (X[2] - z_closest)*(X[2] - z_closest) );                     \
                                                                           \
    }                                                                      \
                                                                           \
    /* if distance to current dislocation line segment        */           \
    /* is smaller than previous closest dislocation           */           \
    /* line segment, compute force and unit tangent           */           \
    /* vector at closest point                                */           \
    /* NOTE: we allow equality here in case the velocity      */           \
    /*       for the neighbor had previously been set with    */           \
    /*       a dislocation line segment that is numerically   */           \
    /*       just a "point."  In that situation, we would     */           \
    /*       rather use the value from a dislocation line     */           \
    /*       segment that has a nonzero numerical length.     */           \
    if ( distance_to_dislocation_segment <=                                \
         distance[idx_neighbor_distance] ) {                               \
                                                                           \
      double weight_endpt1, weight_endpt2;                                 \
      weight_endpt2 = p_minus_endpt1_dot_dislocation                       \
        *inv_dislocation_segment_length;                                   \
      weight_endpt1 = 1 - weight_endpt2;                                   \
                                                                           \
      force_x_closest = force_x_endpt1*weight_endpt1                       \
                      + force_x_endpt2*weight_endpt2;                      \
      force_y_closest = force_y_endpt1*weight_endpt1                       \
                      + force_y_endpt2*weight_endpt2;                      \
      force_z_closest = force_z_endpt1*weight_endpt1                       \
                      + force_z_endpt2*weight_endpt2;                      \
                                                                           \
      update_current_cell = true;                                          \
                                                                           \
    }                                                                      \
  } else {                                                                 \
    /* case: dislocation segment too short too compute its  */             \
    /*       length accurately, so the dislocation segment  */             \
    /*       is treated as a single point and the           */             \
    /*       tangent vector of the dislocation segment      */             \
    /*       is taken to be the tangent vector at the       */             \
    /*       current grid point.                            */             \
                                                                           \
    distance_to_dislocation_segment =                                      \
      sqrt( (X[0] - endpt1[0])*(X[0] - endpt1[0])                          \
          + (X[1] - endpt1[1])*(X[1] - endpt1[1])                          \
          + (X[2] - endpt1[2])*(X[2] - endpt1[2]) );                       \
                                                                           \
    /* if distance to current dislocation line segment  */                 \
    /* is smaller than previous closest dislocation     */                 \
    /* line segment, compute force and unit tangent     */                 \
    /* vector at closest point                          */                 \
    if ( distance_to_dislocation_segment <                                 \
         distance[idx_neighbor_distance] ) {                               \
                                                                           \
      force_x_closest = force_x_endpt1;                                    \
      force_y_closest = force_y_endpt1;                                    \
      force_z_closest = force_z_endpt1;                                    \
                                                                           \
      update_current_cell = true;                                          \
                                                                           \
    }                                                                      \
  } /* end branch on length of dislocation line segment */                 \
}

/*!
 * CHECK_FOR_PURE_SCREW_SCREW_DISLOCATION() determines whether a 
 * dislocation line segment is a pure screw dislocation.
 *
 * Arguments:      
 *  - segment_is_pure_screw (out):    boolean indicating whether or not the
 *                                    dislocation segment has pure screw
 *                                    character
 *  - max_angle_for_pure_screw (in):  maximum angle (approximate) allowed
 *                                    between Burgers vector and tangent
 *                                    vector for segment to be considered
 *                                    to have pure screw character
 *  - b_x, b_y, b_z (in):             Burgers vector of dislocation line 
 *                                    segment
 *  - tangent_vector_x (in):          x-component of tangent vector of 
 *                                    dislocation line segment
 *  - tangent_vector_y (in):          y-component of tangent vector of
 *                                    dislocation line segment
 *  - tangent_vector_z (in):          z-component of tangent vector of
 *                                    dislocation line segment
 *
 * NOTES:
 * - The tangent vector need NOT be of unit length. 
 *
 * - The formula used to estimate the angle, \f$ \theta \f$, between the
 *   Burgers vector and tangent vector is 
 *
 *   \f[
 *       \theta^2 \approx 1
 *                      - \frac{\vec{b} \cdot \vec{\xi}}
 *                             {|\vec{b}|^2 |\vec{\xi}|^2}
 *   \f]
 *
 *   where \f$ \vec{\xi} \f$ is the tangent vector.
 *
 * - All arguments passed into this macro MUST be variables NOT 
 *   expressions.  If expressions are passed in as arguments, 
 *   this macro may yield incorrect results!
 *
 */
#define CHECK_FOR_PURE_SCREW_SCREW_DISLOCATION(                             \
  segment_is_pure_screw,                                                    \
  max_angle_for_pure_screw,                                                 \
  b_x, b_y, b_z,                                                            \
  tangent_vector_x, tangent_vector_y, tangent_vector_z)                     \
{                                                                           \
  /* compute square of norm of tangent vector */                            \
  double norm_sq_tangent_vector = tangent_vector_x*tangent_vector_x         \
                                + tangent_vector_y*tangent_vector_y         \
                                + tangent_vector_z*tangent_vector_z;        \
                                                                            \
  if (norm_sq_tangent_vector < 1.0e-20) {                                   \
    TBOX_WARNING("LSMDD_Utilities::"                           \
              << "CHECK_FOR_PURE_SCREW_SCREW_DISLOCATION(): "               \
              << "length of tangent vector too small to do computation..."  \
              << "returning true"                                           \
              << endl);                                                     \
    segment_is_pure_screw = true;                                           \
  }                                                                         \
                                                                            \
  /* compute square of norm of Burgers vector */                            \
  double norm_sq_burgers_vector = b_x*b_x                                   \
                                + b_y*b_y                                   \
                                + b_z*b_z;                                  \
                                                                            \
  if (norm_sq_burgers_vector < 1.0e-20) {                                   \
    TBOX_WARNING("LSMDD_Utilities::"                           \
              << "CHECK_FOR_PURE_SCREW_SCREW_DISLOCATION(): "               \
              << "length of Burgers vector too small to do computation..."  \
              << "returning true"                                           \
              << endl);                                                     \
    segment_is_pure_screw = true;                                           \
  }                                                                         \
                                                                            \
  /* compute dot product of Burgers vector and tangent vector */            \
  double b_dot_tangent = b_x*tangent_vector_x                               \
                       + b_y*tangent_vector_y                               \
                       + b_z*tangent_vector_z;                              \
                                                                            \
  /* estimate the square of the angle between Burgers vector and */         \
  /* tangent vector                                              */         \
  double theta_sq = 1 - b_dot_tangent*b_dot_tangent                         \
                      / norm_sq_burgers_vector/norm_sq_tangent_vector;      \
                                                                            \
  segment_is_pure_screw =                                                   \
    (theta_sq < max_angle_for_pure_screw*max_angle_for_pure_screw);         \
}

#endif
