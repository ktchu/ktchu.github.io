/*
 * File:        PeriodicDislocationArrayElasticStressModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Implementation file for the 
 *              PeriodicDislocationArrayElasticStressModule class
 */

#include "PeriodicDislocationArrayElasticStressModule.h"

// SAMRAI Headers
#include "Box.h"
#include "CartesianGridGeometry.h"
#include "CellData.h"
#include "CellVariable.h"
#include "IntVector.h"
#include "PatchLevel.h"
#include "VariableContext.h"
#include "VariableDatabase.h"
#include "tbox/MPI.h"
#include "tbox/Utilities.h"

extern "C" {
  #include "lsmdd_elastic_stress_fort.h"
}

// namespaces
using namespace geom;
using namespace pdat;


/* ELASTIC_STRESS_MODULE MACROS */
#define ELASTIC_STRESS_MODULE_NULL                     (0)
#define ELASTIC_STRESS_MODULE_ZERO_TOL                 (1.0e-13)
#define ELASTIC_STRESS_MODULE_FFT_NO_SCALING           (0)
#define ELASTIC_STRESS_MODULE_FFT_NO_PERMUTE           (0)
#define ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS    (6)
#define ELASTIC_STRESS_MODULE_DIM                      (3)
#define ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG        (1)
#define ELASTIC_STRESS_MODULE_FORWARD_FFT_FLAG         (-1)
#define ELASTIC_STRESS_MODULE_PI                       (3.14159265358979)


namespace LSMDD {

/* Constructor() */
PeriodicDislocationArrayElasticStressModule::
PeriodicDislocationArrayElasticStressModule(
  Pointer<Database> input_db,
  Pointer< PatchHierarchy<3> > patch_hierarchy)
{
#ifdef DEBUG_CHECK_ASSERTIONS
  assert(!patch_hierarchy.isNull());
#endif

  // set pointers for patch hierarchy
  d_patch_hierarchy = patch_hierarchy;

  // read input parameters
  getFromInput(input_db);

  // parameter checks
  Pointer< CartesianGridGeometry<3> > grid_geometry = 
    d_patch_hierarchy->getGridGeometry();
  if (!grid_geometry->getDomainIsSingleBox()) {
    TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
              << "PeriodicDislocationArrayElasticStressModule():"
              << " domain MUST be a single box."
              << endl);
  }

  /* 
   * initialize stress field variables
   */
  // get pointer to VariableDatabase
  VariableDatabase<3> *var_db = VariableDatabase<3>::getDatabase();

  // get contexts used by elasticity module
  Pointer<VariableContext> elasticity_context = 
    var_db->getContext("ELASTICITY CALCULATION");

  // create variables
  Pointer< CellVariable<3,double> > stress_field_variable =
    new CellVariable<3,double>("stress_field(LSMDD)",
                               ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS);

  IntVector<3> zero_ghostcell_width(0);
  d_stress_field_handle = var_db->registerVariableAndContext(
    stress_field_variable, elasticity_context, zero_ghostcell_width);


  // compute global index space for problem
  d_global_box = (grid_geometry->getPhysicalDomain())(0);

  /*
   * compute scale factor required to:
   * (1) normalize FFT computed by FFTW
   * (2) account for the difference in definition of Fourier Transform 
   *     used by by Xiang et. al. (2003) (defined in terms of oscillation 
   *     frequency) and by FFTW (defined in terms of angular frequency).
   */
  d_fft_scale_factor = 0.5/d_global_box.size()/ELASTIC_STRESS_MODULE_PI;

  // set d_initialization_complete to false
  d_initialization_complete = false;

  // set d_fft_data_allocated to false
  d_fft_data_allocated = false;

}

  
/* Destructor() */
PeriodicDislocationArrayElasticStressModule::
~PeriodicDislocationArrayElasticStressModule()
{
  // deallocate memory for stress fields
  Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(0);
  level->deallocatePatchData(d_stress_field_handle);

  // deallocate FFT data if not using dynamic memory allocation
  if (!d_use_dynamic_memory_allocation) {
    deallocateFFTData();
  }

  // destroy FFT plan
  fft_3d_destroy_plan(d_fft_plan);
}


/* setStressFieldToZero() */
void PeriodicDislocationArrayElasticStressModule::
setStressFieldToZero()
{
  // make sure that module has been fully initialized
  if (!d_initialization_complete) {
    initializeElasticStressModule();
  }

  // set all components of stress field to zero
  Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(0);
  for (PatchLevelIterator<3> pi(level); pi; pi++) {
    const int pn = *pi;
    Pointer< Patch<3> > patch = level->getPatch(pn);
    if ( patch.isNull() ) {
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << ":setStressFieldToZero()"
                << ": Cannot find patch. Null patch pointer."
                << endl);
    }

    // get stress field PatchData
    Pointer< CellData<3,double> > stress_field_data =
      patch->getPatchData( d_stress_field_handle );

    // fill all components of stress field with zero
    stress_field_data->fillAll(0.0);

  } // end loop over PatchLevel
}


/* addStressFieldForDislocationLine() */ 
void PeriodicDislocationArrayElasticStressModule::
addStressFieldForDislocationLine(
  const int dislocation_line_handle,
  const BurgersVector& burgers_vector,
  const LSMDD_Parameters& lsmdd_params)
{
  // make sure that module has been fully initialized
  if (!d_initialization_complete) {
    initializeElasticStressModule();
    setStressFieldToZero();
  }

  // allocate memory for FFT data is using dynamic memory allocation
  if (d_use_dynamic_memory_allocation) {
    allocateFFTData();
  }

  /*
   * compute FFT of dislocation line function:
   * (1) copy SAMRAI dislocation line field data to FFT data 
   * (2) compute FFT of dislocation line field (to get to frequency space)
   */
  Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(0);
  for (PatchLevelIterator<3> pi(level); pi; pi++) { 
    const int pn = *pi;
    Pointer< Patch<3> > patch = level->getPatch(pn);
    if ( patch.isNull() ) {
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << ":addStressFieldForDislocationLine()"
                << ": Cannot find patch. Null patch pointer."
                << endl);
    }


    // get dislocation line PatchData
    Pointer< CellData<3,double> > dislocation_line_patch_data =
      patch->getPatchData( dislocation_line_handle );

    // get box and ghost box for dislocation line data
    Box<3> dislocation_line_interior_box = 
      dislocation_line_patch_data->getBox();
    const IntVector<3> dislocation_line_interior_box_dimensions = 
      dislocation_line_interior_box.numberCells();

    Box<3> dislocation_line_ghostbox = 
      dislocation_line_patch_data->getGhostBox();
    const IntVector<3> dislocation_line_ghostbox_dims = 
      dislocation_line_ghostbox.numberCells();
    const IntVector<3> dislocation_line_ghostcell_width = 
      dislocation_line_patch_data->getGhostCellWidth();

    // get pointer to actual data
    double* dislocation_line_data[ELASTIC_STRESS_MODULE_DIM];
    dislocation_line_data[0] = dislocation_line_patch_data->getPointer(0);
    dislocation_line_data[1] = dislocation_line_patch_data->getPointer(1);
    dislocation_line_data[2] = dislocation_line_patch_data->getPointer(2);

    // grid index trackers
    int idx_interior = 0;
    int idx_ghostbox = 0;

    // add ghostcell width in z-direction times number of cells in
    // xy-plane to get to starting plane of interior data
    idx_ghostbox += dislocation_line_ghostcell_width(2)
                   *dislocation_line_ghostbox_dims(0)
                   *dislocation_line_ghostbox_dims(1);

    for (int k = 0; k < dislocation_line_interior_box_dimensions(2); k++) {
  
      // add ghostcell width in y-direction times number of cells in
      // x-direction to get to start of next plane of interior data
      idx_ghostbox += dislocation_line_ghostcell_width(1)
                     *dislocation_line_ghostbox_dims(0);

      for (int j = 0; j < dislocation_line_interior_box_dimensions(1); j++) {
  
        // add ghostcell width in x-direction to get to start of 
        // interior data
        idx_ghostbox += dislocation_line_ghostcell_width(0);
  
        for (int i = 0; i < dislocation_line_interior_box_dimensions(0); i++) {
          d_dislocation_line_fft_data[0][idx_interior].re = 
            dislocation_line_data[0][idx_ghostbox];
          d_dislocation_line_fft_data[0][idx_interior].im = 0.0;
          d_dislocation_line_fft_data[1][idx_interior].re = 
            dislocation_line_data[1][idx_ghostbox];
          d_dislocation_line_fft_data[1][idx_interior].im = 0.0;
          d_dislocation_line_fft_data[2][idx_interior].re = 
            dislocation_line_data[2][idx_ghostbox];
          d_dislocation_line_fft_data[2][idx_interior].im = 0.0;
   
          // update array indices
          idx_interior++;
          idx_ghostbox++;
        } 
  
        // add ghostcell width in x-direction to get to start of next 
        // row of SAMRAI data
        idx_ghostbox += dislocation_line_ghostcell_width(0);
  
      } 
  
      // add ghostcell width in y-direction times number of cells in
      // x-direction to get to start of next plane of SAMRAI data
      idx_ghostbox += dislocation_line_ghostcell_width(1)
                     *dislocation_line_ghostbox_dims(0);
  
    } // end loop over grid
  } // end computations on local patch
 
  // Forward FFT (physical space --> frequency space)
  fft_3d(d_dislocation_line_fft_data[0],d_dislocation_line_fft_data[0],
    ELASTIC_STRESS_MODULE_FORWARD_FFT_FLAG, d_fft_plan);
  fft_3d(d_dislocation_line_fft_data[1],d_dislocation_line_fft_data[1],
    ELASTIC_STRESS_MODULE_FORWARD_FFT_FLAG, d_fft_plan);
  fft_3d(d_dislocation_line_fft_data[2],d_dislocation_line_fft_data[2],
    ELASTIC_STRESS_MODULE_FORWARD_FFT_FLAG, d_fft_plan);


  /*
   * Compute stress field:
   * (1) compute stress field in frequency space
   * (2) invert FFT of stress field and accumulate stress 
   *     field in SAMRAI data
   */
  if (d_conserve_memory) {

    // loop over stress field components
    for (int component = 0; component < 6; component++) {

      for (PatchLevelIterator<3> pi(level); pi; pi++) { 
        const int pn = *pi;
        Pointer< Patch<3> > patch = level->getPatch(pn);
        if ( patch.isNull() ) {
          TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                    << ":addStressFieldForDislocationLine()"
                    << ": Cannot find patch. Null patch pointer."
                    << endl);
        }
  
        // compute stress field in frequency space
        computeStressOnPatchMemoryEfficient(
          patch, 
          (STRESS_COMPONENT_TYPE) component,
          d_stress_field_fft_data[0], 
          dislocation_line_handle, burgers_vector, 
          lsmdd_params);

        // Backward FFT to compute stress field component
        // (frequency space --> physical space)
        fft_3d(d_stress_field_fft_data[0], d_stress_field_fft_data[0], 
          ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG, d_fft_plan);

        // accumulate stress in SAMRAI PatchData
        addStressFieldComponentToSAMRAIPatchData(
          patch, d_stress_field_fft_data[0], 
          (STRESS_COMPONENT_TYPE) component,
          lsmdd_params);

      }

    } // end loop over stress field components

  } else {

    // compute stress field in frequency space
    for (PatchLevelIterator<3> pi(level); pi; pi++) { 
      const int pn = *pi;
      Pointer< Patch<3> > patch = level->getPatch(pn);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                  << ":addStressFieldForDislocationLine()"
                  << ": Cannot find patch. Null patch pointer."
                  << endl);
      }

      computeStressOnPatchTimeEfficient(
        patch, 
        dislocation_line_handle, burgers_vector, 
        lsmdd_params);

      // Backward FFT to compute stress field 
      // (frequency space --> physical space)
      fft_3d(d_stress_field_fft_data[0],d_stress_field_fft_data[0],
        ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG, d_fft_plan);
      fft_3d(d_stress_field_fft_data[1],d_stress_field_fft_data[1],
        ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG, d_fft_plan);
      fft_3d(d_stress_field_fft_data[2],d_stress_field_fft_data[2],
        ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG, d_fft_plan);
      fft_3d(d_stress_field_fft_data[3],d_stress_field_fft_data[3],
        ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG, d_fft_plan);
      fft_3d(d_stress_field_fft_data[4],d_stress_field_fft_data[4],
        ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG, d_fft_plan);
      fft_3d(d_stress_field_fft_data[5],d_stress_field_fft_data[5],
        ELASTIC_STRESS_MODULE_BACKWARD_FFT_FLAG, d_fft_plan);

      // accumulate stress field in SAMRAI PatchData
      addStressFieldToSAMRAIPatchData(patch, lsmdd_params);

    }

  }

  // deallocate memory for FFT data is using dynamic memory allocation
  if (d_use_dynamic_memory_allocation) {
    deallocateFFTData();
  }
}


/* addAuxiliaryStressField() */
void PeriodicDislocationArrayElasticStressModule::
addAuxiliaryStressField(
  const int auxiliary_stress_field_handle,
  const LSMDD_Parameters& lsmdd_params)
{
  // make sure that module has been fully initialized
  if (!d_initialization_complete) {
    initializeElasticStressModule();
    setStressFieldToZero();
  }

  // add the auxiliary stress field to the total stress field for all 
  // components of the stress field 
  Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(0);
  for (PatchLevelIterator<3> pi(level); pi; pi++) {
    const int pn = *pi;
    Pointer< Patch<3> > patch = level->getPatch(pn);
    if ( patch.isNull() ) {
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << ":addAuxiliaryStressField()"
                << ": Cannot find patch. Null patch pointer."
                << endl);
    }

    // get PatchData
    Pointer< CellData<3,double> > total_stress_field_data =
      patch->getPatchData( d_stress_field_handle );
    Pointer< CellData<3,double> > auxiliary_stress_field_data =
      patch->getPatchData( auxiliary_stress_field_handle );

    Box<3> total_stress_fillbox = 
      total_stress_field_data->getBox();
    const IntVector<3> total_stress_fillbox_upper = 
      total_stress_fillbox.upper();
    const IntVector<3> total_stress_fillbox_lower = 
      total_stress_fillbox.lower();

    Box<3> total_stress_ghostbox = 
      total_stress_field_data->getGhostBox();
    const IntVector<3> total_stress_ghostbox_upper = 
      total_stress_ghostbox.upper();
    const IntVector<3> total_stress_ghostbox_lower = 
      total_stress_ghostbox.lower();

    Box<3> auxiliary_stress_ghostbox = 
      auxiliary_stress_field_data->getGhostBox();
    const IntVector<3> auxiliary_stress_ghostbox_upper = 
      auxiliary_stress_ghostbox.upper();
    const IntVector<3> auxiliary_stress_ghostbox_lower = 
      auxiliary_stress_ghostbox.lower();

    for (int i=0; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 

      double* total_stress = total_stress_field_data->getPointer(i);
      double* auxiliary_stress = auxiliary_stress_field_data->getPointer(i);

      LSMDD_ADD_STRESS_COMPONENT(
        total_stress,
        &total_stress_ghostbox_lower[0],
        &total_stress_ghostbox_upper[0],
        &total_stress_ghostbox_lower[1],
        &total_stress_ghostbox_upper[1],
        &total_stress_ghostbox_lower[2],
        &total_stress_ghostbox_upper[2],
        auxiliary_stress,
        &auxiliary_stress_ghostbox_lower[0],
        &auxiliary_stress_ghostbox_upper[0],
        &auxiliary_stress_ghostbox_lower[1],
        &auxiliary_stress_ghostbox_upper[1],
        &auxiliary_stress_ghostbox_lower[2],
        &auxiliary_stress_ghostbox_upper[2],
        &total_stress_fillbox_lower[0],
        &total_stress_fillbox_upper[0],
        &total_stress_fillbox_lower[1],
        &total_stress_fillbox_upper[1],
        &total_stress_fillbox_lower[2],
        &total_stress_fillbox_upper[2]);

    } // end loop over components of stress field
  
  } // end loop over PatchHierarchy
}


/* addAuxiliaryStressFieldComponent() */
void PeriodicDislocationArrayElasticStressModule::
addAuxiliaryStressFieldComponent(
  const int auxiliary_stress_field_handle,
  const LSMDD_Parameters& lsmdd_params,
  const int component)
{
  // make sure that module has been fully initialized
  if (!d_initialization_complete) {
    initializeElasticStressModule();
    setStressFieldToZero();
  }

  // add the auxiliary stress field to the total stress field for all 
  // components of the stress field 
  Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(0);
  for (PatchLevelIterator<3> pi(level); pi; pi++) {
    const int pn = *pi;
    Pointer< Patch<3> > patch = level->getPatch(pn);
    if ( patch.isNull() ) {
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << ":addAuxiliaryStressField()"
                << ": Cannot find patch. Null patch pointer."
                << endl);
    } 

    // get PatchData
    Pointer< CellData<3,double> > total_stress_field_data =
      patch->getPatchData( d_stress_field_handle );
    Pointer< CellData<3,double> > auxiliary_stress_field_data =
      patch->getPatchData( auxiliary_stress_field_handle );

    Box<3> total_stress_fillbox = 
      total_stress_field_data->getBox();
    const IntVector<3> total_stress_fillbox_upper = 
      total_stress_fillbox.upper();
    const IntVector<3> total_stress_fillbox_lower = 
      total_stress_fillbox.lower();

    Box<3> total_stress_ghostbox = 
      total_stress_field_data->getGhostBox();
    const IntVector<3> total_stress_ghostbox_upper = 
      total_stress_ghostbox.upper();
    const IntVector<3> total_stress_ghostbox_lower = 
      total_stress_ghostbox.lower();

    Box<3> auxiliary_stress_ghostbox = 
      auxiliary_stress_field_data->getGhostBox();
    const IntVector<3> auxiliary_stress_ghostbox_upper = 
      auxiliary_stress_ghostbox.upper();
    const IntVector<3> auxiliary_stress_ghostbox_lower = 
      auxiliary_stress_ghostbox.lower();

    double* total_stress = total_stress_field_data->getPointer(component);
    double* auxiliary_stress = auxiliary_stress_field_data->getPointer();

    LSMDD_ADD_STRESS_COMPONENT(
      total_stress,
      &total_stress_ghostbox_lower[0],
      &total_stress_ghostbox_upper[0],
      &total_stress_ghostbox_lower[1],
      &total_stress_ghostbox_upper[1],
      &total_stress_ghostbox_lower[2],
      &total_stress_ghostbox_upper[2],
      auxiliary_stress,
      &auxiliary_stress_ghostbox_lower[0],
      &auxiliary_stress_ghostbox_upper[0],
      &auxiliary_stress_ghostbox_lower[1],
      &auxiliary_stress_ghostbox_upper[1],
      &auxiliary_stress_ghostbox_lower[2],
      &auxiliary_stress_ghostbox_upper[2],
      &total_stress_fillbox_lower[0],
      &total_stress_fillbox_upper[0],
      &total_stress_fillbox_lower[1],
      &total_stress_fillbox_upper[1],
      &total_stress_fillbox_lower[2],
      &total_stress_fillbox_upper[2]);

  } // end loop over PatchHierarchy
}


/* printClassData() */
void PeriodicDislocationArrayElasticStressModule::
printClassData(ostream& os) const
{
  os << "PeriodicDislocationArrayElasticStressModule" << endl;
  os << "-------------------------------------------" << endl;
  os << "d_conserve_memory = " << 
    ((d_conserve_memory) ?  "TRUE" : "FALSE") << endl;
  os << "d_use_dynamic_memory_allocation = " << 
    ((d_use_dynamic_memory_allocation) ?  "TRUE" : "FALSE") << endl;
}


/* getFromInput() */
void PeriodicDislocationArrayElasticStressModule::
getFromInput(Pointer<Database> db)
{
  d_conserve_memory = db->getBoolWithDefault("conserve_memory", false);
  d_use_dynamic_memory_allocation = 
    db->getBoolWithDefault("use_dynamic_memory_allocation", true);
}


/* computeStressOnPatchTimeEfficient() */
void PeriodicDislocationArrayElasticStressModule::
computeStressOnPatchTimeEfficient(
  Pointer< Patch<3> > patch,
  const int dislocation_line_handle,
  const BurgersVector& burgers_vector,
  const LSMDD_Parameters& lsmdd_params)
{
  // preparations for calculation
  const double shear_modulus = lsmdd_params.getShearModulus();
  const double poisson_ratio = lsmdd_params.getPoissonRatio();
  const double one_over_one_minus_poisson_ratio = 1.0/(1.0-poisson_ratio);
  const double two_times_shear_modulus = 2.0*shear_modulus;
  const double b1 = burgers_vector[0]; 
  const double b2 = burgers_vector[1]; 
  const double b3 = burgers_vector[2]; 

  /*
   * Compute stresses in frequency space
   */ 
  int idx;

  // real and imaginary parts of Fourier coefficients for dislocation line
  double d1_re, d2_re, d3_re;  
  double d1_im, d2_im, d3_im;  

  // Fourier exponents
  double k1, k2, k3;           

  // get global box and Nyquist limits for grid
  int N1, N2, N3;           
  int f1, f2, f3;           
  N1 = d_global_box.numberCells(0);
  N2 = d_global_box.numberCells(1);
  N3 = d_global_box.numberCells(2);
  f1 = N1/2;
  f2 = N2/2;
  f3 = N3/2;

  // get dimensions of global grid (required to compute wavenumbers)
  Pointer< CartesianGridGeometry<3> > grid_geometry =
    d_patch_hierarchy->getGridGeometry();
  const double* XLower = grid_geometry->getXLower();
  const double* XUpper = grid_geometry->getXUpper();
  double inv_domain_width_x = 1.0/(XUpper[0] - XLower[0]);
  double inv_domain_width_y = 1.0/(XUpper[1] - XLower[1]);
  double inv_domain_width_z = 1.0/(XUpper[2] - XLower[2]);

  // get local box dimensions
  IntVector<3> local_box_lower = d_local_box.lower();
  IntVector<3> local_box_upper = d_local_box.upper();
  IntVector<3> global_box_lower = d_global_box.lower();
  int ilo = local_box_lower(0)-global_box_lower(0);  
  int jlo = local_box_lower(1)-global_box_lower(1);    
  int klo = local_box_lower(2)-global_box_lower(2);    
  int ihi = local_box_upper(0)-global_box_lower(0);  
  int jhi = local_box_upper(1)-global_box_lower(1);  
  int khi = local_box_upper(2)-global_box_lower(2);  


  // initialize debugging variables
  double err1 = 0.0;
  double err2 = 0.0;
  double err3 = 0.0;

  /*
   * compute FFT of all stress components
   *
   * NOTES:  
   * (1) k1, k2, and k3 are scaled to account for the size of the
   *     physical domain in the three coordinate directions.
   * (2) The factor of 2*pi is absorbed into d_fft_scale_factor.
   *
   */
  idx = 0;
  for (int k = klo; k <= khi; k++) {
    k3 = ( (k <= f3) ? k*inv_domain_width_z : (k-N3)*inv_domain_width_z );

    for (int j = jlo; j <= jhi; j++) {
      k2 = ( (j <= f2) ? j*inv_domain_width_y : (j-N2)*inv_domain_width_y );

      for (int i = ilo; i <= ihi; i++) {
        k1 = ( (i <= f1) ? i*inv_domain_width_x : (i-N1)*inv_domain_width_x );

        if ( (i+j+k) != 0 ) { // non-zero wave vector

          // when norm_wave_vec_sq is not zero, then use the 
          // formula from Xiang et. al (2003)

          // get Fourier coefficients for dislocation line
          d1_re = d_dislocation_line_fft_data[0][idx].re;
          d1_im = d_dislocation_line_fft_data[0][idx].im;
          d2_re = d_dislocation_line_fft_data[1][idx].re;
          d2_im = d_dislocation_line_fft_data[1][idx].im;
          d3_re = d_dislocation_line_fft_data[2][idx].re;
          d3_im = d_dislocation_line_fft_data[2][idx].im;

          // compute magnitude of the wave vector 
          double inv_norm_wave_vec_sq = 1.0/(k1*k1+k2*k2+k3*k3);

          // compute (k cross b)
          double kxb_1, kxb_2, kxb_3;
          kxb_1 = k2*b3-k3*b2;
          kxb_2 = k3*b1-k1*b3;
          kxb_3 = k1*b2-k2*b1;

          // compute (k cross b) dot d
          double kxb_dot_d_re = kxb_1*d1_re + kxb_2*d2_re + kxb_3*d3_re;
          double kxb_dot_d_im = kxb_1*d1_im + kxb_2*d2_im + kxb_3*d3_im;

          // compute stress in fourier space
          d_stress_field_fft_data[0][idx].re = 
            - two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( kxb_1*d1_im - one_over_one_minus_poisson_ratio
                           *(k2*k2+k3*k3)*kxb_dot_d_im*inv_norm_wave_vec_sq );
          d_stress_field_fft_data[0][idx].im = 
            two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( kxb_1*d1_re - one_over_one_minus_poisson_ratio
                           *(k2*k2+k3*k3)*kxb_dot_d_re*inv_norm_wave_vec_sq );

          d_stress_field_fft_data[1][idx].re = 
            -two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( kxb_2*d2_im - one_over_one_minus_poisson_ratio
                           *(k3*k3+k1*k1)*kxb_dot_d_im*inv_norm_wave_vec_sq );
          d_stress_field_fft_data[1][idx].im = 
            two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( kxb_2*d2_re - one_over_one_minus_poisson_ratio
                           *(k3*k3+k1*k1)*kxb_dot_d_re*inv_norm_wave_vec_sq );

          d_stress_field_fft_data[2][idx].re = 
            -two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( kxb_3*d3_im - one_over_one_minus_poisson_ratio
                           *(k1*k1+k2*k2)*kxb_dot_d_im*inv_norm_wave_vec_sq );
          d_stress_field_fft_data[2][idx].im = 
            two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( kxb_3*d3_re - one_over_one_minus_poisson_ratio
                           *(k1*k1+k2*k2)*kxb_dot_d_re*inv_norm_wave_vec_sq );

          d_stress_field_fft_data[3][idx].re = 
            -two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( 0.5*(kxb_3*d2_im + kxb_2*d3_im)
            + one_over_one_minus_poisson_ratio*k2*k3
              *kxb_dot_d_im*inv_norm_wave_vec_sq );
          d_stress_field_fft_data[3][idx].im = 
            two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( 0.5*(kxb_3*d2_re + kxb_2*d3_re)
            + one_over_one_minus_poisson_ratio*k2*k3
              *kxb_dot_d_re*inv_norm_wave_vec_sq );

          d_stress_field_fft_data[4][idx].re = 
            -two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( 0.5*(kxb_1*d3_im + kxb_3*d1_im)
            + one_over_one_minus_poisson_ratio*k3*k1
              *kxb_dot_d_im*inv_norm_wave_vec_sq );
          d_stress_field_fft_data[4][idx].im = 
            two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( 0.5*(kxb_1*d3_re + kxb_3*d1_re)
            + one_over_one_minus_poisson_ratio*k3*k1
              *kxb_dot_d_re*inv_norm_wave_vec_sq );

          d_stress_field_fft_data[5][idx].re = 
            -two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( 0.5*(kxb_2*d1_im + kxb_1*d2_im)
            + one_over_one_minus_poisson_ratio*k1*k2
              *kxb_dot_d_im*inv_norm_wave_vec_sq );
          d_stress_field_fft_data[5][idx].im = 
            two_times_shear_modulus * inv_norm_wave_vec_sq
          * ( 0.5*(kxb_2*d1_re + kxb_1*d2_re)
            + one_over_one_minus_poisson_ratio*k1*k2
              *kxb_dot_d_re*inv_norm_wave_vec_sq );


          if (lsmdd_params.debugOn()) {

            // check if div(sigma) = 0 in Fourier space

            double err_tmp;
            err_tmp = fabs( k1*d_stress_field_fft_data[0][idx].re
                          + k2*d_stress_field_fft_data[5][idx].re
                          + k3*d_stress_field_fft_data[4][idx].re )
                    + fabs( k1*d_stress_field_fft_data[0][idx].im
                          + k2*d_stress_field_fft_data[5][idx].im
                          + k3*d_stress_field_fft_data[4][idx].im );
            if (err_tmp > err1) err1 = err_tmp; 
            err_tmp = fabs( k1*d_stress_field_fft_data[5][idx].re
                          + k2*d_stress_field_fft_data[1][idx].re
                          + k3*d_stress_field_fft_data[3][idx].re )
                    + fabs( k1*d_stress_field_fft_data[5][idx].im
                          + k2*d_stress_field_fft_data[1][idx].im
                          + k3*d_stress_field_fft_data[3][idx].im );
            if (err_tmp > err2) err2 = err_tmp;
            err_tmp = fabs( k1*d_stress_field_fft_data[4][idx].re
                          + k2*d_stress_field_fft_data[3][idx].re
                          + k3*d_stress_field_fft_data[2][idx].re )
                    + fabs( k1*d_stress_field_fft_data[4][idx].im
                          + k2*d_stress_field_fft_data[3][idx].im
                          + k3*d_stress_field_fft_data[2][idx].im );
            if (err_tmp > err3) err3 = err_tmp;

          } // end debug mode: check div(sigma) = 0

        } else { 

          // when the wave vector is zero, the fourier 
          // coefficients are also zero

          d_stress_field_fft_data[0][idx].re = 0.0;
          d_stress_field_fft_data[0][idx].im = 0.0;
          d_stress_field_fft_data[1][idx].re = 0.0;
          d_stress_field_fft_data[1][idx].im = 0.0;
          d_stress_field_fft_data[2][idx].re = 0.0;
          d_stress_field_fft_data[2][idx].im = 0.0;
          d_stress_field_fft_data[3][idx].re = 0.0;
          d_stress_field_fft_data[3][idx].im = 0.0;
          d_stress_field_fft_data[4][idx].re = 0.0;
          d_stress_field_fft_data[4][idx].im = 0.0;
          d_stress_field_fft_data[5][idx].re = 0.0;
          d_stress_field_fft_data[5][idx].im = 0.0;

        } // end setting stress field in fourier space

        // increment data array index
        idx++;

      }
    }
  } // end loop over grid

  // output debugging information if debugging is activated
  if (lsmdd_params.debugOn()) {
    plog << "Error in div(sigma) = 0 in fourier space" << endl;
    plog << "  11,12,13: " << err1*d_fft_scale_factor/shear_modulus << endl;
    plog << "  21,22,23: " << err2*d_fft_scale_factor/shear_modulus << endl;
    plog << "  31,32,33: " << err3*d_fft_scale_factor/shear_modulus << endl;
  }

}


/* computeStressOnPatchMemoryEfficient() */
void PeriodicDislocationArrayElasticStressModule::
computeStressOnPatchMemoryEfficient(
  Pointer< Patch<3> > patch,
  STRESS_COMPONENT_TYPE stress_field_component,
  FFT_DATA *stress_field_fft_data,
  const int dislocation_line_handle,
  const BurgersVector& burgers_vector,
  const LSMDD_Parameters& lsmdd_params)
{
  // preparations for calculation
  const double shear_modulus = lsmdd_params.getShearModulus();
  const double poisson_ratio = lsmdd_params.getPoissonRatio();
  const double one_over_one_minus_poisson_ratio = 1.0/(1.0-poisson_ratio);
  const double b1 = burgers_vector[0]; 
  const double b2 = burgers_vector[1]; 
  const double b3 = burgers_vector[2]; 

  /*
   * Compute stresses in frequency space
   */ 
  int idx;

  // cache 2.0*shear_modulus since it shows up so often
  const double two_times_shear_modulus = 2.0*shear_modulus;

  // real and imaginary parts of Fourier coefficients for dislocation line
  double d1_re, d2_re, d3_re;  
  double d1_im, d2_im, d3_im;  

  // Fourier exponents
  double k1, k2, k3;           

  // get global box and Nyquist limits for grid
  int N1, N2, N3;           
  int f1, f2, f3;           
  N1 = d_global_box.numberCells(0);
  N2 = d_global_box.numberCells(1);
  N3 = d_global_box.numberCells(2);
  f1 = N1/2;
  f2 = N2/2;
  f3 = N3/2;

  // get dimensions of global grid (required to compute wavenumbers)
  Pointer< CartesianGridGeometry<3> > grid_geometry =
    d_patch_hierarchy->getGridGeometry();
  const double* XLower = grid_geometry->getXLower();
  const double* XUpper = grid_geometry->getXUpper();
  double inv_domain_width_x = 1.0/(XUpper[0] - XLower[0]);
  double inv_domain_width_y = 1.0/(XUpper[1] - XLower[1]);
  double inv_domain_width_z = 1.0/(XUpper[2] - XLower[2]);

  // get local box dimensions
  IntVector<3> local_box_lower = d_local_box.lower();
  IntVector<3> local_box_upper = d_local_box.upper();
  IntVector<3> global_box_lower = d_global_box.lower();
  int ilo = local_box_lower(0)-global_box_lower(0);  
  int jlo = local_box_lower(1)-global_box_lower(1);    
  int klo = local_box_lower(2)-global_box_lower(2);    
  int ihi = local_box_upper(0)-global_box_lower(0);  
  int jhi = local_box_upper(1)-global_box_lower(1);  
  int khi = local_box_upper(2)-global_box_lower(2);  

  /*
   * compute FFT of specified stress field component 
   *
   * NOTES:
   * (1) k1, k2, and k3 are scaled to account for the size of the
   *     physical domain in the three coordinate directions.
   * (2) The factor of 2*pi is absorbed into d_fft_scale_factor.
   *
   */
  switch (stress_field_component) {

    case LSMDD::SIGMA_11: {

      idx = 0;
      for (int k = klo; k <= khi; k++) {
        k3 = ( (k <= f3) ? k*inv_domain_width_z : (k-N3)*inv_domain_width_z );

        for (int j = jlo; j <= jhi; j++) {
          k2 = ( (j <= f2) ? j*inv_domain_width_y : (j-N2)*inv_domain_width_y );

          for (int i = ilo; i <= ihi; i++) {
            k1 = ( (i <= f1) ? i*inv_domain_width_x : 
                               (i-N1)*inv_domain_width_x );

            if ( (i+j+k) != 0 ) { // non-zero wave vector

              // when norm_wave_vec_sq is not zero, then use the 
              // formula from Xiang et. al (2003)

              // get Fourier coefficients for dislocation line
              d1_re = d_dislocation_line_fft_data[0][idx].re;
              d1_im = d_dislocation_line_fft_data[0][idx].im;
              d2_re = d_dislocation_line_fft_data[1][idx].re;
              d2_im = d_dislocation_line_fft_data[1][idx].im;
              d3_re = d_dislocation_line_fft_data[2][idx].re;
              d3_im = d_dislocation_line_fft_data[2][idx].im;

              // compute magnitude of the wave vector 
              double inv_norm_wave_vec_sq = 1.0/(k1*k1+k2*k2+k3*k3);

              // compute (k cross b)
              double kxb_1, kxb_2, kxb_3;
              kxb_1 = k2*b3-k3*b2;
              kxb_2 = k3*b1-k1*b3;
              kxb_3 = k1*b2-k2*b1;

              // compute (k cross b) dot d
              double kxb_dot_d_re = kxb_1*d1_re + kxb_2*d2_re + kxb_3*d3_re;
              double kxb_dot_d_im = kxb_1*d1_im + kxb_2*d2_im + kxb_3*d3_im;

              // compute stress in fourier space
              stress_field_fft_data[idx].re = 
                - two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( kxb_1*d1_im - one_over_one_minus_poisson_ratio
                               *(k2*k2+k3*k3)*kxb_dot_d_im
                               *inv_norm_wave_vec_sq );
              stress_field_fft_data[idx].im = 
                two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( kxb_1*d1_re - one_over_one_minus_poisson_ratio
                               *(k2*k2+k3*k3)*kxb_dot_d_re
                               *inv_norm_wave_vec_sq );

            } else { 

              // when the wave vector is zero, the fourier 
              // coefficients are also zero

              stress_field_fft_data[idx].re = 0.0;
              stress_field_fft_data[idx].im = 0.0;

            } // end setting stress field in fourier space

            // increment data array index
            idx++;

          }
        }
      } // end loop over grid

      break;

    } // end case: LSMDD::SIGMA_11

    case LSMDD::SIGMA_22: {

      idx = 0;
      for (int k = klo; k <= khi; k++) {
        k3 = ( (k <= f3) ? k*inv_domain_width_z : (k-N3)*inv_domain_width_z );

        for (int j = jlo; j <= jhi; j++) {
          k2 = ( (j <= f2) ? j*inv_domain_width_y : (j-N2)*inv_domain_width_y );

          for (int i = ilo; i <= ihi; i++) {
            k1 = ( (i <= f1) ? i*inv_domain_width_x : 
                               (i-N1)*inv_domain_width_x );

            if ( (i+j+k) != 0 ) { // non-zero wave vector

              // when norm_wave_vec_sq is not zero, then use the 
              // formula from Xiang et. al (2003)

              // get Fourier coefficients for dislocation line
              d1_re = d_dislocation_line_fft_data[0][idx].re;
              d1_im = d_dislocation_line_fft_data[0][idx].im;
              d2_re = d_dislocation_line_fft_data[1][idx].re;
              d2_im = d_dislocation_line_fft_data[1][idx].im;
              d3_re = d_dislocation_line_fft_data[2][idx].re;
              d3_im = d_dislocation_line_fft_data[2][idx].im;

              // compute magnitude of the wave vector 
              double inv_norm_wave_vec_sq = 1.0/(k1*k1+k2*k2+k3*k3);

              // compute (k cross b)
              double kxb_1, kxb_2, kxb_3;
              kxb_1 = k2*b3-k3*b2;
              kxb_2 = k3*b1-k1*b3;
              kxb_3 = k1*b2-k2*b1;

              // compute (k cross b) dot d
              double kxb_dot_d_re = kxb_1*d1_re + kxb_2*d2_re + kxb_3*d3_re;
              double kxb_dot_d_im = kxb_1*d1_im + kxb_2*d2_im + kxb_3*d3_im;

              // compute stress in fourier space
              stress_field_fft_data[idx].re = 
                -two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( kxb_2*d2_im - one_over_one_minus_poisson_ratio
                               *(k3*k3+k1*k1)*kxb_dot_d_im
                               *inv_norm_wave_vec_sq );
              stress_field_fft_data[idx].im = 
                two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( kxb_2*d2_re - one_over_one_minus_poisson_ratio
                               *(k3*k3+k1*k1)*kxb_dot_d_re
                               *inv_norm_wave_vec_sq );

            } else { 

              // when the wave vector is zero, the fourier 
              // coefficients are also zero

              stress_field_fft_data[idx].re = 0.0;
              stress_field_fft_data[idx].im = 0.0;

            } // end setting stress field in fourier space

            // increment data array index
            idx++;

          }
        }
      } // end compute FFT of sigma_22

      break;

    } // end case: LSMDD::SIGMA_22

    case LSMDD::SIGMA_33: {

      idx = 0;
      for (int k = klo; k <= khi; k++) {
        k3 = ( (k <= f3) ? k*inv_domain_width_z : (k-N3)*inv_domain_width_z );

        for (int j = jlo; j <= jhi; j++) {
          k2 = ( (j <= f2) ? j*inv_domain_width_y : (j-N2)*inv_domain_width_y );

          for (int i = ilo; i <= ihi; i++) {
            k1 = ( (i <= f1) ? i*inv_domain_width_x : 
                               (i-N1)*inv_domain_width_x );

            if ( (i+j+k) != 0 ) { // non-zero wave vector

              // when norm_wave_vec_sq is not zero, then use the 
              // formula from Xiang et. al (2003)

              // get Fourier coefficients for dislocation line
              d1_re = d_dislocation_line_fft_data[0][idx].re;
              d1_im = d_dislocation_line_fft_data[0][idx].im;
              d2_re = d_dislocation_line_fft_data[1][idx].re;
              d2_im = d_dislocation_line_fft_data[1][idx].im;
              d3_re = d_dislocation_line_fft_data[2][idx].re;
              d3_im = d_dislocation_line_fft_data[2][idx].im;

              // compute magnitude of the wave vector 
              double inv_norm_wave_vec_sq = 1.0/(k1*k1+k2*k2+k3*k3);

              // compute (k cross b)
              double kxb_1, kxb_2, kxb_3;
              kxb_1 = k2*b3-k3*b2;
              kxb_2 = k3*b1-k1*b3;
              kxb_3 = k1*b2-k2*b1;

              // compute (k cross b) dot d
              double kxb_dot_d_re = kxb_1*d1_re + kxb_2*d2_re + kxb_3*d3_re;
              double kxb_dot_d_im = kxb_1*d1_im + kxb_2*d2_im + kxb_3*d3_im;

              // compute stress in fourier space
              stress_field_fft_data[idx].re = 
                -two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( kxb_3*d3_im - one_over_one_minus_poisson_ratio
                               *(k1*k1+k2*k2)*kxb_dot_d_im
                               *inv_norm_wave_vec_sq );
              stress_field_fft_data[idx].im = 
                two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( kxb_3*d3_re - one_over_one_minus_poisson_ratio
                               *(k1*k1+k2*k2)*kxb_dot_d_re
                               *inv_norm_wave_vec_sq );
      
            } else { 

              // when the wave vector is zero, the fourier 
              // coefficients are also zero

              stress_field_fft_data[idx].re = 0.0;
              stress_field_fft_data[idx].im = 0.0;

            } // end setting stress field in fourier space

            // increment data array index
            idx++;

          }
        }
      } // end compute FFT of sigma_33

      break;

    } // end case:  LSMDD::SIGMA_33

    case LSMDD::SIGMA_23: {

      idx = 0;
      for (int k = klo; k <= khi; k++) {
        k3 = ( (k <= f3) ? k*inv_domain_width_z : (k-N3)*inv_domain_width_z );

        for (int j = jlo; j <= jhi; j++) {
          k2 = ( (j <= f2) ? j*inv_domain_width_y : (j-N2)*inv_domain_width_y );

          for (int i = ilo; i <= ihi; i++) {
            k1 = ( (i <= f1) ? i*inv_domain_width_x : 
                               (i-N1)*inv_domain_width_x );

            if ( (i+j+k) != 0 ) { // non-zero wave vector

              // when norm_wave_vec_sq is not zero, then use the 
              // formula from Xiang et. al (2003)

              // get Fourier coefficients for dislocation line
              d1_re = d_dislocation_line_fft_data[0][idx].re;
              d1_im = d_dislocation_line_fft_data[0][idx].im;
              d2_re = d_dislocation_line_fft_data[1][idx].re;
              d2_im = d_dislocation_line_fft_data[1][idx].im;
              d3_re = d_dislocation_line_fft_data[2][idx].re;
              d3_im = d_dislocation_line_fft_data[2][idx].im;

              // compute magnitude of the wave vector 
              double inv_norm_wave_vec_sq = 1.0/(k1*k1+k2*k2+k3*k3);

              // compute (k cross b)
              double kxb_1, kxb_2, kxb_3;
              kxb_1 = k2*b3-k3*b2;
              kxb_2 = k3*b1-k1*b3;
              kxb_3 = k1*b2-k2*b1;

              // compute (k cross b) dot d
              double kxb_dot_d_re = kxb_1*d1_re + kxb_2*d2_re + kxb_3*d3_re;
              double kxb_dot_d_im = kxb_1*d1_im + kxb_2*d2_im + kxb_3*d3_im;

              // compute stress in fourier space
              stress_field_fft_data[idx].re = 
                -two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( 0.5*(kxb_3*d2_im + kxb_2*d3_im)
                + one_over_one_minus_poisson_ratio*k2*k3
                  *kxb_dot_d_im*inv_norm_wave_vec_sq );
              stress_field_fft_data[idx].im = 
                two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( 0.5*(kxb_3*d2_re + kxb_2*d3_re)
                + one_over_one_minus_poisson_ratio*k2*k3
                  *kxb_dot_d_re*inv_norm_wave_vec_sq );

            } else { 

              // when the wave vector is zero, the fourier 
              // coefficients are also zero

              stress_field_fft_data[idx].re = 0.0;
              stress_field_fft_data[idx].im = 0.0;

            } // end setting stress field in fourier space

            // increment data array index
            idx++;

          }
        }
      } // end compute FFT of sigma_23

      break;

    } // end case: LSMDD::SIGMA_23

    case LSMDD::SIGMA_31: {

      idx = 0;
      for (int k = klo; k <= khi; k++) {
        k3 = ( (k <= f3) ? k*inv_domain_width_z : (k-N3)*inv_domain_width_z );

        for (int j = jlo; j <= jhi; j++) {
          k2 = ( (j <= f2) ? j*inv_domain_width_y : (j-N2)*inv_domain_width_y );

          for (int i = ilo; i <= ihi; i++) {
            k1 = ( (i <= f1) ? i*inv_domain_width_x : 
                               (i-N1)*inv_domain_width_x );

            if ( (i+j+k) != 0 ) { // non-zero wave vector

              // when norm_wave_vec_sq is not zero, then use the 
              // formula from Xiang et. al (2003)

              // get Fourier coefficients for dislocation line
              d1_re = d_dislocation_line_fft_data[0][idx].re;
              d1_im = d_dislocation_line_fft_data[0][idx].im;
              d2_re = d_dislocation_line_fft_data[1][idx].re;
              d2_im = d_dislocation_line_fft_data[1][idx].im;
              d3_re = d_dislocation_line_fft_data[2][idx].re;
              d3_im = d_dislocation_line_fft_data[2][idx].im;

              // compute magnitude of the wave vector 
              double inv_norm_wave_vec_sq = 1.0/(k1*k1+k2*k2+k3*k3);

              // compute (k cross b)
              double kxb_1, kxb_2, kxb_3;
              kxb_1 = k2*b3-k3*b2;
              kxb_2 = k3*b1-k1*b3;
              kxb_3 = k1*b2-k2*b1;

              // compute (k cross b) dot d
              double kxb_dot_d_re = kxb_1*d1_re + kxb_2*d2_re + kxb_3*d3_re;
              double kxb_dot_d_im = kxb_1*d1_im + kxb_2*d2_im + kxb_3*d3_im;

              // compute stress in fourier space
              stress_field_fft_data[idx].re = 
                -two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( 0.5*(kxb_3*d1_im + kxb_1*d3_im)
                + one_over_one_minus_poisson_ratio*k3*k1
                  *kxb_dot_d_im*inv_norm_wave_vec_sq );
              stress_field_fft_data[idx].im = 
                two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( 0.5*(kxb_3*d1_re + kxb_1*d3_re)
                + one_over_one_minus_poisson_ratio*k3*k1
                  *kxb_dot_d_re*inv_norm_wave_vec_sq );
    
            } else { 

              // when the wave vector is zero, the fourier 
              // coefficients are also zero
    
              stress_field_fft_data[idx].re = 0.0;
              stress_field_fft_data[idx].im = 0.0;
    
            } // end setting stress field in fourier space

            // increment data array index
            idx++;

          }
        }
      } // end compute FFT of sigma_31

      break;

    } // end case: LSMDD::SIGMA_31

    case LSMDD::SIGMA_12: {

      idx = 0;
      for (int k = klo; k <= khi; k++) {
        k3 = ( (k <= f3) ? k*inv_domain_width_z : (k-N3)*inv_domain_width_z );

        for (int j = jlo; j <= jhi; j++) {
          k2 = ( (j <= f2) ? j*inv_domain_width_y : (j-N2)*inv_domain_width_y );

          for (int i = ilo; i <= ihi; i++) {
            k1 = ( (i <= f1) ? i*inv_domain_width_x : 
                               (i-N1)*inv_domain_width_x );

            if ( (i+j+k) != 0 ) { // non-zero wave vector

              // when norm_wave_vec_sq is not zero, then use the 
              // formula from Xiang et. al (2003)

              // get Fourier coefficients for dislocation line
              d1_re = d_dislocation_line_fft_data[0][idx].re;
              d1_im = d_dislocation_line_fft_data[0][idx].im;
              d2_re = d_dislocation_line_fft_data[1][idx].re;
              d2_im = d_dislocation_line_fft_data[1][idx].im;
              d3_re = d_dislocation_line_fft_data[2][idx].re;
              d3_im = d_dislocation_line_fft_data[2][idx].im;

              // compute magnitude of the wave vector 
              double inv_norm_wave_vec_sq = 1.0/(k1*k1+k2*k2+k3*k3);

              // compute (k cross b)
              double kxb_1, kxb_2, kxb_3;
              kxb_1 = k2*b3-k3*b2;
              kxb_2 = k3*b1-k1*b3;
              kxb_3 = k1*b2-k2*b1;

                // compute (k cross b) dot d
              double kxb_dot_d_re = kxb_1*d1_re + kxb_2*d2_re + kxb_3*d3_re;
              double kxb_dot_d_im = kxb_1*d1_im + kxb_2*d2_im + kxb_3*d3_im;

              // compute stress in fourier space
              stress_field_fft_data[idx].re = 
                -two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( 0.5*(kxb_2*d1_im + kxb_1*d2_im)
                + one_over_one_minus_poisson_ratio*k1*k2
                  *kxb_dot_d_im*inv_norm_wave_vec_sq );
              stress_field_fft_data[idx].im = 
                two_times_shear_modulus * inv_norm_wave_vec_sq
              * ( 0.5*(kxb_2*d1_re + kxb_1*d2_re)
                + one_over_one_minus_poisson_ratio*k1*k2
                  *kxb_dot_d_re*inv_norm_wave_vec_sq );

            } else { 

              // when the wave vector is zero, the fourier 
              // coefficients are also zero

              stress_field_fft_data[idx].re = 0.0;
              stress_field_fft_data[idx].im = 0.0;

            } // end setting stress field in fourier space

            // increment data array index
            idx++;

          }
        }
      } // end compute FFT of sigma_12

      break;

    } // end case: LSMDD::SIGMA_12

  } // end switch on stress_field_component

}


/* allocateFFTData() */
void PeriodicDislocationArrayElasticStressModule::
allocateFFTData()
{
  if (!d_fft_data_allocated) {

    // get local box size
    const int box_size = d_local_box.size();

    // initialize pointers to FFT_DATA to NULL
    for (int i=0; i<ELASTIC_STRESS_MODULE_DIM; i++) { 
      d_dislocation_line_fft_data[i] = ELASTIC_STRESS_MODULE_NULL;
    }
    for (int i=0; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 
      d_stress_field_fft_data[i] = ELASTIC_STRESS_MODULE_NULL;
    }
  
    // attempt allocate memory for dislocation line FFT data
    for (int i=0; i<ELASTIC_STRESS_MODULE_DIM; i++) { 
      d_dislocation_line_fft_data[i] = new FFT_DATA[box_size];
    }

    // attempt allocate memory for stress field FFT data
    if (d_conserve_memory) {
      d_stress_field_fft_data[0] = new FFT_DATA[box_size];
      for (int i=1; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 
        d_stress_field_fft_data[i] = d_stress_field_fft_data[0];
      }
    } else {
      for (int i=0; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 
        d_stress_field_fft_data[i] = new FFT_DATA[box_size];
      }
    }

    // check memory allocation
    bool memory_allocation_failed = false;
    for (int i=0; i<ELASTIC_STRESS_MODULE_DIM; i++) { 
      if (!d_dislocation_line_fft_data[i]) memory_allocation_failed = true;
    }
    for (int i=0; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 
      if (!d_stress_field_fft_data[i]) memory_allocation_failed = true;
    }
    if (memory_allocation_failed) {
      // free successfully allocated memory
      for (int i=0; i<ELASTIC_STRESS_MODULE_DIM; i++) { 
        if (d_dislocation_line_fft_data[i]) 
          delete [] d_dislocation_line_fft_data[i];
      }
      for (int i=0; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 
      if (d_stress_field_fft_data[i]) delete [] d_stress_field_fft_data[i];
      }
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << ":allocateFFTData()"
                << ": Memory allocation for FFT data failed."
                << endl);
    } // end case memory allocation failed
  
    // set d_fft_data_allocated to true
    d_fft_data_allocated = true;
  }
}


/* deallocateFFTData() */
void PeriodicDislocationArrayElasticStressModule::
deallocateFFTData()
{
  if (d_fft_data_allocated) {

    // free memory for FFT data
    for (int i=0; i<ELASTIC_STRESS_MODULE_DIM; i++) { 
      delete [] d_dislocation_line_fft_data[i];
      d_dislocation_line_fft_data[i] = ELASTIC_STRESS_MODULE_NULL;
    }
    if (d_conserve_memory) {
      delete [] d_stress_field_fft_data[0];
      for (int i=0; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 
        d_stress_field_fft_data[i] = ELASTIC_STRESS_MODULE_NULL;
      }
    } else {
      for (int i=0; i<ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS; i++) { 
        delete [] d_stress_field_fft_data[i];
        d_stress_field_fft_data[i] = ELASTIC_STRESS_MODULE_NULL;
      }
    }

    // set d_fft_data_allocated to false
    d_fft_data_allocated = false;
  }
}


/* addStressFieldToSAMRAIPatchData() 
 *
 * NOTES: 
 *  - we need to rescale the results since FFTW
 *    computes an unnormalized transform in terms
 *    of the oscillation frequency instead of the
 *    angular frequency used by Xiang et. al. (2003).
 *  - the result is purely real, so we ignore the
 *    imaginary part of the result
 */
void PeriodicDislocationArrayElasticStressModule::
addStressFieldToSAMRAIPatchData(
  Pointer< Patch<3> > patch,
  const LSMDD_Parameters& lsmdd_params)
{
  // get stress field PatchData
  Pointer< CellData<3,double> > stress_field_data =
    patch->getPatchData( d_stress_field_handle );

  // get box and ghost box for stress field data
  Box<3> stress_field_interior_box = 
    stress_field_data->getBox();
  const IntVector<3> stress_field_interior_box_dimensions = 
    stress_field_interior_box.numberCells();

  Box<3> stress_field_ghostbox = 
    stress_field_data->getGhostBox();
  const IntVector<3> stress_field_ghostbox_dims = 
    stress_field_ghostbox.numberCells();
  const IntVector<3> stress_field_ghostcell_width= 
    stress_field_data->getGhostCellWidth();

  // get pointer to actual data
  double* stress_field[ELASTIC_STRESS_MODULE_NUM_STRESS_COMPONENTS];
  stress_field[0] = stress_field_data->getPointer(0);
  stress_field[1] = stress_field_data->getPointer(1);
  stress_field[2] = stress_field_data->getPointer(2);
  stress_field[3] = stress_field_data->getPointer(3);
  stress_field[4] = stress_field_data->getPointer(4);
  stress_field[5] = stress_field_data->getPointer(5);

  int idx_interior = 0;
  int idx_ghostbox = 0;

  // add ghostcell width in z-direction times number of cells in
  // xy-plane to get to starting plane of interior data
  idx_ghostbox += stress_field_ghostcell_width(2)
                 *stress_field_ghostbox_dims(0)
                 *stress_field_ghostbox_dims(1);

  for (int k = 0; k < stress_field_interior_box_dimensions(2); k++) {

    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of interior data
    idx_ghostbox += stress_field_ghostcell_width(1)
                   *stress_field_ghostbox_dims(0);

    for (int j = 0; j < stress_field_interior_box_dimensions(1); j++) {

      // add ghostcell width in x-direction to get to start of 
      // interior data
      idx_ghostbox += stress_field_ghostcell_width(0);

      for (int i = 0; i < stress_field_interior_box_dimensions(0); i++) {
        stress_field[0][idx_ghostbox] += d_fft_scale_factor
         *d_stress_field_fft_data[0][idx_interior].re;
        stress_field[1][idx_ghostbox] += d_fft_scale_factor
         *d_stress_field_fft_data[1][idx_interior].re;
        stress_field[2][idx_ghostbox] += d_fft_scale_factor
         *d_stress_field_fft_data[2][idx_interior].re;
        stress_field[3][idx_ghostbox] += d_fft_scale_factor
         *d_stress_field_fft_data[3][idx_interior].re;
        stress_field[4][idx_ghostbox] += d_fft_scale_factor
         *d_stress_field_fft_data[4][idx_interior].re;
        stress_field[5][idx_ghostbox] += d_fft_scale_factor
         *d_stress_field_fft_data[5][idx_interior].re;

        if (lsmdd_params.debugOn()) {
          Pointer< CartesianGridGeometry<3> > grid_geometry = 
            d_patch_hierarchy->getGridGeometry();
          const double* dX = grid_geometry->getDx();
          double tol = dX[0]/d_fft_scale_factor;
          if (   (fabs(d_stress_field_fft_data[0][idx_interior].im) > tol)
              || (fabs(d_stress_field_fft_data[1][idx_interior].im) > tol)
              || (fabs(d_stress_field_fft_data[2][idx_interior].im) > tol)
              || (fabs(d_stress_field_fft_data[3][idx_interior].im) > tol)
              || (fabs(d_stress_field_fft_data[4][idx_interior].im) > tol)
              || (fabs(d_stress_field_fft_data[5][idx_interior].im) > tol) ) {
            pout << "ERROR: Imaginary component of stress nonzero!" << endl;
            pout << d_fft_scale_factor
                   *d_stress_field_fft_data[0][idx_interior].im << ","
                 << d_fft_scale_factor
                   *d_stress_field_fft_data[1][idx_interior].im << ","
                 << d_fft_scale_factor
                   *d_stress_field_fft_data[2][idx_interior].im << ","
                 << d_fft_scale_factor
                   *d_stress_field_fft_data[3][idx_interior].im << ","
                 << d_fft_scale_factor
                   *d_stress_field_fft_data[4][idx_interior].im << ","
                 << d_fft_scale_factor
                   *d_stress_field_fft_data[5][idx_interior].im << endl;
           }
         }

        // update array indices
        idx_interior++;
        idx_ghostbox++;

      } 

      // add ghostcell width in x-direction to get to start of next 
      // row of SAMRAI data
      idx_ghostbox += stress_field_ghostcell_width(0);

    } 

    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of SAMRAI data
    idx_ghostbox += stress_field_ghostcell_width(1)
                   *stress_field_ghostbox_dims(0);

  } // end loop over grid
} 


/* addStressFieldComponentToSAMRAIPatchData() 
 *
 * NOTES: 
 *  - we need to rescale the results since FFTW
 *    computes an unnormalized transform in terms
 *    of the oscillation frequency instead of the
 *    angular frequency used by Xiang et. al. (2003).
 *  - the result is purely real, so we ignore the
 *    imaginary part of the result
 */
void PeriodicDislocationArrayElasticStressModule::
addStressFieldComponentToSAMRAIPatchData(
  Pointer< Patch<3> > patch,
  FFT_DATA *stress_field_fft_data,
  const STRESS_COMPONENT_TYPE stress_component,
  const LSMDD_Parameters& lsmdd_params)
{
  // get stress field PatchData
  Pointer< CellData<3,double> > stress_field_data =
    patch->getPatchData( d_stress_field_handle );

  // get box and ghost box for stress field data
  Box<3> stress_field_interior_box = 
    stress_field_data->getBox();
  const IntVector<3> stress_field_interior_box_dimensions = 
    stress_field_interior_box.numberCells();

  Box<3> stress_field_ghostbox = 
    stress_field_data->getGhostBox();
  const IntVector<3> stress_field_ghostbox_dims = 
    stress_field_ghostbox.numberCells();
  const IntVector<3> stress_field_ghostcell_width= 
    stress_field_data->getGhostCellWidth();

  // get pointer to actual data
  double* stress_field;
  stress_field = stress_field_data->getPointer(stress_component);

  int idx_interior = 0;
  int idx_ghostbox = 0;

  // add ghostcell width in z-direction times number of cells in
  // xy-plane to get to starting plane of interior data
  idx_ghostbox += stress_field_ghostcell_width(2)
                 *stress_field_ghostbox_dims(0)
                 *stress_field_ghostbox_dims(1);

  for (int k = 0; k < stress_field_interior_box_dimensions(2); k++) {

    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of interior data
    idx_ghostbox += stress_field_ghostcell_width(1)
                   *stress_field_ghostbox_dims(0);

    for (int j = 0; j < stress_field_interior_box_dimensions(1); j++) {

      // add ghostcell width in x-direction to get to start of 
      // interior data
      idx_ghostbox += stress_field_ghostcell_width(0);

      for (int i = 0; i < stress_field_interior_box_dimensions(0); i++) {
        stress_field[idx_ghostbox] += d_fft_scale_factor
         *stress_field_fft_data[idx_interior].re;

        if (lsmdd_params.debugOn()) {
          Pointer< CartesianGridGeometry<3> > grid_geometry = 
            d_patch_hierarchy->getGridGeometry();
          const double* dX = grid_geometry->getDx();
          double tol = dX[0]/d_fft_scale_factor;
          if (fabs(stress_field_fft_data[idx_interior].im) > tol) {
            pout << "ERROR: Imaginary component of stress nonzero!" << endl;
            pout << d_fft_scale_factor*stress_field_fft_data[idx_interior].im
                 << endl;
          }
        }

        // update array indices
        idx_interior++;
        idx_ghostbox++;

      } 

      // add ghostcell width in x-direction to get to start of next 
      // row of SAMRAI data
      idx_ghostbox += stress_field_ghostcell_width(0);

    } 

    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of SAMRAI data
    idx_ghostbox += stress_field_ghostcell_width(1)
                   *stress_field_ghostbox_dims(0);

  } // end loop over grid
} 

/* initializeElasticStressModule() */
void PeriodicDislocationArrayElasticStressModule::
initializeElasticStressModule()
{
  // parameter check
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  if (num_levels > 1) {
    TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
              << "initializeElasticStressModule():"
              << " AMR is NOT currently supported."
              << endl);
  }

  // compute local index space owned by this processor
  Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(0);
  bool patch_found = false;
  for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
    const int pn = *pi;
    Pointer< Patch<3> > patch = level->getPatch(pn);
    if ( patch.isNull() ) {
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << "initializeElasticStressModule():"
                << ": Cannot find patch. Null patch pointer."
                << endl);
    }

    if (patch_found) {
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << "initializeElasticStressModule():"
                << ": Multiple patches per processor NOT currently supported."
                << endl);
    }

    // get local index space
    d_local_box = patch->getBox();

    // set patch_found to true
    patch_found = true;
  }

  /* 
   * set up create Plimpton FFT plan
   */
  tbox::MPI::comm mpi_comm = tbox::MPI::getCommunicator();
  int internal_storage_buf_size;
  d_fft_plan = fft_3d_create_plan(
    mpi_comm, 
    d_global_box.numberCells(0),
    d_global_box.numberCells(1),
    d_global_box.numberCells(2),
    d_local_box.lower(0), d_local_box.upper(0),
    d_local_box.lower(1), d_local_box.upper(1),
    d_local_box.lower(2), d_local_box.upper(2),
    d_local_box.lower(0), d_local_box.upper(0),
    d_local_box.lower(1), d_local_box.upper(1),
    d_local_box.lower(2), d_local_box.upper(2),
    ELASTIC_STRESS_MODULE_FFT_NO_SCALING,
    ELASTIC_STRESS_MODULE_FFT_NO_PERMUTE,
    &internal_storage_buf_size);
  if (!d_fft_plan) { // case: NULL FFT plan
      TBOX_ERROR(  "PeriodicDislocationArrayElasticStressModule::"
                << "initializeElasticStressModule():"
                << ": creation of parallel FFT plan failed."
                << endl);
  }

  // allocate FFT data if not using dynamic memory allocation
  if (!d_use_dynamic_memory_allocation) {
    allocateFFTData();
  }

  // allocate memory for stress fields
  level->allocatePatchData(d_stress_field_handle);

  d_initialization_complete = true;
}

} // end LSMDD namespace
