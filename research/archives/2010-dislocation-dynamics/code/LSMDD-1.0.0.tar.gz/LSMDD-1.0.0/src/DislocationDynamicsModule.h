/*
 * File:        DislocationDynamicsModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 379 $
 * Modified:    $Date: 2007-08-07 10:02:34 -0400 (Tue, 07 Aug 2007) $
 * Description: Header file for the DislocationDynamicsModule class
 */

#ifndef included_DislocationDynamicsModule_h
#define included_DislocationDynamicsModule_h

/*! \class LSMDD::DislocationDynamicsModule
 *
 * \brief
 * The DislocationDynamicsModule class is the main class of the Level 
 * Set Method Dislocation Dynamics (LSMDD) library that orchestrates 
 * the simulation of dislocation lines represented as the intersection 
 * of the zero level set of two level set functions.  LSMDD has been 
 * specifically designed to run on parallel architectures so that ensembles 
 * of many dislocations may be simulated in a reasonable amount of time.
 *
 * The numerical algorithms underlying the LSMDD were originally developed 
 * by Xiang et. al. in their series of papers on level set method approaches
 * for simulating dislocation dynamics.  However, because there are still 
 * open research questions about how various aspects of dislocation motion 
 * and interactions, the LSMDD library has been designed to allow flexibility 
 * in how the physics of dislocations are computationally modeled.  For 
 * example, the library has been designed to allow a user to supply his/her 
 * algorithms for computing the forces on and velocity on dislocation lines.
 * 
 * The parallel level set method calculations required by LSMDD are 
 * provided by the Level Set Method Library (LSMLIB).  We have leveraged 
 * the vector level set method calculations and standard level set method
 * discretizations provided by LSMLIB.  The parallel and restart capabilities 
 * of LSMDD are provided by the Structured Adaptive Mesh Refinement
 * Application Infrastructure (SAMRAI) developed in the Center for 
 * Applied Scientific Computing at Lawrence Livermore National Laboratory.
 * It is worth mentioning that the LSMLIB also relies heavily on SAMRAI
 * for its parallel and restart capabilities.
 *
 * For more details about the numerical algorithms used by specific
 * elastic stress modules or dislocation force modules, see the 
 * documentation for those modules.
 *
 *
 * <h3> User-specified parameters (input database field) </h3>
 *
 * When using the DislocationDynamicsModule, it is possible to modify 
 * the behavior of the module through an input file.  The input data 
 * parameters available for/required by the user are described below. 
 * In the input file, the parameters for the components of the 
 * DislocationDynamicsModule must each have their own separate 
 * sub-databases.  That is, the input file should have the following 
 * form:
 *
 * <pre>
 * DislocationDynamicsModule {
 *
 *   ... input parameters for DislocationDynamicsModule ...
 *
 *   LSMDD_Parameters {
 *     ... input parameters for LSMDD_Parameters ...
 *   }
 *
 *   LevelSetMethodAlgorithm {
 *
 *     LevelSetFunctionIntegrator {
 *       ... input parameters for LevelSetFunctionIntegrator ...
 *     }
 * 
 *     LevelSetMethodGriddingAlgorithm {
 *       ... input parameters LevelSetMethodGriddingAlgorithm ...
 *     } 
 *
 *   } // end input database for LevelSetMethodAlgorithm
 *
 *   FieldExtensionAlgorithm {
 *     ... input parameters FieldExtensionAlgorithm ...
 *   } 
 *
 * } // end input database for DislocationDynamicsModule
 * </pre>
 * 
 * <h4> DislocationDynamicsModule Input Database Parameters </h4>
 * 
 *   <h5> Dislocation Dynamics Module Parameters: </h5>
 *   - num_stabilization_iterations         = number of reinitialization
 *                                            iterations to use after each 
 *                                            time step to stabilize the
 *                                            dislocation line
 *                                            (default = 4)
 *   - use_persistent_velocity_data         = flag indicating whether velocity
 *                                            data should persist between
 *                                            time steps
 *                                            (default = FALSE)
 *   - lower_bc_velocity                    = boundary conditions for 
 *                                            velocity field (used during
 *                                            velocity extension) at 
 *                                            the lower side of 
 *                                            computational domain
 *                                            (default = NONE on non-periodic
 *                                             boundaries and PERIODIC on 
 *                                             periodic boundaries)
 *   - upper_bc_velocity                    = boundary conditions for 
 *                                            velocity field (used during
 *                                            velocity extension) at 
 *                                            the upper side of 
 *                                            computational domain
 *                                            (default = NONE on non-periodic
 *                                             boundaries and PERIODIC on 
 *                                             periodic boundaries)
 *   - spatial_derivative_type              = spatial derivative type used
 *                                            in computing dislocation line
 *                                            (default = value used by 
 *                                             LevelSetMethodAlgorithm)
 *   - spatial_derivative_order             = spatial derivative order used
 *                                            in computing dislocation line
 *                                            (default = value used by 
 *                                             LevelSetMethodAlgorithm)
 *
 *   <h5> LSMDD Parameters: </h5>
 *   - shear_modulus                        = shear modulus of material
 *   - poisson_ratio                        = poisson ratio of material
 *   - glide_mobility                       = glide mobility for dislocations
 *   - climb_mobility                       = climb mobility for dislocations
 *   - core_radius                          = radius for dislocation core
 *                                            in units of length
 *   - min_dislocation_segment_length       = minimum length of dislocation
 *                                            line segment for considering the
 *                                            two endpoints of the segment
 *                                            segment as numerically distinct
 *                                            (default = 1.0e-8)
 *   - max_angle_for_pure_screw             = maximum angle between the Burgers
 *                                            vector and tangent vector for
 *                                            considering a dislocation line
 *                                            segment to be pure screw
 *                                            (default = 0.1)
 *   - debug_on                             = flag indicating whether the
 *                                            simulation should be run in
 *                                            debug mode
 *                                            (default = FALSE)
 *
 *   <h5> Level Set Method Algorithm Parameters: </h5>
 *   There are two parts to the input for the LevelSetMethodAlgorithm:
 *   LevelSetFunctionIntegrator and LevelSetMethodGriddingAlgorithm.
 *
 *   The input parameters for the LevelSetFunctionIntegrator are:
 *
 *   - start_time                           = physical start time 
 *                                            for simulation
 *   - end_time                             = physical end time 
 *                                            for simulation
 *   - spatial_derivative_type              = spatial derivative type used
 *                                            in computing spatial 
 *                                            derivatives in level set
 *                                            evolution equations
 *   - spatial_derivative_order             = spatial derivative order used
 *                                            in computing spatial 
 *                                            derivatives in level set
 *                                            evolution equations
 *   - tvd_runge_kutta_order                = order of TVD Runge-Kutta
 *                                            integration scheme to use
 *                                            when integrating level set
 *                                            evolution equations
 *   - cfl_number                           = CFL number to use for 
 *                                            evolving the level set 
 *                                            functions with an advective
 *                                            velocity, reinitialization, 
 *                                            and orthogonalization
 *   - reinitialization_interval            = number of time steps between 
 *                                            reinitialization of level
 *                                            set functions
 *   - reinitialization_max_iters           = maximum number of iterations
 *                                            to use during reinitialization 
 *                                            of level set functions
 *   - orthogonalization_interval           = number of time steps between 
 *                                            orthogonalization of the pair
 *                                            of level set functions for 
 *                                            each dislocation line
 *   - orthogonalization_max_iters          = maximum number of iterations
 *                                            to use during orthogonalization 
 *                                            of level set functions
 *   - verbose_mode                         = flag indicating whether the
 *                                            level set algorithm should
 *                                            output status information
 *                                            (default = FALSE)
 *
 *   The input parameters for the LevelSetMethodGriddingAlgorithm are:
 *
 *   - max_levels                           = maximum number of refinement 
 *                                            levels in simulation.  This 
 *                                            should ALWAYS be set to 1 for
 *                                            LSMDD simulations.
 *   - largest_patch_size                   = size of largest patch in 
 *                                            simulation.  This should
 *                                            should ALWAYS be set to be
 *                                            larger than the grid size
 *                                            of computational domain for
 *                                            LSMDD simulations.
 *
 *   <h5> Velocity Field Extension Parameters: </h5>
 *   - spatial_derivative_type              = spatial derivative type used
 *                                            in computing spatial 
 *                                            derivatives in field 
 *                                            extension equations.
 *   - spatial_derivative_order             = spatial derivative order used
 *                                            in computing spatial 
 *                                            derivatives in field
 *                                            extension equations
 *   - tvd_runge_kutta_order                = order of TVD Runge-Kutta
 *                                            integration scheme to use
 *                                            for velocity field extension
 *   - cfl_number                           = CFL number to use for 
 *                                            field extension equations
 *   - max_iterations                       = maximum number of time steps 
 *                                            to use during velocity field 
 *                                            extension
 *   - verbose_mode                         = flag indicating whether the
 *                                            field extension algorithm should
 *                                            output status information
 *                                            (default = FALSE)
 *
 *
 * <h4> Sample Input File </h4>
 * 
 *  <pre>
 *  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *  DislocationDynamicsModule { 
 *
 *    num_stabilization_iterations = 4
 *    use_persistent_velocity_data = TRUE
 *    spatial_derivative_type      = WENO
 *    spatial_derivative_order     = 5
 *
 *    LSMDD_Parameters {
 *  
 *      shear_modulus = 1.0
 *      poisson_ratio = 0.33333
 *
 *      climb_mobility = 1
 *      glide_mobility = 1 
 *
 *      core_radius = 3
 *
 *      min_dislocation_segment_length = 1e-6
 *      max_angle_for_pure_screw       = .1
 *
 *      debug_on = FALSE
 *  
 *    }
 *
 *    LevelSetMethodAlgorithm{ 
 *   
 *      LevelSetFunctionIntegrator {
 *        start_time  = 0.0
 *        end_time    = 2000.0
 *
 *        spatial_derivative_type  = "WENO"
 *        spatial_derivative_order = 5
 *        tvd_runge_kutta_order    = 3
 *        cfl_number               = 0.5
 *
 *        reinitialization_interval = 50
 *        reinitialization_max_iters = 20
 *        orthogonalization_interval = 50
 *        orthogonalization_max_iters = 20
 *
 *        verbose = FALSE
 *
 *      } // end of LevelSetFunctionIntegrator database
 *
 *
 *      LevelSetMethodGriddingAlgorithm {
 *        max_levels = 1
 *
 *        largest_patch_size {
 *           level_0 = 10000, 10000, 10000
 *        }
 *        
 *      } // end of LevelSetMethodGriddingAlgorithm database
 *
 *    } // end of LevelSetMethodAlgorithm database
 *  
 *    FieldExtensionAlgorithm {
 *
 *      spatial_derivative_type  = "WENO"
 *      spatial_derivative_order = 1
 *      tvd_runge_kutta_order    = 1
 *      cfl_number               = 0.5
 *
 *      max_iterations = 20
 *
 *      verbose_mode = TRUE
 *
 *    } // end of FieldExtensionAlgorithm database
 *
 *  } // end of DislocationDynanmicsModule database
 *
 *  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *  </pre>
 *  
 * 
 * <h3> NOTES </h3>
 *  - The reinitialization used at each time step to stabilize the 
 *    dislocation is <em>independent</em> of the reinitialization done 
 *    periodically to reset ar larger portion of the level set function 
 *    to be a signed distance function.  num_stabilization_iterations 
 *    only controls the number of iterations used for stabilization 
 *    reinitialization; the stopping criteria specified in the 
 *    LevelSetMethodAlgorithm section of the input file controls the 
 *    reinitialization that is carried out at longer intervals.
 *  - The core_radius MUST be larger than 3 times the grid spacing 
 *    (i.e. max(dx,dy,dz)).  Otherwise, an unrecoverable error will
 *    be thrown.
 *  - Because the velocity off of the dislocation lines does not have to
 *    be very accurate, higher computational performance for the simulation
 *    can be achieved by reducing the accuracy of the discretizations
 *    used for spatial derivatives and the order of the TVD Runge-Kutta
 *    time integration scheme for the FieldExtensionAlgorithm.  In 
 *    practice, using ENO1 for the spatial derivatives and first-order
 *    TVD Runge-Kutta (forward Euler) integration is usually sufficient.
 *  - The LevelSetMethodGriddingAlgorithm will throw the following
 *    warning:
 *    <pre>
 *      WARNING MESSAGE: 
 *      LSMDD_LSM_Algorithm::LevelSetMethodGriddingAlgorithm:getFromInput
 *      No `tagging_method' entry specified, so cell tagging
 *      will NOT be performed.  If you wish to invoke cell
 *      tagging, you must enter one or more valid tagging
 *      methods, of type GRADIENT_DETECTOR, RICHARDSON_EXTRAPOLATION, or 
 *      REFINE_BOXES See class header for details.
 *    </pre>
 *    It is perfectly safe to ignore this warning.
 * 
 */


// System Headers
#include <float.h>
#include <string>
#include <vector>

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "Box.h"
#include "CartesianGridGeometry.h"
#include "CellData.h"
#include "ComponentSelector.h"
#include "IntVector.h"
#include "Patch.h"
#include "PatchHierarchy.h"
#include "RefineAlgorithm.h"
#include "RefineSchedule.h"
#include "tbox/Array.h"
#include "tbox/Database.h"
#include "tbox/Pointer.h"

// Level Set Method Headers
#include "LSMLIB_config.h"
#include "BoundaryConditionModule.h"
#include "FieldExtensionAlgorithm.h"
#include "LevelSetFunctionIntegrator.h"
#include "LevelSetMethodAlgorithm.h"
#include "LevelSetMethodPatchStrategy.h"
#include "LevelSetMethodToolbox.h"
#include "LevelSetMethodVelocityFieldStrategy.h"

// LSMDD Headers
#include "LSMDD_config.h"
#include "BurgersVector.h"
#include "LSMDD_PhysicsStrategy.h"
#include "LSMDD_Parameters.h"
#include "ElasticStressStrategy.h"

// namespaces
using namespace std;
using namespace SAMRAI;
using namespace geom;
using namespace hier;
using namespace pdat;
using namespace tbox;
using namespace xfer;
using namespace LSMLIB;


/******************************************************************
 *
 * DislocationDynamicsModule Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class DislocationDynamicsModule:
  public LevelSetMethodPatchStrategy<3>,
  public LevelSetMethodVelocityFieldStrategy<3>
{
public:

  //! @{
  /*!
   ****************************************************************
   *
   * @name Type and constant definitions 
   *
   ****************************************************************/
 
  /*! \enum VISUALIZATION_FILE_FORMAT
   *
   * Enumerated type for the different visualization file formats
   *
   */
  typedef enum { ASCII = 0, 
                 BINARY = 1 } VISUALIZATION_FILE_FORMAT;

  //! @}


  //! @{
  /*!
   ****************************************************************
   *    
   * @name Constructor and destructor
   *    
   ****************************************************************/ 
  
  /*!
   * The constructor creates a LevelSetMethodAlgorithm to track the
   * motion of dislocation lines during the simulation, creates 
   * FieldExtensionAlgorithms to extend the velocity field off of 
   * dislocation lines, and initializes the state of the 
   * DislocationDynamicsModule using the parameters from the input 
   * database.
   * 
   * Arguments:     
   *  - input_db (in):                 input database containing
   *                                   user-defined parameters for
   *                                   the DislocationDynamicsModule
   *  - patch_hierarchy (in):          PatchHierarchy for computation
   *  - elastic_stress_strategy (in):  pointer to concrete subclass of
   *                                   ElasticStressStrategy
   *  - lsmdd_physics_strategy (in):   pointer to concrete subclass of
   *                                   LSMDD_PhysicsStrategy
   * 
   */
  DislocationDynamicsModule(
    Pointer<Database> input_db,
    Pointer< PatchHierarchy<3> > patch_hierarchy,
    ElasticStressStrategy *elastic_stress_strategy,
    LSMDD_PhysicsStrategy* lsmdd_physics_strategy);

  
  /*!
   * The destructor deallocates memory used during the simulation.
   */
  virtual ~DislocationDynamicsModule();

  //! @}


  //! @{
  /*!
   ********************************************************************
   *
   * @name Accessor methods for level set functions and related data
   *
   ********************************************************************/

  /*!
   * getPhiPatchDataHandle() returns the patch data handle for phi.
   *
   * Arguments:     none
   *
   * Return value:  PatchData handle for phi
   *
   */
  virtual int getPhiPatchDataHandle() const;

  /*!
   * getPsiPatchDataHandle() returns the patch data handle for psi.
   *
   * Arguments:     none
   *
   * Return value:  PatchData handle for psi
   *
   */
  virtual int getPsiPatchDataHandle() const;

  /*!
   * getVelocityPatchDataHandle() returns the patch data handle for
   * the velocity.
   *
   * Arguments:     none
   *
   * Return value:  PatchData handle for velocity
   *
   */
  virtual int getVelocityPatchDataHandle() const;

  /*!
   * getControlVolumePatchDataHandle() returns the patch data handle for
   * the control volume.
   *
   * Arguments:     none
   *
   * Return value:  PatchData handle for control volume
   *
   */
  virtual int getControlVolumePatchDataHandle() const;

  //! @}


  //! @{
  /*!
   *******************************************************************
   *
   *  @name Accessor methods for simulation state
   *
   *******************************************************************/

  /*!
   * getStartTime() returns the simulation start time.
   *
   * Arguments:     none
   *
   * Return value:  start time
   *
   */
  virtual double getStartTime() const;

  /*!
   * getEndTime() returns the simulation end time.
   *
   * Arguments:     none
   *
   * Return value:  end time
   *
   */
  virtual double getEndTime() const;

  /*!
   * getCurrentTime() returns the current simulation time.
   *
   * Arguments:     none
   *
   * Return value:  current time
   *
   */
  virtual double getCurrentTime() const;

  /*!
   * endTimeReached() returns true if the end time for the simulation
   * has been reached; otherwise, it returns false.
   *
   * Arguments:     none
   *
   * Return value:  true if the current time is equal to or after
   *                the end time for the simulation; false otherwise
   *
   */
  virtual bool endTimeReached() const;

  /*!
   * numSimulationStepsTaken() returns the number of time steps taken 
   * in the simulation. 
   *
   * Arguments:     none
   *
   * Return value:  number of simulation steps taken
   *
   */
  virtual int numSimulationStepsTaken() const;

  /*!
   * printClassData() prints the value of the data members for
   * an instance of the DislocationDynamicsModule class.
   *
   * Arguments:     
   *  - os (in):    output stream to write object information
   *
   * Return value:  none
   *
   */
  virtual void printClassData(ostream& os) const;

  //! @}


  //! @{
  /*!
   *******************************************************************
   *
   *  @name Methods for time advancing dislocation lines
   *
   *******************************************************************/

  /*!
   * initializeDislocationsLevelSetFunctions() initializes the level 
   * set functions associated with each dislocation line in the 
   * simulation.
   *
   * Arguments:     none
   *
   * Return value:  none
   *
   */
  virtual void initializeDislocationLevelSetFunctions();

  /*!
   * computeNextDt() computes the maximum stable dt for the next
   * time step. 
   *
   * Arguments:     none
   *
   * Return value:  dt
   *
   */
  virtual double computeNextDt();

  /*!
   * advanceDislocations() advances all of the dislocations in the 
   * simulation by computing the stress field associated with the 
   * dislocations, using this stress field to compute the forces
   * and velocities on each of the dislocations, and advancing the
   * dislocation level set functions with the calculated velocities.
   *
   * Arguments:
   *  - dt (in):    time step size by which to advance dislocations
   *
   * Return value:  none
   *
   */
  virtual void advanceDislocations(const double dt);

  /*!
   * toggleUpwindDirection() toggles the upwind direction used
   * to compute the dislocation line field.  
   *
   * Arguments:     none
   *
   * Return value:  current upwind direction
   *
   */
  virtual bool toggleUpwindDirection();


  //! @{
  /*!
   ****************************************************************
   *
   *  @name Visualization methods
   *
   *******************************************************************/

  /*!
   * writeAllDislocationLinesToFile() outputs all of the current 
   * dislocation lines as a series of dislocation line segments. 
   *
   * Arguments:     
   *  - base_name (in):  base name for output files
   *  - file_type (in):  type of output file
   *                     (default = ASCII)
   *
   * Return value:       none
   *
   * NOTES:
   *  - If the specified file already exists, it will be overwritten.
   *
   *  - See notes for writeOneDislocationLineToFile().
   * 
   */
  virtual void writeAllDislocationLinesToFile(
    const string& base_name,
    const VISUALIZATION_FILE_FORMAT file_type = ASCII); 

  /*!
   * writeOneDislocationLineToFile() outputs the specified dislocation 
   * line as a series of dislocation line segments. 
   *
   * Arguments:     
   *  - line_handle (in):             handle for dislocation to write to file
   *  - base_name (in):               base name for output files
   *  - file_type(in):                type of output file
   *                                  (default = ASCII)
   *  - overwrite_file (in):          true if the specified file should be 
   *                                  overwritten (if it exists); false 
   *                                  if the dislocation data should be 
   *                                  appended to the specified file
   *                                  (default = true)
   *  - allocate_scratch_space (in):  true if scratch data needs to be 
   *                                  allocated for computing the 
   *                                  dislocation line
   *                                  (default = true)
   *
   * Return value:                    none
   *
   * NOTES:
   *  - For ASCII output, each line of the output file contains the
   *    coordinates of the two ends of a dislocation line segment
   *    separated by white space:
   *      
   *      x_1   y_1   z_1   x_2   y_2   z_2
   *    
   *    The last line of the output for the specified dislocation line
   *    is a row containing five NaNs and the dislocation number 
   *    (line_handle).  This is used indicate that the data for the
   *    specified dislocation line has ended.
   *
   *  - Binary output files have the following format:
   *    - LSMDD Version (int)
   *    - number of dislocations (int)
   *    - array of s_lsmdd_binary_output_max_num_dislocations integers
   *      that stores information about where in the file each
   *      dislocation line begins
   *    - the data for each dislocation line has the following
   *      format:
   *      - line_handle (int)
   *      - number of dislocation segments (int)
   *      - list of dislocation segments stored as endpt1
   *        followed by endpt2.  Both endpt1 and endpt2 are
   *        stored as the three doubles representing the x, y,
   *        and z components of the position of the end point.
   *
   */
  virtual void writeOneDislocationLineToFile(
    const int line_handle,
    const string& base_name,
    const VISUALIZATION_FILE_FORMAT file_type = ASCII,
    const bool overwrite_file = true,
    const bool allocate_scratch_data = true); 

  //! @}


  /*******************************************************************
   *******************************************************************
   *
   *  USERS NEED NOT BE CONCERNED WITH FOLLOWING METHODS.  THEY
   *  ARE PART OF THE IMPLEMENTATION DETAILS FOR THE LEVEL SET 
   *  METHOD DISLOCATION DYNAMICS CALCULATION.
   *
   *******************************************************************
   *******************************************************************/

  //! @{
  /*!
   *******************************************************************
   *
   *  @name Inherited methods 
   * 
   *  Methods inherited from the LevelSetMethodPatchStrategy and
   *  LevelSetMethodVelocityStrategy Classes.  Users need not be 
   *  concerned with these methods.
   *
   *******************************************************************/

  /*!
   * initializeLevelSetFunctionsOnPatch() passes the request to
   * the LSMDD_PhysicsStrategy object.
   * 
   * Arguments:
   *  - patch (in):         Patch on which to initialize level set functions
   *  - current_time (in):  current time
   *  - phi_handle (in):    PatchData handle for phi
   *  - psi_handle (in):    PatchData handle for psi
   * 
   * Return value:          none
   * 
   */
  virtual void initializeLevelSetFunctionsOnPatch(Patch<3>& patch,
                                                  const double time,
                                                  const int phi_handle,
                                                  const int psi_handle);

  /*!
   * setLevelSetFunctionBoundaryConditions() passes the request to the 
   * LSMDD_PhysicsStrategy object.
   * 
   * Arguments:
   *  - patch (in):                Patch on which to set boundary conditions
   *                               for the level set functions
   *  - fill_time (in):            time at which boundary data are being filled
   *  - phi_handle (in):           PatchData handle for phi
   *  - psi_handle (in):           PatchData handle for psi
   *  - ghost_width_to_fill (in):  width of ghost cells to fill
   * 
   * Return value:                 none
   * 
   */
  virtual void setLevelSetFunctionBoundaryConditions(
    Patch<3>& patch,
    const double fill_time,
    const int phi_handle,
    const int psi_handle,
    const IntVector<3>& ghost_width_to_fill);

  /*!
   * computeStableDtOnPatch() passes the request to the 
   * LSMDD_PhysicsStrategy object.
   *
   * Arguments:
   *  - patch (in):                        Patch on which to compute a stable
   *                                       time step size
   *  - lsm_integrator (in):               pointer to LevelSetFunctionIntegrator
   *  - lsm_velocity_field_strategy (in):  pointer to 
   *                                       LevelSetMethodVelocityFieldStrategy
   * 
   * Return value:                         user-specified time step dt
   * 
   */
  virtual double computeStableDtOnPatch(
    Patch<3>& patch,
    LevelSetFunctionIntegrator<3>* lsm_integrator,
    LevelSetMethodVelocityFieldStrategy<3>* lsm_velocity_field_strategy);


  /*!
   * providesExternalVelocityField() returns true.
   *
   * Arguments:     none
   *
   * Return value:  true 
   *
   */
  virtual inline bool providesExternalVelocityField() const 
  {
    return true;
  }

  /*!
   * providesNormalVelocityField() returns false.
   *
   * Arguments:     none
   *
   * Return value:  false
   *
   */
  virtual inline bool providesNormalVelocityField() const 
  {
    return false;
  }

  /*!
   * Accessor method for the external (vector) velocity field PatchData
   * handle.
   *
   * Arguments:     
   *  - component (in):  component of vector level set function for which 
   *                     the velocity field handle is being requested 
   *
   * Return value:       PatchData handle for the external velocity field 
   *                     data
   *
   */
  virtual inline int getExternalVelocityFieldPatchDataHandle(
    int component) const
  {
    (void) component;
    return d_velocity_handle;
  }

  /*!
   * getNormalVelocityFieldPatchDataHandle() returns a bogus PatchData
   * handle since the dislocation dynamics requires a vector velocity field, 
   * not just the normal velocity.
   *
   * Arguments:     
   *  - level_set_fcn (in):  level set function for which to get 
   *                         normal velocity field PatchData handle
   *  - component (in):      component of vector level set function for which 
   *                         the velocity field handle is being requested 
   *
   * Return value:           -1
   *
   */
  virtual inline int getNormalVelocityFieldPatchDataHandle(
    LEVEL_SET_FCN_TYPE level_set_fcn,
    int component) const 
  {
      (void) level_set_fcn;
      (void) component;
      return -1;
  }

  /*!
   * setCurrentTime() sets the current simulation time to the specified
   * time.
   *
   * Arguments:     
   *  - time (in):  new current time
   *
   * Return value:  none
   *
   */
  virtual inline void setCurrentTime(const double time) 
  {
    d_current_time = time;
  }
  
  /*!
   * computeStableDt() just returns the largest double value because 
   * there is no dynamics in the elastic stress calculation that would 
   * impact the time step size (i.e. the material is assumed to respond 
   * instantaneously).
   *
   * Arguments:     none
   *
   * Return value:  maximum acceptable (stable) time step
   *
   */
  virtual inline double computeStableDt() 
  {
    return DBL_MAX;
  }

  /*!
   * computeVelocityField() computes all necessary 
   * level set method velocity fields on the entire hierarchy.  
   *
   * Arguments:
   *  - time (in):         time that velocity field is to be computed
   *  - phi_handle (in):   PatchData handle for phi
   *  - psi_handle (in):   PatchData handle for psi
   *  - line_handle (in):  handle for dislocation line for which to
   *                       compute velocity field
   *
   * Return value:         none
   *
   */
  virtual void computeVelocityField(
    const double time,
    const int phi_handle,
    const int psi_handle,
    const int line_handle);

  /*!
   * initializeLevelData() does not do anything since there are no fields
   * that need to be initialized for the velocity field calculation.
   *
   * Arguments:
   *  - hierarchy (in):       PatchHierarchy on which to tag cells for
   *                          refinement
   *  - level_number (in):    PatchLevel number on which to tag cells for
   *                          refinement
   *  - init_data_time (in):  simulation time at which data is to be 
   *                          initialized
   *  - phi_handle (in):      PatchData handle for phi
   *  - psi_handle (in):      PatchData handle for psi
   *  - can_be_refined (in):  true if this is NOT the finest level in the
   *                          PatchHierarchy; false it if is
   *  - initial_time (in):    true if the PatchLevel is being introduced for
   *                          the first time; false otherwise
   *  - old_level (in):       old PatchLevel from which data for new
   *                          PatchLevel should be taken
   *  - allocate_data (in):   true if PatchData needs to be allocated before
   *                          it is initialized; false otherwise
   *
   * Return value:            none
   *
   */
  virtual inline void initializeLevelData(
    const Pointer< PatchHierarchy<3> > hierarchy,
    const int level_number,
    const double init_data_time,
    const int phi_handle,
    const int psi_handle,
    const bool can_be_refined,
    const bool initial_time,
    const Pointer< PatchLevel<3> > old_level
      = Pointer< PatchLevel<3> >((0)),
    const bool allocate_data = true) {}

  /*!
   * resetHierarchyConfiguration() updates resets the communication
   * schedules to be consistent with the new configuration of the
   * PatchHierarchy.  This method should be invoked any time the
   * PatchHierarchy has been changed.
   *
   * Arguments:
   *  - hierarchy (in):       Pointer to new PatchHierarchy
   *  - coarsest_level (in):  coarsest level in the hierarchy to be updated
   *  - finest_level (in):    finest level in the hierarchy to be updated
   *
   * Return value:            none
   *
   */
  virtual void resetHierarchyConfiguration(
    Pointer< PatchHierarchy<3> > hierarchy,
    const int coarsest_level,
    const int finest_level);

  //! @}


protected:

  //! @{
  /*!
   ****************************************************************
   *
   * @name Utility methods
   *
   ****************************************************************/

  /*!
   * getFromInput()
   *
   * Arguments:
   *  - input_db (in):
   *
   * Return value:      none
   *
   */
  virtual void getFromInput(Pointer<Database> input_db);

  /*!
   * computeDislocationLineField() computes the dislocation line 
   * field ( delta(phi)*delta(psi)*unit_tangent_vector ) required to 
   * calculate the elastic stress field due to dislocation lines for a 
   * single dislocation line.
   *
   * Arguments:
   *  - line_handle (in):  the handle of the dislocation line to use
   *  - phi_handle(in):    PatchData handle for phi
   *  - psi_handle(in):    PatchData handle for psi
   *
   * Return value:         none
   *
   */
  virtual void computeDislocationLineField(
    const int line_handle,
    const int phi_handle,
    const int psi_handle);

  /*!
   * computeUnitTangentVectorForDislocationLine() computes the tangent
   * vector for the dislocation line associated with a single Burgers 
   * vector which is used to compute the force on a dislocation line
   * via the formula: 
   *
   *   (sigma dot b) cross tangent
   *
   * Arguments:
   *  - line_handle (in):  handle of the dislocation line for which
   *                       to compute tangent vector
   *  - phi_handle(in):    PatchData handle for phi
   *  - psi_handle(in):    PatchData handle for psi
   *
   * Return value:         none
   *
   * NOTES:
   *  - This is the tangent vector that is passed to the method
   *    computeForceOnDislocationLineOnPatch() that is defined by 
   *    the application developer in a concrete subclass of the
   *    LSMDD_PhysicsStrategy class.
   *    
   */
  virtual void computeUnitTangentVectorForDislocationLine(
    const int tangent_vector_handle,
    const int line_handle,
    const int phi_handle,
    const int psi_handle);

  /*!
   * initializeVariables() sets up the variables and PatchData handles
   * for the dislocation dynamics simulation.
   *
   * Arguments:     none
   *   
   * Return value:  none
   *   
   */  
  virtual void initializeVariables();

  /*!
   * initializeCommunicationObjects() initializes the objects
   * involved in communication between patches (including
   * inter-node data transfers). 
   *
   * Arguments:     none
   *   
   * Return value:  none
   *
   */  
  virtual void initializeCommunicationObjects();

  /*!
   * fillGhostCellsForLevelSetFunctions() fills the ghostcells for
   * the level set functions phi and psi.  Ghostcells corresponding
   * to grid cells in the interior of the computational domain are 
   * filled by copying data from neighboring patches. Ghostcells 
   * corresponding to cells outside of the computational domain
   * are filled either by (1) copying data from the appropriate
   * grid cells for periodic boundary conditions or (2) calling the
   * setLevelSetFunctionBoundaryConditions() method in the user-defined
   * subclass of the LSMDD_PhysicsStrategy class.
   *
   * Arguments:     
   *  - line_handle (in):  handle of dislocation level set functions
   *                       that need to have ghostcells filled
   *  - phi_handle(in):    PatchData handle for phi
   *  - psi_handle(in):    PatchData handle for psi
   *
   * Return value:         none
   *
   * NOTES:
   *  - Periodic boundary conditions are applied in a special manner to
   *    avoid the introduction of artificial dislocations (which arise
   *    from the introduction of artificial zero level sets in phi and 
   *    psi).  When the sign of the level set function in the interior
   *    of the computational domain is the same on both sides of a 
   *    periodic boundary, then the values in the ghostcells outside of 
   *    the physical domain are set equal to the value of the grid cells 
   *    taken from grid cells on the other side of the computational 
   *    domain (i.e. periodic boundary conditions).  However, when the 
   *    sign of the level set function in the interior of the computational 
   *    domain changes across a periodic boundary, the values in the 
   *    ghostcells outside of the physical domain are set to minus the 
   *    value of the grid cells taken from grid cells on the other side 
   *    of the computational domain (i.e. anti-periodic boundary 
   *    conditions).
   *
   */
  virtual void fillGhostCellsForLevelSetFunctions(
    const int line_handle,
    const int phi_handle,
    const int psi_handle);

  /*!
   * writeOneDislocationLineToAsciiFile() outputs the specified 
   * dislocation line to an ASCII text file as a series of dislocation 
   * line segments.
   *
   * Arguments:     
   *  - base_name (in):       base name for output files
   *  - line_handle (in):     handle for dislocation to write to file
   *  - overwrite_file (in):  true if the specified file should be 
   *                          overwritten (if it exists); false 
   *                          if the dislocation data should be 
   *                          appended to the specified file
   *                          (default = true)
   *
   * Return value:            none
   *
   * NOTES:
   *  - Each line of the output file contains the coordinates of the
   *    two ends of a dislocation line segment separated by white space:
   *
   *    x_1   y_1   z_1   x_2   y_2   z_2
   *
   *  - The last line of the output for the specified dislocation line
   *    is a row containing five NaNs and the dislocation number 
   *    (line_handle).  This is used indicate that the data for the
   *    specified dislocation line has ended.
   *  
   */
  virtual void writeOneDislocationLineToAsciiFile(
    const string& base_name,
    const int line_handle,
    const bool overwrite_file = true);

  /*!
   * writeOneDislocationLineToBinaryFile() outputs the specified 
   * dislocation line to a binary file. 
   *
   * Arguments:     
   *  - base_name (in):        base name for output files
   *  - line_handle (in):      handle for dislocation to write to file
   *  - overwrite_file (in):   true if the specified file should be 
   *                           overwritten (if it exists); false 
   *                           if the dislocation data should be 
   *                           appended to the specified file
   *                           (default = true)
   *
   * Return value:             none
   *
   * NOTES:
   *  - Binary output files have the following format:
   *    - LSMDD Version (int)
   *    - number of dislocations (int)
   *    - array of s_lsmdd_binary_output_max_num_dislocations integers
   *      that stores information about where in the file each
   *      dislocation line begins
   *    - the data for each dislocation line has the following
   *      format:
   *      - line_handle (int)
   *      - number of dislocation segments (int)
   *      - list of dislocation segments stored as endpt1
   *        followed by endpt2.  Both endpt1 and endpt2 are
   *        stored as the three doubles representing the x, y,
   *        and z components of the position of the end point.
   *
   */
  virtual void writeOneDislocationLineToBinaryFile(
    const string& base_name,
    const int line_handle,
    const bool overwrite_file = true);

 //! @}

  /*
   * Input parameters
   */

  // simulation parameters 
  double d_start_time;
  double d_end_time;
  SPATIAL_DERIVATIVE_TYPE d_spatial_derivative_type;
  int d_spatial_derivative_order;
  int d_num_stabilization_iterations;
  int d_reinitialization_interval;
  int d_use_reinitialization;
  int d_orthogonalization_interval;
  int d_use_orthogonalization;
  bool d_use_persistent_velocity_data;

  // LSMDD_Parameters
  LSMDD_Parameters d_lsmdd_params;


  /* 
   * Pointers to algorithm and data structure objects
   */

  // pointer to PatchHierarchy
  Pointer< PatchHierarchy<3> > d_patch_hierarchy;

  // pointer to CartesianGridGeometry
  Pointer< CartesianGridGeometry<3> > d_grid_geometry;

  // array of Burgers vectors for dislocation lines
  Array< BurgersVector > d_burgers_vectors;
  int d_num_dislocation_lines;

  // pointer to LevelSetMethodAlgorithm object
  Pointer< LevelSetMethodAlgorithm<3> > d_lsm_algorithm;

  // pointer to FieldExtensionAlgorithm objects
  Pointer< FieldExtensionAlgorithm<3> > d_lsm_phi_field_extension_alg;
  Pointer< FieldExtensionAlgorithm<3> > d_lsm_psi_field_extension_alg;

  // pointer to ElasticStressStrategy
  ElasticStressStrategy *d_elastic_stress_strategy;

  // pointer to LSMDD_PhysicsStrategy
  LSMDD_PhysicsStrategy* d_lsmdd_physics_strategy;

  // pointer to BoundaryConditionModule
  Pointer< BoundaryConditionModule<3> > d_level_set_fcn_bc_module;

  // boundary conditions for level set functions
  Array< IntVector<3> > d_lower_bc_phi;
  Array< IntVector<3> > d_upper_bc_phi;
  Array< IntVector<3> > d_lower_bc_psi;
  Array< IntVector<3> > d_upper_bc_psi;

  // boundary conditions for velocity field
  IntVector<3> d_lower_bc_velocity;
  IntVector<3> d_upper_bc_velocity;

  /*
   * Geometry and boundary condition parameters
   */
  IntVector<3> d_level_set_fcn_scratch_ghostcell_width;


  /*
   * PatchData handles
   */

  // PatchData handles for computation
  int d_phi_scratch_handle;               // PatchData handle for phi
                                          // scratch data
  int d_psi_scratch_handle;               // PatchData handle for psi
                                          // scratch data
  int d_grad_phi_plus_handle;             // PatchData handle for grad(phi) 
                                          // plus
  int d_grad_phi_minus_handle;            // PatchData handle for grad(phi)
                                          // minus
  int d_grad_phi_central_handle;          // PatchData handle for central
                                          // approximation to grad(phi)
  int d_grad_psi_plus_handle;             // PatchData handle for grad(psi)
                                          // plus
  int d_grad_psi_minus_handle;            // PatchData handle for grad(psi)
                                          // minus
  int d_grad_psi_central_handle;          // PatchData handle for central
                                          // approximation to grad(psi)

  int d_dislocation_line_field_handle;    // PatchData handle for dislocation
                                          // line field given by 
                                          // delta(phi)*delta(phi)*unit_tangent
  int d_velocity_handle;                  // PatchData handle for velocity
  int d_aux_stress_field_handle;          // PatchData handle for auxiliary
                                          // stress field
  int d_force_handle;                     // PatchData handle for force on
                                          // dislocation line
  vector<int> d_tangent_vector_handles;   // PatchData handle for unit tangent
                                          // vectors of dislocation line
  int d_distance_handle;                  // PatchData handle for the closest
                                          // distance from the nearest 
                                          // dislocation line to the center
                                          // of the grid cell

                                          // dislocation line
  ComponentSelector d_tangent_vectors;    // Component selector to manage
                                          // allocation/deallocation of 
                                          // tangent vector PatchData

  /*
   * Data communication objects
   */
  Pointer< RefineAlgorithm<3> > d_level_set_fcn_fill_bdry_alg;
  Array< Pointer< RefineSchedule<3> > > d_level_set_fcn_fill_bdry_sched;
  Pointer< RefineAlgorithm<3> > d_force_interp_fill_bdry_alg;
  Array< Pointer< RefineSchedule<3> > > d_force_interp_fill_bdry_sched;
  Pointer< RefineAlgorithm<3> > d_tangent_fill_bdry_alg;
  Array< Pointer< RefineSchedule<3> > > d_tangent_fill_bdry_sched;

  /*
   * Parameters for outputing data to file
   */
  static const int s_lsmdd_version;
  static const int s_lsmdd_binary_output_max_num_dislocations;

  /*
   * Object state variables 
   */
  double d_current_time;                         // current simulation time
  double d_last_stress_update_time;              // last time that stress
                                                 // field was updated
  int d_num_simulation_steps_taken;              // number of simulation steps 
                                                 // taken
  bool d_upwind_spatial_derivative_flag;         // flag indicating whether 
                                                 // upwind or downwind spatial 
                                                 // derivatives should be used 
                                                 // during calculation of 
                                                 // dislocation lines
  bool d_hierarchy_configuration_needs_reset;    // flag indicating that 
                                                 // communication schedules
                                                 // need to be recomputed
  bool d_velocity_data_allocated;                // flag indicating if velocity
                                                 // data has been allocated


private:
 
  /*
   * Private copy constructor to prevent use.
   *
   * Arguments:
   *  - rhs (in):  DislocationDynamicsModule object to copy
   *
   */
  DislocationDynamicsModule(const DislocationDynamicsModule& rhs){}

  /*
   * Private assignment operator to prevent use.
   *
   * Arguments:
   *  - rhs (in):   DislocationDynamicsModule object to copy
   *
   * Return value:  *this
   *
   */
  const DislocationDynamicsModule& operator=(
    const DislocationDynamicsModule& rhs){ return *this; }

};

} // end LSMDD namespace

#ifndef LSMDD_DEBUG_NO_INLINE
#include "DislocationDynamicsModule.inline"
#endif

#endif

