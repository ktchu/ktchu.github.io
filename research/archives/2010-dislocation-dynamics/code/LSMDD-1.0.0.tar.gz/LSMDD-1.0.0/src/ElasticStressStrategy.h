/*
 * File:        ElasticStressStrategy.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 379 $
 * Modified:    $Date: 2007-08-07 10:02:34 -0400 (Tue, 07 Aug 2007) $
 * Description: Header file for the ElasticStressStrategy class
 */

#ifndef included_ElasticStressStrategy_h
#define included_ElasticStressStrategy_h

/*! \class LSMDD::ElasticStressStrategy
 *
 * \brief
 * The ElasticStressStrategy class defines the interface used by
 * the DislocationDynamicsModule class for computing the elastic 
 * stress field in a material containing dislocations. 
 * 
 */


// System Headers
#include <ostream>
#include <vector>

// SAMRAI Headers
#include "SAMRAI_config.h"

// LSMDD Headers
#include "LSMDD_config.h"
#include "BurgersVector.h"
#include "LSMDD_Parameters.h"


/******************************************************************
 *
 * ElasticStressStrategy Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class ElasticStressStrategy
{
public:

  //! @{
  /*!
   ****************************************************************
   *    
   * @name Empty constructor and destructor
   *    
   ****************************************************************/

  ElasticStressStrategy(){}

  virtual ~ElasticStressStrategy(){}

  //! @}


  //! @{
  /*!
   ****************************************************************
   *    
   * @name Methods for accessing elastic stress field data
   *    
   ****************************************************************/ 
  
  /*!
   * getStressFieldHandle() returns the PatchData handle for the
   * elastic stress field.
   *
   * Arguments:     none
   *   
   * Return value:  PatchData handle for stress field
   *
   * NOTES:
   *  - This is a pure abstract method that the user MUST override in 
   *    order to use the DislocationDynamicsModule class.
   */
  virtual int getStressFieldHandle() = 0;

  //! @}


  //! @{
  /*!
   ****************************************************************
   *    
   * @name Methods for computing elastic stress field 
   *    
   ****************************************************************/ 

  /*!
   * setStressFieldToZero() sets the stress field equal to zero 
   * everywhere.
   *
   * Arguments:     none
   * 
   * Return value:  none
   *
   * NOTES:
   *  - This is a pure abstract method that the user MUST override in 
   *    order to use the DislocationDynamicsModule class.
   * 
   */
  virtual void setStressFieldToZero() = 0;

  /*!
   * addStressFieldForDislocationLine() adds the stress field due to the 
   * specified dislocation line to the total elastic stress field.
   *
   * Arguments:     
   *  - dislocation_line_field_handle (in):  PatchData handle for dislocation 
   *                                         line for which to compute stress
   *                                         field contribution
   *  - burgers_vector (in):                 Burgers vector of dislocation 
   *                                         line
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   * 
   * Return value:                           none
   *
   * NOTES:
   *  - This is a pure abstract method that the user MUST override in 
   *    order to use the DislocationDynamicsModule class.
   * 
   */
  virtual void addStressFieldForDislocationLine(
    const int dislocation_line_field_handle,
    const BurgersVector& burgers_vector,
    const LSMDD_Parameters& lsmdd_params) = 0;

  /*!
   * addAuxiliaryStressField() adds the specified auxiliary stress field 
   * to the total elastic stress field.
   *
   * Arguments:     
   *  - auxiliary_stress_field_handle (in):  PatchData handle for external
   *                                         stress field
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   * 
   * Return value:                           none
   *
   * NOTES:
   *  - This is a pure abstract method that the user MUST override in 
   *    order to use the DislocationDynamicsModule class.
   * 
   */
  virtual void addAuxiliaryStressField(
    const int auxiliary_stress_field_handle,
    const LSMDD_Parameters& lsmdd_params) = 0;

  /*!
   * addAuxiliaryStressFieldComponent() adds the component of the 
   * specified auxiliary stress field to the total elastic stress 
   * field.
   *
   * Arguments:     
   *  - auxiliary_stress_field_handle (in):  PatchData handle for auxiliary
   *                                         stress field
   *  - lsmdd_params (in):                   parameters for dislocation
   *                                         dynamics simulation
   *  - component (in):                      component of auxiliary stress
   *                                         field to update
   * 
   * Return value:                          none
   *
   * NOTES:
   *  - This is a pure abstract method that the user MUST override in 
   *    order to use the DislocationDynamicsModule class.
   * 
   */
  virtual void addAuxiliaryStressFieldComponent(
    const int auxiliary_stress_field_handle,
    const LSMDD_Parameters& lsmdd_params,
    const int component) = 0;

  //! @}


  //! @{
  /*!
   *******************************************************************
   *
   *  @name Accessor methods for object state
   *
   *******************************************************************/

  /*!
   * printClassData() prints the current state of the 
   * ElasticStressStrategy object to the specified output 
   * stream.
   *
   * Arguments:     
   *  - os (in):    output stream for class data 
   * 
   * Return value:  none
   *
   * NOTES:
   *  - This is a pure abstract method that the user MUST override in 
   *    order to use the DislocationDynamicsModule class.
   */
  virtual void printClassData(ostream& os) const = 0;

  //! @}
};

} // end LSMDD namespace

#endif

