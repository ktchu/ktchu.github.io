%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% plot_sphere() plots a sphere with the specified properties.
%
% Arguments:
%   center:         array containing the position of the center of the sphere
%   radius:         radius of sphere
%   color:          color of sphere (value between 0 and 1)
%   material_type:  type of material for surface 
%                   0 = 'shiny'
%                   1 = 'metal'
%                   2 = 'dull'
%   N_theta:        number of points to use in theta direction
%   N_phi:          number of points to use in phi direction
%
% Kevin T. Chu
% Mechanical & Aerospace Engineering, Princeton University
% Jan 2006
%
% NOTES:
%
% - This function does NOT manage the lighting; setting up the lighting
%   is left up to the user.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:        plot_sphere.m
% Copyright:   (c) 2005-2007 Princeton University
% Author(s):   Kevin T. Chu
% Revision:    $Revision: 376 $
% Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
% Description: MATLAB function for showing dislocation dynamics movie
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plot_sphere(center, radius, color, material_type, N_theta, N_phi)

% read in arguments
if (nargin < 2) 
  error('MATLAB:missingArgs','plot_sphere:missing arguments');
end

if (nargin < 3)
  color = 0.5;
end
if (nargin < 4)
  material_type = 0;
end
if (nargin < 5)
  N_theta = 25;
end
if (nargin < 6)
  N_phi = 50;
end

% generate mesh for surface of sphere
d_theta = pi/N_theta;
theta = 0:d_theta:pi;
d_phi = 2*pi/N_phi;
phi = 0:d_phi:2*pi;
[phi_mesh,theta_mesh] = meshgrid(phi,theta);

% compute points on sphere
x = radius * sin(theta_mesh) .* cos(phi_mesh) + center(1);
y = radius * sin(theta_mesh) .* sin(phi_mesh) + center(2);
z = radius * cos(theta_mesh) + center(3);

% plot sphere
surf(x,y,z,color*ones(size(x)));

% set color axis
caxis([0 1]);  

% set shading and material type
shading flat;
if (material_type == 0)
  material shiny;
elseif (material_type == 1)
  material metal;
else 
  material dull
end

