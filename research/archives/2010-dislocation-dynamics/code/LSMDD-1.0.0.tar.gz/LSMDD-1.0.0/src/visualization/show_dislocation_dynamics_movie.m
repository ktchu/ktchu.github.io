%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% show_dislocation_dynamics_move() shows a dislocation dynamics movie based
% on the data contained in specified data files.  See the documentation of
% the plot_dislocation_lines function for the assumptions about the format 
% of the data file.
%
% Arguments:
%  - data_files:          cell-array of data files
%  - num_procs:           number of processors used to generate data files
%  - unit_cell:           array specifying the bounds of the unit cell in
%                         each coordinate direction.
%  - data_times:          array of times associated with the data files.
%                         To disable display of the data times, set 
%                         data_times to [].
%                         (default:  [])
%  - periodic_dirs:       array specifying the which coordinate directions
%                         are periodic.  If the i-th coordinate direction is
%                         periodic, set periodic_dirs(i) to a nonzero value.
%                         (default:  [0 0 0])
%  - line_numbers:        array of line numbers for the dislocation lines to 
%                         plot.  set line_numbers equal to 0 to plot all 
%                         dislocation lines.
%                         (default:  0)
%  - particles_file:      name of file containing the positions and sizes
%                         particles
%                         (default:  none)
%  - plot_view:           view to use for plot
%                         (default:  MATLAB default view)
%  - plot_axes:           axes for plot.  set to 0 for default axes.
%                         (default:  unit cell plus periodic_dirs )
%  - axes_scaling:        set to 0 for MATLAB default; set to 1 for
%                         'axis equal', set to 2 for 'axis square'
%                         (default:  0)
%  - line_formats:        cell array of line formats to use for dislocation 
%                         lines (if the there are fewer line formats than 
%                         line_numbers, the last line format is used for all 
%                         line numbers larger than the number of line formats)
%                         (default: {'r'})
%  - line_width:          line width to use when plotting dislocation lines
%                         (default:  1)
%  - marker_size:         marker size to use when plotting dislocation lines
%                         (default:  12)
%  - marker_face_colors:  cell array of colors to use to fill markers when 
%                         plotting dislocation lines.       
%                         (if the there are fewer colors than line_numbers,
%                         the last color is used for all line numbers
%                         larger than the number of colors)
%                         (default:  use 'auto' for all lines)
%  - marker_edge_colors:  cell array of colors to use for edges of markers 
%                         when plotting dislocation lines.
%                         (if the there are fewer colors than line_numbers,
%                         the last color is used for all line numbers
%                         larger than the number of colors)
%                         (default:  use 'auto' for all lines)
%  - save_movie_params:   cell-array containing parameters to use for
%                         saving movies.  
%                         save_movie_params{1}:  directory where movie frames 
%                                                should be saved.  If this 
%                                                is set to '', movie frames
%                                                will not be saved.
%                         save_movie_params{2}:  base filename for invididual 
%                                                movie frames.
%                         save_movie_params{3}:  image format to use for saving
%                                                individual movie frames.
%                         (default:  {'','frame_','jpeg'})
%  - figure_num:          number of figure in which to draw plot
%                         (default:  0 - which means to create a new figure)
%  - verbose_mode:        set to non-zero value to show progress statistics
%                         (default:  0)
%
%
% USAGE:
%   show_dislocation_dynamics_movie(data_files, ...
%                                   num_procs, ...
%                                   unit_cell, ...
%                                   data_times, ...
%                                   periodic_dirs, ...
%                                   line_numbers, ...
%                                   particles_file, ...
%                                   plot_view, ...
%                                   plot_axes, ...
%                                   axes_scaling, ...
%                                   line_formats, ...
%                                   line_width, ...
%                                   marker_size, ...
%                                   marker_face_colors, ...
%                                   marker_edge_colors, ...
%                                   save_movie_params, ...
%                                   figure_num, ...
%                                   verbose_mode)
%
%
% NOTES:
%  - The data files are shown in the sequence specified by the user.
%
%  - It is the responsibilty of the user to ensure that there is enough
%    data in the data file to plot the requested line_numbers.
%
%  - The ordering of the line formats used for plotting the disloction 
%    lines is consistent with the ordering of the line numbers.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:        show_dislocation_dynamics_movie.m
% Copyright:   (c) 2005-2007 Princeton University
% Author(s):   Kevin T. Chu
% Revision:    $Revision: 395 $
% Modified:    $Date: 2007-08-07 14:04:25 -0400 (Tue, 07 Aug 2007) $
% Description: MATLAB function for showing dislocation dynamics movie
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = show_dislocation_dynamics_movie(data_files, ...
                                              num_procs, ...
                                              unit_cell, ...
                                              data_times, ...
                                              periodic_dirs, ...
                                              line_numbers, ...
                                              particles_file, ...
                                              plot_view, ...
                                              plot_axes, ...
                                              axes_scaling, ...
                                              line_formats, ...
                                              line_width, ...
                                              marker_size, ...
                                              marker_face_colors, ...
                                              marker_edge_colors, ...
                                              save_movie_params, ...
                                              figure_num, ...
                                              verbose_mode)

% argument check
if nargin < 3
  error('MATLAB:missingArgs','show_dislocation_dynamics_movie:missing arguments');
  return
end
if nargin < 4
  data_times = [];
  show_data_times = 0;
else 
  if (isempty(data_times))
    show_data_times = 0;
  else 
    if (length(data_files) == length(data_times)) 
      show_data_times = 1;
    else
      error('show_dislocation_dynamics_movie: data_times and data_files MUST have same length.');
      return
    end
  end
end
if nargin < 5
  periodic_dirs = [0 0 0];
else
  for i=1:3
    if (periodic_dirs(i) ~= 0) 
      periodic_dirs(i) = 1;
    end
  end
end
if nargin < 6
  line_numbers = 0;
end
if nargin < 7
  plot_particles = 0;
  particles_file = '';
else
  if (strcmp(particles_file,'')) 
    plot_particles = 0;
  else 
    plot_particles = 1;
  end
end
if nargin < 8
  plot_view = [-37.5, 30];  % this is the default 3-D view
end
if (nargin < 9) | (plot_axes == 0)
  plot_axes = unit_cell;
  for i=1:3
    if (periodic_dirs(i) ~= 0) 
      plot_axes(2*i) = plot_axes(2*i) + unit_cell(2*i) - unit_cell(2*i-1);
    end
  end
end
if nargin < 10
  axes_scaling = 0;
end
if nargin < 11
  line_formats = {'r'};
end
if nargin < 12
  line_width = 1;
end
if nargin < 13
  marker_size = 12;
end
if nargin < 14
  marker_face_colors = {'auto'};
end
if nargin < 15
  marker_edge_colors = {'auto'};
end
if nargin < 16
  save_movie_params = {'','frame_','jpeg'};
else
  if (strcmp(save_movie_params{1},'') == 0) 
    if (strcmp(save_movie_params{2},'') == 1) 
      save_movie_params{2} = 'frame_';
    end
  end
end
if nargin < 17
  figure_num = 0;
end
if nargin < 18
  verbose_mode = 0;
end

% preparations for saving movie
if (strcmp(save_movie_params{1},'') == 0) 
  movie_dir = save_movie_params{1};
  frame_basename = save_movie_params{2};
  mkdir(movie_dir);
  frame_format = sprintf('-d%s',save_movie_params{3});
  save_movie = 1;
else
  save_movie = 0;
end

% read in particle data (if available)
if (plot_particles ~= 0)
  particle_data = load(particles_file);
  num_particles = size(particle_data,1);
end

% show plots in sequence
num_data_files = length(data_files);
if (figure_num > 0)
  figure(figure_num); clf;
else
  figure; clf;
end
for i = 1:num_data_files

  if (verbose_mode ~= 0)
    output_string = sprintf('Generating frame %d', i);
    disp(output_string);
  end
  
  clf;
  plot_dislocation_lines( ...
    data_files{i}, num_procs, ...
    unit_cell, periodic_dirs, ...
    line_numbers, ...
    plot_view, ...
    line_formats, line_width, ...
    marker_size, ...
    marker_face_colors, marker_edge_colors, ...
    verbose_mode);
  hold on;

  if (plot_particles ~= 0)
    for obs_num = 1:num_particles
      particle_position = particle_data(obs_num,1:3);
      particle_radius = particle_data(obs_num,4);
      plot_sphere(particle_position, particle_radius);
    end
  end

  % set axis scaling type
  if (axes_scaling == 1)
    axis equal;
  elseif (axes_scaling == 2)
    axis square;
  end

  % set axes
  axis(plot_axes);

  % label axes
  xlabel('x'); ylabel('y'); zlabel('z');

  % show time in title
  if (show_data_times == 1)
    title_string = sprintf('Time: %f', data_times(i));
    title(title_string);
  end

  % turn on lighting
  light

  % draw frame now
  drawnow;

  if (save_movie == 1)
    frame_name = sprintf('%s/%s%05d',movie_dir,frame_basename,i);
    print(frame_format,frame_name);
  end

end
