%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% plot_dislocation_lines() reads in dislocation data from the specified
% file and plots it in a 3D figure.  There are two assumptions about the
% format of the data file:
%
%  - Each row of the data file contains the coordinates of the two 
%    endpoints of a dislocation line segment separated by white space:
%
%       x_1   y_1   z_1   x_2   y_2   z_2
%
%  - Data for different dislocation lines is separated by a row 
%    containing NaNs
%
% Arguments:
%  - data_file:           name of data file
%  - num_procs:           number of processors used to generate data files
%  - unit_cell:           array specifying the bounds of the unit cell in 
%                         each coordinate direction.  
%  - periodic_dirs:       array specifying the which coordinate directions
%                         are periodic.  If the i-th coordinate direction is
%                         periodic, set periodic_dirs(i) to a nonzero value.
%                         (default:  [0 0 0])
%  - line_numbers:        array of line numbers for the dislocation lines to 
%                         plot.  set line_numbers equal to 0 to plot all 
%                         dislocation lines.
%                         (default:  plot ALL lines)
%  - plot_view:           view to use for plot
%                         (default:  MATLAB default view)
%  - line_formats:        cell array of line formats to use for dislocation 
%                         lines (if the there are fewer line formats than 
%                         line_numbers, the last line format is used for all 
%                         line numbers larger than the number of line formats)
%                         (default:  plot ALL lines in red)
%  - line_width:          line width to use when plotting dislocation lines
%                         (default:  1)
%  - marker_size:         marker size to use when plotting dislocation lines
%                         (default:  12)
%  - marker_face_colors:  cell array of colors to use to fill markers when 
%                         plotting dislocation lines.
%                         (if the there are fewer colors than line_numbers,
%                         the last color is used for all line numbers 
%                         larger than the number of colors)
%                         (default:  use 'auto' for all lines)
%  - marker_edge_colors:  cell array of colors to use for edges of markers 
%                         when plotting dislocation lines.
%                         (if the there are fewer colors than line_numbers,
%                         the last color is used for all line numbers 
%                         larger than the number of colors)
%                         (default:  use 'auto' for all lines)
%  - verbose_mode:        set to non-zero value to show statistics
%                         (default:  0)
%
%
% USAGE:
%
%   plot_dislocation_lines(data_file, num_procs, ...
%                          unit_cell, periodic_dirs, ...
%                          line_numbers, ...
%                          plot_view, ...
%                          line_formats, line_width, ...
%                          marker_size, ...
%                          marker_face_colors, marker_edge_colors, ...
%                          verbose_mode)
%
%
% NOTES:
%  - It is the responsibilty of the user to ensure that there is enough
%    data in the data file to plot the requested line_numbers.
%
%  - The ordering of the line formats used for plotting the disloction 
%    lines is consistent with the ordering of the line numbers.
%
%  - This code is an adaptation of the plotter() function written by
%    Y. Xiang and L.-T. Cheng.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:        plot_dislocation_lines.m
% Copyright:   (c) 2005-2007 Princeton University
% Author(s):   Kevin T. Chu
% Revision:    $Revision: 376 $
% Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
% Description: MATLAB function for plotting dislocation lines
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = plot_dislocation_lines(data_file, ...
                                     num_procs, ...
                                     unit_cell, ...
                                     periodic_dirs, ...
                                     line_numbers, ...
                                     plot_view, ...
                                     line_formats, ...
                                     line_width, ...
                                     marker_size, ...
                                     marker_face_colors, ...
                                     marker_edge_colors, ...
                                     verbose_mode)

% argument check
if nargin < 3
  error('MATLAB:missingArgs','plot_dislocation_lines:missing arguments');
  return
end
if nargin < 4
  periodic_dirs = [0 0 0];
end
if nargin < 5
  line_numbers = 0;
end
if nargin < 6
  plot_view = [-37.5, 30];  % this is the default 3-D view
end
if nargin < 7
  line_formats = {'r'};
end
if nargin < 8
  line_width = 1;
end
if nargin < 9
  marker_size = 12;
end
if nargin < 10
  marker_face_colors = {'auto'};
end
if nargin < 11
  marker_edge_colors = {'auto'};
end
if nargin < 12
  verbose_mode = 0;
end


% initialize timers
data_read_time = 0;
plot_time = 0;

% set base_name
base_name = data_file;


% loop over data files
for proc = 1:num_procs

  % read data from file
  tic % reset timer
  if (num_procs > 1)
    data_file = sprintf('%s.%05d',base_name,proc-1);  % zero-based proc numbering
  else
    data_file = base_name;
  end
  raw_data = load(data_file);
  data_read_time = data_read_time + toc;

  tic  % reset timer
  endpt1 = raw_data(:,1:3);
  endpt2 = raw_data(:,4:6);

  % compute rows where data switches between different dislocation lines
  switch_rows = find( isnan(endpt1(:,1)) );
  switch_rows = [0; switch_rows];  % prepend 0 to switch_rows for convenience
                                   % in plotting


  % plot dislocation lines
  if (line_numbers == 0) 
    line_numbers = 1:(length(switch_rows)-1);
  end
  for i = 1:length(line_numbers)

    % get line number and rows of endpt matrices
    line_num = line_numbers(i);

    % get line format and marker colors
    if (i <= length(line_formats) )
      line_format = line_formats{i};
    else
      line_format = line_formats{end};
    end
    if (i <= length(marker_face_colors) )
      marker_face_color = marker_face_colors{i};
    else
      marker_face_color = marker_face_colors{end};
    end
    if (i <= length(marker_edge_colors) )
      marker_edge_color = marker_edge_colors{i};
    else
      marker_edge_color = marker_edge_colors{end};
    end

    % organize dislocation line data for simultaneous plotting
    idx_start = switch_rows(line_num)+1;
    idx_end   = switch_rows(line_num+1)-1;
    x = [ endpt1(idx_start:idx_end,1), endpt2(idx_start:idx_end,1) ];
    y = [ endpt1(idx_start:idx_end,2), endpt2(idx_start:idx_end,2) ];
    z = [ endpt1(idx_start:idx_end,3), endpt2(idx_start:idx_end,3) ];

    % add copies of data for periodic directions
    unit_cell_size = unit_cell(2:2:end) - unit_cell(1:2:end);
    if (periodic_dirs(1) ~= 0)  % periodic in x
      x = [ x; ...
            endpt1(idx_start:idx_end,1)+unit_cell_size(1), ...
            endpt2(idx_start:idx_end,1)+unit_cell_size(1) ];
      y = [ y; endpt1(idx_start:idx_end,2), endpt2(idx_start:idx_end,2) ];
      z = [ z; endpt1(idx_start:idx_end,3), endpt2(idx_start:idx_end,3) ];
    end
    if (periodic_dirs(2) ~= 0)  % periodic in y
      x = [ x; endpt1(idx_start:idx_end,1), endpt2(idx_start:idx_end,1) ];
      y = [ y; ...
            endpt1(idx_start:idx_end,2)+unit_cell_size(2), ...
            endpt2(idx_start:idx_end,2)+unit_cell_size(2) ];
      z = [ z; endpt1(idx_start:idx_end,3), endpt2(idx_start:idx_end,3) ];
    end
    if (periodic_dirs(3) ~= 0)  % periodic in z
      x = [ x; endpt1(idx_start:idx_end,1), endpt2(idx_start:idx_end,1) ];
      y = [ y; endpt1(idx_start:idx_end,2), endpt2(idx_start:idx_end,2) ];
      z = [ z; ...
            endpt1(idx_start:idx_end,3)+unit_cell_size(3), ...
            endpt2(idx_start:idx_end,3)+unit_cell_size(3) ];
    end
    if (periodic_dirs(1) ~= 0) & (periodic_dirs(2) ~= 0)  % periodic in xy
      x = [ x; ...
            endpt1(idx_start:idx_end,1)+unit_cell_size(1), ...
            endpt2(idx_start:idx_end,1)+unit_cell_size(1) ];
      y = [ y; ...
            endpt1(idx_start:idx_end,2)+unit_cell_size(2), ...
            endpt2(idx_start:idx_end,2)+unit_cell_size(2) ];
      z = [ z; endpt1(idx_start:idx_end,3), endpt2(idx_start:idx_end,3) ];
    end
    if (periodic_dirs(1) ~= 0) & (periodic_dirs(3) ~= 0)  % periodic in xz
      x = [ x; ...
            endpt1(idx_start:idx_end,1)+unit_cell_size(1), ...
            endpt2(idx_start:idx_end,1)+unit_cell_size(1) ];
      y = [ y; endpt1(idx_start:idx_end,2), endpt2(idx_start:idx_end,2) ];
      z = [ z; ...
            endpt1(idx_start:idx_end,3)+unit_cell_size(3), ...
            endpt2(idx_start:idx_end,3)+unit_cell_size(3) ];
    end
    if (periodic_dirs(2) ~= 0) & (periodic_dirs(3) ~= 0)  % periodic in yz
      x = [ x; endpt1(idx_start:idx_end,1), endpt2(idx_start:idx_end,1) ];
      y = [ y; ...
            endpt1(idx_start:idx_end,2)+unit_cell_size(2), ...
            endpt2(idx_start:idx_end,2)+unit_cell_size(2) ];
      z = [ z; ...
            endpt1(idx_start:idx_end,3)+unit_cell_size(3), ...
            endpt2(idx_start:idx_end,3)+unit_cell_size(3) ];
    end
    if (periodic_dirs(1) ~= 0) & (periodic_dirs(2) ~= 0) & ...
       (periodic_dirs(3) ~= 0)  % periodic in xyz
      x = [ x; ...
            endpt1(idx_start:idx_end,1)+unit_cell_size(1), ...
            endpt2(idx_start:idx_end,1)+unit_cell_size(1) ];
      y = [ y; ...
            endpt1(idx_start:idx_end,2)+unit_cell_size(2), ...
            endpt2(idx_start:idx_end,2)+unit_cell_size(2) ];
      z = [ z; ...
            endpt1(idx_start:idx_end,3)+unit_cell_size(3), ...
            endpt2(idx_start:idx_end,3)+unit_cell_size(3) ];
    end

    % transpose data so it is compatible with plot3()
    x = x'; y = y'; z = z';

    % plot current dislocation line
    if ( (proc > 1) | (i > 1) )
      hold on;
    end
    plot3(x, y, z, line_format, ...
          'LineWidth', line_width, ...
          'MarkerSize', marker_size, ...
          'MarkerFaceColor', marker_face_color, ...
          'MarkerEdgeColor', marker_edge_color);

  end

end % } end loop over parallel data files

% set view
view(plot_view);

plot_time = toc;

% show statistics if requested
if (verbose_mode ~= 0)

  output_string = sprintf('Data read time: %f seconds.', data_read_time);
  disp(output_string);

  output_string = sprintf('Plot time: %f seconds.', plot_time);
  disp(output_string);

end
