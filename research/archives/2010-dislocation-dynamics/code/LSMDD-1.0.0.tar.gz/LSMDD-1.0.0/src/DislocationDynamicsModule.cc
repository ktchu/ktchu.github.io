/*
 * File:        DislocationDynamicsModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Implementation file for the DislocationDynamicsModule class
 */


#include "DislocationDynamicsModule.h"

// System Headers
#include <iostream>
#include <sstream>

// SAMRAI Headers
#include "BoundaryBox.h"
#include "CartesianPatchGeometry.h"
#include "CellVariable.h"
#include "VariableContext.h"
#include "VariableDatabase.h"
#include "tbox/Array.h"
#include "tbox/RestartManager.h"
#include "tbox/Utilities.h"

// LSMDD Headers
#include "LSMDD_Utilities.h"


extern "C" {
  #include <float.h>
  #include "lsmdd_utilities_fort.h"
  #include "lsm_geometry3d.h"
  #include "lsm_samrai_f77_utilities.h"
}


/*
 * Default values for user-defined parameters
 */
#define LSMDD_DEFAULT_NUM_STABILIZATION_ITERATIONS   (3)
#define LSMDD_DEFAULT_USE_PERSISTENT_VELOCITY        (false)


#ifdef LSMDD_DEBUG_NO_INLINE
#include "DislocationDynamicsModule.inline"
#endif


namespace LSMDD {


/* Class variables*/
const int DislocationDynamicsModule::s_lsmdd_version = 1;
const int DislocationDynamicsModule::
  s_lsmdd_binary_output_max_num_dislocations = 256;




/* Constructor() */
DislocationDynamicsModule::DislocationDynamicsModule(
  Pointer<Database> input_db,
  Pointer< PatchHierarchy<3> > patch_hierarchy,
  ElasticStressStrategy *elastic_stress_strategy,
  LSMDD_PhysicsStrategy* lsmdd_physics_strategy) :
d_patch_hierarchy(patch_hierarchy),
d_elastic_stress_strategy(elastic_stress_strategy),
d_lsmdd_physics_strategy(lsmdd_physics_strategy)
{
#ifdef DEBUG_CHECK_ASSERTIONS
  assert(!input_db.isNull());
#endif

  // set grid geometry
   d_grid_geometry = d_patch_hierarchy->getGridGeometry();

  // create LevelSetMethodAlgorithm objects to track the motion 
  // of individual dislocation lines
  d_num_dislocation_lines = 
    d_lsmdd_physics_strategy->numberOfDislocationLines();
  int codimension = 2;
  d_lsm_algorithm = new LevelSetMethodAlgorithm<3>(
    input_db->getDatabase("LevelSetMethodAlgorithm"),
    d_patch_hierarchy,
    (LevelSetMethodPatchStrategy<3>*) this,
    (LevelSetMethodVelocityFieldStrategy<3>*) this,
    d_num_dislocation_lines,
    codimension,
    "LSMDD_LSM_Algorithm");

  // initialize LSMDD_Parameters
  d_lsmdd_params.initializeParametersFromDatabase(
    input_db->getDatabase("LSMDD_Parameters"));

  // Create BoundaryConditionModule objects
  d_level_set_fcn_bc_module = new BoundaryConditionModule<3>;

  // initialize boundary conditions for level set functions
  d_lower_bc_phi.resizeArray(d_num_dislocation_lines);
  d_upper_bc_phi.resizeArray(d_num_dislocation_lines);
  for (int line_num=0; line_num < d_num_dislocation_lines; line_num++) {
    d_lsmdd_physics_strategy->getBoundaryConditions(
      d_lower_bc_phi[line_num], d_upper_bc_phi[line_num],
      line_num, LSMLIB::PHI);
    d_lsm_algorithm->setBoundaryConditions(
      d_lower_bc_phi[line_num], d_upper_bc_phi[line_num], 
      LSMLIB::PHI, line_num);
  }
  d_lower_bc_psi.resizeArray(d_num_dislocation_lines);
  d_upper_bc_psi.resizeArray(d_num_dislocation_lines);
  for (int line_num=0; line_num < d_num_dislocation_lines; line_num++) {
    d_lsmdd_physics_strategy->getBoundaryConditions(
      d_lower_bc_psi[line_num], d_upper_bc_psi[line_num],
      line_num, LSMLIB::PSI);
    d_lsm_algorithm->setBoundaryConditions(
      d_lower_bc_psi[line_num], d_upper_bc_psi[line_num], 
      LSMLIB::PSI, line_num);
  }

  // get reinitialization and orthogonalization intervals
  d_reinitialization_interval = 
    d_lsm_algorithm->getReinitializationInterval();
  d_use_reinitialization = (d_reinitialization_interval > 0);
  d_orthogonalization_interval = 
    d_lsm_algorithm->getOrthogonalizationInterval();
  d_use_orthogonalization = (d_orthogonalization_interval > 0);

  // get dislocation line information from input database
  getFromInput(input_db);

  // temporarily set pointers to FieldExtensionAlgorithms to null
  d_lsm_phi_field_extension_alg.setNull();
  d_lsm_psi_field_extension_alg.setNull();

  // initialize variables and communication objects
  initializeVariables();
  initializeCommunicationObjects();

  // compute number of scratch ghostcells that phi/psi have
  int num_ghostcells = -1; // temporary value
  switch (d_spatial_derivative_type) {
    case ENO: {
      num_ghostcells = d_spatial_derivative_order;
      break;
    }
    case WENO: {
      num_ghostcells = d_spatial_derivative_order/2 + 1;
      break;
    }
    default:
      TBOX_ERROR("DislocationDynamicsModule::"
              << "DislocationDynamicsModule(): "
              << "Unsupported spatial derivative type.  "
              << "Only ENO and WENO derivatives are supported."
              << endl );
  }

  // Create FieldExtensionAlgorithm objects
  d_lsm_phi_field_extension_alg = new FieldExtensionAlgorithm<3>(
    input_db->getDatabase("FieldExtensionAlgorithm"),
    d_patch_hierarchy,
    d_velocity_handle,
    d_lsm_algorithm->getPhiPatchDataHandle(),
    d_lsm_algorithm->getControlVolumePatchDataHandle(),
    "phi-based FieldExtensionAlgorithm",
    num_ghostcells);

  d_lsm_psi_field_extension_alg = new FieldExtensionAlgorithm<3>(
    input_db->getDatabase("FieldExtensionAlgorithm"),
    d_patch_hierarchy,
    d_velocity_handle,
    d_lsm_algorithm->getPsiPatchDataHandle(),
    d_lsm_algorithm->getControlVolumePatchDataHandle(),
    "psi-based FieldExtensionAlgorithm",
    num_ghostcells);

  // initialize the simulation start and end times
  d_start_time = d_lsm_algorithm->getStartTime();
  d_end_time   = d_lsm_algorithm->getEndTime();

  // initialize current time and current step in simulation
  d_current_time = d_lsm_algorithm->getCurrentTime();
  d_num_simulation_steps_taken = d_lsm_algorithm->numIntegrationStepsTaken();

  // initialize last stress update times
  d_last_stress_update_time = d_start_time-1;

  // initialize d_upwind_spatial_derivative_flag to true
  d_upwind_spatial_derivative_flag = true;

  // initialize d_velocity_data_allocated to false
  d_velocity_data_allocated = false;

}


/* Destructor() */
DislocationDynamicsModule::~DislocationDynamicsModule()
{
  // deallocate memory for velocity data if necessary
  if (d_use_persistent_velocity_data && d_velocity_data_allocated) {
    const int num_levels = d_patch_hierarchy->getNumberLevels();
    for ( int ln=0 ; ln < num_levels; ln++ ) {
      Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
        level->deallocatePatchData(d_velocity_handle);

      if (d_lsmdd_physics_strategy->
          providesAuxiliaryStressField()) {
        level->deallocatePatchData(d_aux_stress_field_handle);
      } 
    }
  }
}


/* printClassData() */
void DislocationDynamicsModule::printClassData(ostream& os) const
{
  os << endl << "===================================" << endl;

  os << "DislocationDynamicsModule" << endl;
  os << "-------------------------" << endl;
  os << "d_num_stabilization_iterations = " 
     << d_num_stabilization_iterations << endl;
  os << "d_use_persistent_velocity_data = " 
     << d_use_persistent_velocity_data << endl;
  os << "d_spatial_derivative_type = ";
  if (d_spatial_derivative_type == ENO) {
    os << "ENO" << endl;
  } else if (d_spatial_derivative_type == WENO) {
    os << "WENO" << endl;
  }
  os << "d_spatial_derivative_order = " << d_spatial_derivative_order << endl;
  os << "tvd_runge_kutta_order = " 
     << d_lsm_algorithm->getTVDRungeKuttaOrder() << endl;
  os << "reinitialization_interval = " 
     << d_lsm_algorithm->getReinitializationInterval() << endl;
  os << "orthogonalization_interval = " 
     << d_lsm_algorithm->getOrthogonalizationInterval() << endl;

  os << "d_lower_bc_velocity = " 
     << d_lower_bc_velocity(0) << ","
     << d_lower_bc_velocity(1) << ","
     << d_lower_bc_velocity(2) << endl;
  os << "d_upper_bc_velocity = " 
     << d_upper_bc_velocity(0) << ","
     << d_upper_bc_velocity(1) << ","
     << d_upper_bc_velocity(2) << endl;
 
  os << endl;

  // print out LSMDD parameters
  d_lsmdd_params.printClassData(os);

  os << endl << "===================================" << endl;

  d_lsm_algorithm->printClassData(os);

}


/* writeAllDislocationLinesToFile() */
void DislocationDynamicsModule::writeAllDislocationLinesToFile(
  const string& base_name,
  const VISUALIZATION_FILE_FORMAT file_type) 
{

  // allocate scratch space for phi and psi data
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
    level->allocatePatchData(d_phi_scratch_handle);
    level->allocatePatchData(d_psi_scratch_handle);
  }

  // for first dislocation line, overwrite existing file
  writeOneDislocationLineToFile(0, base_name, file_type, true, false);

  // for remainder of dislocation line, do NOT overwrite existing file
  for (int line_num = 1; line_num < d_num_dislocation_lines; line_num++) {
    writeOneDislocationLineToFile(line_num, base_name, file_type, 
                                  false, false);
  }

  // deallocate scratch space for phi and psi data
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
    level->deallocatePatchData(d_phi_scratch_handle);
    level->deallocatePatchData(d_psi_scratch_handle);
  }

}


/* writeOneDislocationLineToFile() */
void DislocationDynamicsModule::writeOneDislocationLineToFile(
  const int line_handle,
  const string& base_name,
  const VISUALIZATION_FILE_FORMAT file_type,
  const bool overwrite_file,
  const bool allocate_scratch_space) 
{
  // allocate scratch space for phi and psi data
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  if (allocate_scratch_space) {
    for ( int ln=0 ; ln < num_levels; ln++ ) {
      Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
      level->allocatePatchData(d_phi_scratch_handle);
      level->allocatePatchData(d_psi_scratch_handle);
    }
  }

  // fill scratch space for phi and psi
  fillGhostCellsForLevelSetFunctions(
    line_handle,
    d_lsm_algorithm->getPhiPatchDataHandle(),
    d_lsm_algorithm->getPsiPatchDataHandle());

  // write data to file of specified file type
  switch (file_type) {
    case ASCII: {
      writeOneDislocationLineToAsciiFile(
        base_name, line_handle, overwrite_file);
      break;
    }

    case BINARY: {
      writeOneDislocationLineToBinaryFile(
        base_name, line_handle, overwrite_file);
      break;
    }

    default: {
     TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "writeOneDislocationLine(): "
                  << "Invalid file type."
                  << endl);
    }

  }


  // deallocate scratch space for phi and psi data
  if (allocate_scratch_space) {
    for ( int ln=0 ; ln < num_levels; ln++ ) {
      Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
      level->deallocatePatchData(d_phi_scratch_handle);
      level->deallocatePatchData(d_psi_scratch_handle);
    }
  }
}


/* initializeDislocationLevelSetFunctions() */
void DislocationDynamicsModule::initializeDislocationLevelSetFunctions()
{
  d_lsm_algorithm->initializeLevelSetMethodCalculation();
}


/* computeNextDt() */
double DislocationDynamicsModule::computeNextDt()
{
  // allocate PatchData for phi/psi scratch data, forces, 
  // distances and velocity 
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
    level->allocatePatchData(d_phi_scratch_handle);
    level->allocatePatchData(d_psi_scratch_handle);
    level->allocatePatchData(d_force_handle);
    level->allocatePatchData(d_distance_handle);
    if (!d_use_persistent_velocity_data || !d_velocity_data_allocated) {
      level->allocatePatchData(d_velocity_handle);
      d_velocity_data_allocated = true;
    }
  }

  double dt = d_lsm_algorithm->computeStableDt();

  // deallocate PatchData for phi/psi scratch data, forces, 
  // distances and velocity 
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
    level->deallocatePatchData(d_phi_scratch_handle);
    level->deallocatePatchData(d_psi_scratch_handle);
    level->deallocatePatchData(d_force_handle);
    level->deallocatePatchData(d_distance_handle);
    if (!d_use_persistent_velocity_data) {
      level->deallocatePatchData(d_velocity_handle);
    }
  }

  return dt;

}


/* advanceDislocations() */
void DislocationDynamicsModule::advanceDislocations(
  const double dt)
{

  // reset hierarchy configuration if necessary
  if (d_hierarchy_configuration_needs_reset) {
    resetHierarchyConfiguration(d_patch_hierarchy,
      0, d_patch_hierarchy->getFinestLevelNumber());
  }

  // allocate PatchData for phi/psi scratch data, forces, 
  // distances, velocity, and tangent vectors
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
    level->allocatePatchData(d_phi_scratch_handle);
    level->allocatePatchData(d_psi_scratch_handle);
    level->allocatePatchData(d_force_handle);
    level->allocatePatchData(d_distance_handle);
    level->allocatePatchData(d_tangent_vectors);
    if (!d_use_persistent_velocity_data || !d_velocity_data_allocated) {
      level->allocatePatchData(d_velocity_handle);
      d_velocity_data_allocated = true;
    }
  }

  // preprocess data for advancing dislocations
  d_lsmdd_physics_strategy->preprocessAdvanceDislocations(
    *d_patch_hierarchy, 
    d_lsm_algorithm->getPhiPatchDataHandle(),
    d_lsm_algorithm->getPsiPatchDataHandle(),
    d_lsmdd_params,
    d_current_time);

  // advance level set functions 
  d_lsm_algorithm->advanceLevelSetFunctions(dt);

  // reinitialize level set functions to stabilize simulation 
  // if the integration step is not a reinitialization step
  int integrator_step = d_lsm_algorithm->numIntegrationStepsTaken();
  if ( ( d_use_reinitialization && 
         (integrator_step % d_reinitialization_interval != 0) ) ||
       ( d_use_orthogonalization && 
         (integrator_step % d_orthogonalization_interval != 0) ) ) {
    d_lsm_algorithm->reinitializeLevelSetFunctions(
      LSMLIB::PHI, d_num_stabilization_iterations);
    d_lsm_algorithm->reinitializeLevelSetFunctions(
      LSMLIB::PSI, d_num_stabilization_iterations);
  }

  // postprocess data after advancing dislocations
  d_lsmdd_physics_strategy->postprocessAdvanceDislocations(
    *d_patch_hierarchy, 
    d_lsm_algorithm->getPhiPatchDataHandle(),
    d_lsm_algorithm->getPsiPatchDataHandle(),
    d_lsmdd_params,
    d_current_time);

  // deallocate PatchData for phi/psi scratch data, forces, 
  // distances, velocity, and tangent vectors 
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
    level->deallocatePatchData(d_phi_scratch_handle);
    level->deallocatePatchData(d_psi_scratch_handle);
    level->deallocatePatchData(d_force_handle);
    level->deallocatePatchData(d_distance_handle);
    level->deallocatePatchData(d_tangent_vectors);
    if (!d_use_persistent_velocity_data) {
      level->deallocatePatchData(d_velocity_handle);
    }
  }

  // update current time and number of simulation steps taken
  d_current_time += dt;
  d_num_simulation_steps_taken++;

  // toggle upwind direction used to compute dislocation line field
  toggleUpwindDirection();

}

/*******************************************************************
 *
 * Methods inherited from LevelSetMethodPatchStrategy and
 * LevelSetMethodVelocityFieldStrategy classes.
 *
 *******************************************************************/

/* initializeLevelSetFunctionsOnPatch() */
void DislocationDynamicsModule::initializeLevelSetFunctionsOnPatch(
  Patch<3>& patch,
  const double time,
  const int phi_handle,
  const int psi_handle)
{
  d_lsmdd_physics_strategy->initializeLevelSetFunctionsOnPatch(
    patch, time, phi_handle, psi_handle);
}


/* setLevelSetFunctionBoundaryConditions() */
void DislocationDynamicsModule::setLevelSetFunctionBoundaryConditions(
  Patch<3>& patch,
  const double fill_time,
  const int phi_handle,
  const int psi_handle,
  const IntVector<3>& ghost_width_to_fill)
{
  d_lsmdd_physics_strategy->
    setLevelSetFunctionBoundaryConditions(patch, fill_time, 
                                          phi_handle, psi_handle, 
                                          ghost_width_to_fill);
}


/* computeStableDtOnPatch() */
double DislocationDynamicsModule::computeStableDtOnPatch(
  Patch<3>& patch,
  LevelSetFunctionIntegrator<3>* lsm_integrator,
  LevelSetMethodVelocityFieldStrategy<3>* lsm_velocity_field_strategy)
{
  (void) lsm_integrator;
  (void) lsm_velocity_field_strategy;
  return d_lsmdd_physics_strategy->computeStableDtOnPatch(patch);
}


/* computeVelocityField() */
void DislocationDynamicsModule::computeVelocityField(
  const double time,
  const int phi_handle,
  const int psi_handle,
  const int line_handle)
{
  // get number of levels in PatchHierarchy
  const int num_levels = d_patch_hierarchy->getNumberLevels();

  // update stress field and tangent vectors if time has changed 
  // since they were last computed
  if (time != d_last_stress_update_time) {

    // update last stress update time
    d_last_stress_update_time = time;

    /*
     * compute stress field 
     */

    // allocate memory for grad(phi), grad(psi) and dislocation line fields
    //   ( delta(phi)*delta(psi)*unit_tangent )
    for ( int ln=0 ; ln < num_levels; ln++ ) {
      Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
      level->allocatePatchData(d_grad_phi_plus_handle);
      level->allocatePatchData(d_grad_phi_minus_handle);
      level->allocatePatchData(d_grad_psi_plus_handle);
      level->allocatePatchData(d_grad_psi_minus_handle);
      level->allocatePatchData(d_dislocation_line_field_handle);
    } 


    /*
     * compute stress field due to dislocations
     */
    // zero out stress field
    d_elastic_stress_strategy->setStressFieldToZero();

    // add stress fields from dislocations
    for (int i = 0; i < d_num_dislocation_lines; i++) {

      computeDislocationLineField(i, phi_handle, psi_handle);

      // compute stress field 
      d_elastic_stress_strategy->addStressFieldForDislocationLine(
        d_dislocation_line_field_handle, d_burgers_vectors[i], 
        d_lsmdd_params);

    } // end loop over dislocation lines

    // compute auxiliary stress field
    if (d_lsmdd_physics_strategy->
        providesAuxiliaryStressField()) {

      for ( int ln=0 ; ln < num_levels; ln++ ) {
        Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
  
        for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
          const int patch_num = *pi;
          Pointer< Patch<3> > patch = level->getPatch(patch_num);
          if ( patch.isNull() ) {
            TBOX_ERROR(  "DislocationDynamicsModule::"
                      << "computeVelocityField(): "
                      << "Cannot find patch. Null patch pointer."
                      << endl);
          }

          d_lsmdd_physics_strategy->
            computeAuxiliaryStressFieldOnPatch(
              *patch,
              d_aux_stress_field_handle,
              d_elastic_stress_strategy->getStressFieldHandle(),
              time,
              d_lsmdd_params);

        } // end loop over patches in PatchLevel
      } // end loop over levels in PatchHierarchy

      // add auxiliary stress to total elastic stress
      d_elastic_stress_strategy->addAuxiliaryStressField(
        d_aux_stress_field_handle,
        d_lsmdd_params);

    } // end case:  LSMDD_PhysicsStrategy provides auxiliary stress

    // deallocate memory for grad(phi), grad(psi) and dislocation line field
    //   ( delta(phi)*delta(psi)*unit_tangent )
    for ( int ln=0 ; ln < num_levels; ln++ ) {
      Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
      level->deallocatePatchData(d_grad_phi_plus_handle);
      level->deallocatePatchData(d_grad_phi_minus_handle);
      level->deallocatePatchData(d_grad_psi_plus_handle);
      level->deallocatePatchData(d_grad_psi_minus_handle);
      level->deallocatePatchData(d_dislocation_line_field_handle);
    } 

    // allocate memory required to compute unit tangent vectors
    for ( int ln=0 ; ln < num_levels; ln++ ) {
    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
      level->allocatePatchData(d_grad_phi_central_handle);
      level->allocatePatchData(d_grad_psi_central_handle);
    }

    // compute unit tangent vectors for all of the dislocation lines
    for (int i = 0; i < d_num_dislocation_lines; i++) {
      computeUnitTangentVectorForDislocationLine(
        d_tangent_vector_handles[i], i, phi_handle, psi_handle);
    }

    //  deallocate memory for grad(phi) and grad(psi) 
    for ( int ln=0 ; ln < num_levels; ln++ ) {
      Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);
      level->deallocatePatchData(d_grad_phi_central_handle);
      level->deallocatePatchData(d_grad_psi_central_handle);
    }

    /*
     * fill ghostcells for tangent vector
     */
    for ( int ln=0 ; ln < num_levels; ln++ ) {
      // NOTE: 0.0 is "current time" and true indicates that physical
      //       boundary conditions should be set.
      d_tangent_fill_bdry_sched[ln]->fillData(0.0,true);
    }

  } // end recomputation of stress fields and tangent vectors


  /*
   * compute forces on the specified dislocation line 
   */
  // fill scratch space for phi and psi
  fillGhostCellsForLevelSetFunctions(
    line_handle,
    d_lsm_algorithm->getPhiPatchDataHandle(),
    d_lsm_algorithm->getPsiPatchDataHandle());

  for ( int ln=0 ; ln < num_levels; ln++ ) {

    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);

    for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "computeVelocityField(): "
                  << "Cannot find patch. Null patch pointer."
                  << endl);
      }

      d_lsmdd_physics_strategy->
        computeForceOnDislocationLineOnPatch(
          *patch,
          d_force_handle,
          d_elastic_stress_strategy->getStressFieldHandle(),
          d_tangent_vector_handles,
          d_lsm_algorithm->getPhiPatchDataHandle(),
          d_lsm_algorithm->getPsiPatchDataHandle(),
          line_handle,
          time,
          d_lsmdd_params);

    } // end loop over patches in PatchLevel
  } // end loop over levels in PatchHierarchy

  /*
   * fill ghostcells for force interpolation
   */
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    // NOTE: 0.0 is "current time" and true indicates that physical
    //       boundary conditions should be set.
    d_force_interp_fill_bdry_sched[ln]->fillData(0.0,true);
  }

  /*
   * initialize velocities to zero
   */
  for ( int ln=0 ; ln < num_levels; ln++ ) {

    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);

    for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "computeVelocityField(): "
                  << "Cannot find patch. Null patch pointer."
                  << endl);
      }

      Pointer< CellData<3,double> > velocity_data = 
        patch->getPatchData(d_velocity_handle);
      velocity_data->fillAll(0.0); 

    } // end loop over Patches
  } // end loop over PatchLevels

  /*
   * compute velocities on the specified dislocation line 
   */
  // fill scratch space for phi and psi
  fillGhostCellsForLevelSetFunctions(
    line_handle,
    d_lsm_algorithm->getPhiPatchDataHandle(),
    d_lsm_algorithm->getPsiPatchDataHandle());

  for ( int ln=0 ; ln < num_levels; ln++ ) {

    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);

    for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "computeVelocityField(): "
                  << "Cannot find patch. Null patch pointer."
                  << endl);
      }

      // initialize distances to the nearest dislocation line to
      // DBL_MAX
      Pointer< CellData<3,double> > distance_data = 
        patch->getPatchData(d_distance_handle);
      distance_data->fillAll(DBL_MAX); 

      d_lsmdd_physics_strategy->
        computeVelocityForDislocationLineOnPatch(
          *patch,
          d_velocity_handle,
          d_force_handle,
          d_tangent_vector_handles,
          d_distance_handle,
          d_phi_scratch_handle,
          d_psi_scratch_handle,
          line_handle,
          time,
          d_lsmdd_params);

    } // end loop over patches in PatchLevel
  } // end loop over levels in PatchHierarchy


  // extend velocity off of the dislocation line 
  d_lsm_phi_field_extension_alg->computeExtensionField(
    line_handle, -1, 
    d_lower_bc_phi[line_handle], d_upper_bc_phi[line_handle],
    d_lower_bc_velocity, d_upper_bc_velocity);
  d_lsm_psi_field_extension_alg->computeExtensionField(
    line_handle, -1,
    d_lower_bc_psi[line_handle], d_upper_bc_psi[line_handle],
    d_lower_bc_velocity, d_upper_bc_velocity);
}


/* resetHierarchyConfiguration() */
void DislocationDynamicsModule::resetHierarchyConfiguration(
  Pointer< PatchHierarchy<3> > hierarchy,
  const int coarsest_level,
  const int finest_level)
{
  // reset d_patch_hierarchy
  d_patch_hierarchy = hierarchy;

  // reset d_grid_geometry
  d_grid_geometry = d_patch_hierarchy->getGridGeometry();

  // recompute boundary boxes required for setting anti-periodic
  // boundary conditions
  const int num_levels = d_patch_hierarchy->getNumberLevels();

  // compute RefineSchedules for filling data 
  d_level_set_fcn_fill_bdry_sched.resizeArray(num_levels);
  d_force_interp_fill_bdry_sched.resizeArray(num_levels);
  d_tangent_fill_bdry_sched.resizeArray(num_levels);

  for (int ln = coarsest_level; ln <= finest_level; ln++) {
    Pointer< PatchLevel<3> > level = hierarchy->getPatchLevel(ln);

    // reset data transfer configuration for boundary filling
    // before computing tangent vector
    d_level_set_fcn_fill_bdry_sched[ln] =
      d_level_set_fcn_fill_bdry_alg->createSchedule(
        level, ln-1, hierarchy, 0);  // NULL RefinePatchStrategy

    // reset data transfer configuration for boundary filling
    // of unit tangent vector
    d_tangent_fill_bdry_sched[ln] =
      d_tangent_fill_bdry_alg->createSchedule(
        level, ln-1, hierarchy, 0);  // NULL RefinePatchStrategy

    // reset data transfer configuration for boundary filling
    // before interpolating force
    d_force_interp_fill_bdry_sched[ln] =
      d_force_interp_fill_bdry_alg->createSchedule(
        level, ln-1, hierarchy, 0);  // NULL RefinePatchStrategy

    // allocate memory for auxiliary stress field
    if (d_lsmdd_physics_strategy->
        providesAuxiliaryStressField()) {
      level->allocatePatchData(d_aux_stress_field_handle);
    } 

  } // end loop over levels

  // reset hierarchy configuration for FieldExtensionAlgorithm
  if (!d_lsm_phi_field_extension_alg.isNull()) {
    d_lsm_phi_field_extension_alg->resetHierarchyConfiguration(
      d_patch_hierarchy, coarsest_level, finest_level); 
  }
  if (!d_lsm_psi_field_extension_alg.isNull()) {
    d_lsm_psi_field_extension_alg->resetHierarchyConfiguration(
      d_patch_hierarchy, coarsest_level, finest_level); 
  }

  // reset hierarchy configuration for BoundaryConditionModule
  d_level_set_fcn_bc_module->resetHierarchyConfiguration(
    d_patch_hierarchy,
    coarsest_level, 
    finest_level,
    d_level_set_fcn_scratch_ghostcell_width);

  // set d_hierarchy_configuration_needs_reset to (finest_level < 0)
  d_hierarchy_configuration_needs_reset = (finest_level < 0);

}


/*******************************************************************
 *
 * Utility Methods
 *
 *******************************************************************/

/* getFromInput() */
void DislocationDynamicsModule::getFromInput(Pointer<Database> input_db)
{

  // get spatial derivative type and order
  if (input_db->keyExists("spatial_derivative_type")) {
    d_spatial_derivative_type = (SPATIAL_DERIVATIVE_TYPE)
      input_db->getInteger("spatial_derivative_type");
  } else {
    d_spatial_derivative_type = (SPATIAL_DERIVATIVE_TYPE)
      d_lsm_algorithm->getSpatialDerivativeType();
  }
  d_spatial_derivative_order = input_db->getIntegerWithDefault(
    "spatial_derivative_order", 
    d_lsm_algorithm->getSpatialDerivativeOrder());

  // get number of reinitialization iterations used to stabilize
  // computation 
  d_num_stabilization_iterations = input_db->getIntegerWithDefault(
    "num_stabilization_iterations",
    LSMDD_DEFAULT_NUM_STABILIZATION_ITERATIONS);

  // get "use_persistent velocity_data" flag
  d_use_persistent_velocity_data = input_db->getBoolWithDefault(
    "use_persistent_velocity_data", 
    LSMDD_DEFAULT_USE_PERSISTENT_VELOCITY);

  // read in boundary conditions for the velocity field
  string lower_bc_velocity_key = "lower_bc_velocity";

  int lower_bc[3];
  if (input_db->keyExists(lower_bc_velocity_key)) {
    input_db->getIntegerArray(
      lower_bc_velocity_key, lower_bc, 3);
    for (int i = 0; i < 3; i++) {
      d_lower_bc_velocity(i) = lower_bc[i];
    }
  } else {
    // set default boundary conditions for velocity field to "NONE"
    // NOTE: for problems where the physical boundaries are periodic, 
    //       this choice automatically sets periodic boundary conditions
    //       for the velocity field.
    for (int i = 0; i < 3; i++) {
      d_lower_bc_velocity(i) = BoundaryConditionModule<3>::NONE;
    }
  }

  string upper_bc_velocity_key = "upper_bc_velocity";

  int upper_bc[3];
  if (input_db->keyExists(upper_bc_velocity_key)) {
    input_db->getIntegerArray(
      upper_bc_velocity_key, upper_bc, 3);
    for (int i = 0; i < 3; i++) {
      d_upper_bc_velocity(i) = upper_bc[i];
    }
  } else {
    // set default boundary conditions for velocity field to "NONE"
    // NOTE: for problems where the physical boundaries are periodic, 
    //       this choice automatically sets periodic boundary conditions
    //       for the velocity field.
    for (int i = 0; i < 3; i++) {
      d_upper_bc_velocity(i) = BoundaryConditionModule<3>::NONE;
    }
  }

}


/* computeDislocationLineField() */
void DislocationDynamicsModule::computeDislocationLineField(
  const int line_handle,
  const int phi_handle,
  const int psi_handle)
{

  // fill scratch space for phi and psi
  fillGhostCellsForLevelSetFunctions(line_handle, phi_handle, psi_handle);

  // compute grad(phi)
  LevelSetMethodToolbox<3>::computePlusAndMinusSpatialDerivatives(
    d_patch_hierarchy,
    d_spatial_derivative_type,
    d_spatial_derivative_order,
    d_grad_phi_plus_handle,
    d_grad_phi_minus_handle,
    d_phi_scratch_handle,
    0); // the (line_handle)-th component of phi is copied to 
        // 0-th component of phi_scratch

  // compute grad(psi)
  LevelSetMethodToolbox<3>::computePlusAndMinusSpatialDerivatives(
    d_patch_hierarchy,
    d_spatial_derivative_type,
    d_spatial_derivative_order,
    d_grad_psi_plus_handle,
    d_grad_psi_minus_handle,
    d_psi_scratch_handle,
    0); // the (line_handle)-th component of psi is copied to 
        // 0-th component of psi_scratch

  // decide which grad(phi) and grad(psi) to use
  int grad_phi_handle, grad_psi_handle;
  if (d_upwind_spatial_derivative_flag) {
    grad_phi_handle = d_grad_phi_plus_handle;
    grad_psi_handle = d_grad_psi_plus_handle;
  } else {
    grad_phi_handle = d_grad_phi_minus_handle;
    grad_psi_handle = d_grad_psi_minus_handle;
  }


  // loop over PatchHierarchy and compute delta(phi)*delta(psi)*unit_tangent
  // by calling Fortran routines
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {

    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);

    for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "computeDislocationLineField(): "
                  << "Cannot find patch. Null patch pointer."
                  << endl);
      }

      // get dX
      Pointer< CartesianPatchGeometry<3> > patch_geometry = 
        patch->getPatchGeometry();
      const double* dX = patch_geometry->getDx();

      // get core radius and check that the grid resolution is
      // high enough to resolve it.
      double core_radius =  d_lsmdd_params.getCoreRadius();
      double max_dX = (dX[0] > dX[1]) ? dX[0] : dX[1];
      max_dX = (max_dX > dX[2]) ? max_dX : dX[2];
      if (core_radius/max_dX < 3) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "computeDislocationLineField(): "
                  << "grid resolution is too coarse to resolve dislocation "
                  << "core ... aborting simulation!!"
                  << endl);
      }

      // get PatchData, ghostboxes, and fillbox
      Pointer< CellData<3,double> > dislocation_line_data = 
        patch->getPatchData( d_dislocation_line_field_handle );
      Box<3> disloc_line_ghostbox = dislocation_line_data->getGhostBox();
      const IntVector<3> disloc_line_ghostbox_lower = 
        disloc_line_ghostbox.lower();
      const IntVector<3> disloc_line_ghostbox_upper = 
        disloc_line_ghostbox.upper();
      Box<3> disloc_line_fillbox = dislocation_line_data->getBox();
      const IntVector<3> disloc_line_fillbox_lower = 
        disloc_line_fillbox.lower();
      const IntVector<3> disloc_line_fillbox_upper = 
        disloc_line_fillbox.upper();

      Pointer< CellData<3,double> > phi_data = 
        patch->getPatchData( phi_handle );
      Pointer< CellData<3,double> > psi_data = 
        patch->getPatchData( psi_handle );
      Box<3> phi_ghostbox = phi_data->getGhostBox();
      const IntVector<3> phi_ghostbox_lower = phi_ghostbox.lower();
      const IntVector<3> phi_ghostbox_upper = phi_ghostbox.upper();
      Box<3> psi_ghostbox = psi_data->getGhostBox();
      const IntVector<3> psi_ghostbox_lower = psi_ghostbox.lower();
      const IntVector<3> psi_ghostbox_upper = psi_ghostbox.upper();

      Pointer< CellData<3,double> > grad_phi_data = 
        patch->getPatchData(grad_phi_handle);
      Pointer< CellData<3,double> > grad_psi_data = 
        patch->getPatchData(grad_psi_handle);
      Box<3> grad_phi_ghostbox = grad_phi_data->getGhostBox();
      const IntVector<3> grad_phi_ghostbox_lower = 
        grad_phi_ghostbox.lower();
      const IntVector<3> grad_phi_ghostbox_upper = 
        grad_phi_ghostbox.upper();
      Box<3> grad_psi_ghostbox = grad_psi_data->getGhostBox();
      const IntVector<3> grad_psi_ghostbox_lower = 
        grad_psi_ghostbox.lower();
      const IntVector<3> grad_psi_ghostbox_upper = 
        grad_psi_ghostbox.upper();

      // get pointers to actual data in memory
      double* disloc_line_x = dislocation_line_data->getPointer(0);
      double* disloc_line_y = dislocation_line_data->getPointer(1);
      double* disloc_line_z = dislocation_line_data->getPointer(2);
      double* phi = phi_data->getPointer(line_handle);
      double* grad_phi_x = grad_phi_data->getPointer(0);
      double* grad_phi_y = grad_phi_data->getPointer(1);
      double* grad_phi_z = grad_phi_data->getPointer(2);
      double* psi = psi_data->getPointer(line_handle);
      double* grad_psi_x = grad_psi_data->getPointer(0);
      double* grad_psi_y = grad_psi_data->getPointer(1);
      double* grad_psi_z = grad_psi_data->getPointer(2);

      LSMDD_COMPUTE_DISLOCATION_LINE_FIELD(
        disloc_line_x, disloc_line_y, disloc_line_z,
        &disloc_line_ghostbox_lower[0],
        &disloc_line_ghostbox_upper[0],
        &disloc_line_ghostbox_lower[1],
        &disloc_line_ghostbox_upper[1],
        &disloc_line_ghostbox_lower[2],
        &disloc_line_ghostbox_upper[2],
        phi,
        &phi_ghostbox_lower[0],
        &phi_ghostbox_upper[0],
        &phi_ghostbox_lower[1],
        &phi_ghostbox_upper[1],
        &phi_ghostbox_lower[2],
        &phi_ghostbox_upper[2],
        grad_phi_x, grad_phi_y, grad_phi_z,
        &grad_phi_ghostbox_lower[0],
        &grad_phi_ghostbox_upper[0],
        &grad_phi_ghostbox_lower[1],
        &grad_phi_ghostbox_upper[1],
        &grad_phi_ghostbox_lower[2],
        &grad_phi_ghostbox_upper[2],
        psi,
        &psi_ghostbox_lower[0],
        &psi_ghostbox_upper[0],
        &psi_ghostbox_lower[1],
        &psi_ghostbox_upper[1],
        &psi_ghostbox_lower[2],
        &psi_ghostbox_upper[2],
        grad_psi_x, grad_psi_y, grad_psi_z,
        &grad_psi_ghostbox_lower[0],
        &grad_psi_ghostbox_upper[0],
        &grad_psi_ghostbox_lower[1],
        &grad_psi_ghostbox_upper[1],
        &grad_psi_ghostbox_lower[2],
        &grad_psi_ghostbox_upper[2],
        &disloc_line_fillbox_lower[0],
        &disloc_line_fillbox_upper[0],
        &disloc_line_fillbox_lower[1],
        &disloc_line_fillbox_upper[1],
        &disloc_line_fillbox_lower[2],
        &disloc_line_fillbox_upper[2],
        dX, &core_radius);

    }  // end loop over PatchLevel
  }  // end loop over PatchHierarchy

}


/* computeUnitTangentVectorForDislocationLine() */
void DislocationDynamicsModule::computeUnitTangentVectorForDislocationLine(
  const int tangent_vector_handle,
  const int line_handle,
  const int phi_handle,
  const int psi_handle)
{
  // fill scratch space for phi and psi
  fillGhostCellsForLevelSetFunctions(line_handle, phi_handle, psi_handle);

  // compute grad(phi)
  LevelSetMethodToolbox<3>::computeCentralSpatialDerivatives(
    d_patch_hierarchy,
    (d_spatial_derivative_order < 5 ? d_spatial_derivative_order : 4),
    d_grad_phi_central_handle,
    d_phi_scratch_handle,
    0); // the (line_handle)-th component of phi is copied to 
        // 0-th component of phi_scratch

  // compute grad(psi)
  LevelSetMethodToolbox<3>::computeCentralSpatialDerivatives(
    d_patch_hierarchy,
    (d_spatial_derivative_order < 5 ? d_spatial_derivative_order : 4),
    d_grad_psi_central_handle,
    d_psi_scratch_handle,
    0); // the (line_handle)-th component of psi is copied to 
        // 0-th component of psi_scratch


  // loop over PatchHierarchy and compute grad(phi) cross grad(psi)
  // by calling Fortran routines
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {

    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);

    for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "computeUnitTangentVectorForDislocationLine(): "
                  << "Cannot find patch. Null patch pointer."
                  << endl);
      }

      // get dX
      Pointer< CartesianPatchGeometry<3> > patch_geometry = 
        patch->getPatchGeometry();
      const double* dX = patch_geometry->getDx();

      // get PatchData, ghostboxes, and fillbox
      Pointer< CellData<3,double> > unit_tangent_data = 
        patch->getPatchData( tangent_vector_handle );
      Box<3> unit_tangent_ghostbox = unit_tangent_data->getGhostBox();
      const IntVector<3> unit_tangent_ghostbox_lower = 
        unit_tangent_ghostbox.lower();
      const IntVector<3> unit_tangent_ghostbox_upper = 
        unit_tangent_ghostbox.upper();
      Box<3> unit_tangent_fillbox = unit_tangent_data->getBox();
      const IntVector<3> unit_tangent_fillbox_lower = 
        unit_tangent_fillbox.lower();
      const IntVector<3> unit_tangent_fillbox_upper = 
        unit_tangent_fillbox.upper();

      Pointer< CellData<3,double> > grad_phi_data = 
        patch->getPatchData(d_grad_phi_central_handle);
      Box<3> grad_phi_ghostbox = grad_phi_data->getGhostBox();
      const IntVector<3> grad_phi_ghostbox_lower = 
        grad_phi_ghostbox.lower();
      const IntVector<3> grad_phi_ghostbox_upper = 
        grad_phi_ghostbox.upper();

      Pointer< CellData<3,double> > grad_psi_data = 
        patch->getPatchData(d_grad_psi_central_handle);
      Box<3> grad_psi_ghostbox = grad_psi_data->getGhostBox();
      const IntVector<3> grad_psi_ghostbox_lower = 
        grad_psi_ghostbox.lower();
      const IntVector<3> grad_psi_ghostbox_upper = 
        grad_psi_ghostbox.upper();

      // get pointers to actual data in memory
      double* unit_tangent_x = unit_tangent_data->getPointer(0);
      double* unit_tangent_y = unit_tangent_data->getPointer(1);
      double* unit_tangent_z = unit_tangent_data->getPointer(2);
      double* grad_phi_x = grad_phi_data->getPointer(0);
      double* grad_phi_y = grad_phi_data->getPointer(1);
      double* grad_phi_z = grad_phi_data->getPointer(2);
      double* grad_psi_x = grad_psi_data->getPointer(0);
      double* grad_psi_y = grad_psi_data->getPointer(1);
      double* grad_psi_z = grad_psi_data->getPointer(2);

      LSMDD_COMPUTE_UNIT_TANGENT_VECTOR_FIELD(
        unit_tangent_x, unit_tangent_y, unit_tangent_z,
        &unit_tangent_ghostbox_lower[0],
        &unit_tangent_ghostbox_upper[0],
        &unit_tangent_ghostbox_lower[1],
        &unit_tangent_ghostbox_upper[1],
        &unit_tangent_ghostbox_lower[2],
        &unit_tangent_ghostbox_upper[2],
        grad_phi_x, grad_phi_y, grad_phi_z,
        &grad_phi_ghostbox_lower[0],
        &grad_phi_ghostbox_upper[0],
        &grad_phi_ghostbox_lower[1],
        &grad_phi_ghostbox_upper[1],
        &grad_phi_ghostbox_lower[2],
        &grad_phi_ghostbox_upper[2],
        grad_psi_x, grad_psi_y, grad_psi_z,
        &grad_psi_ghostbox_lower[0],
        &grad_psi_ghostbox_upper[0],
        &grad_psi_ghostbox_lower[1],
        &grad_psi_ghostbox_upper[1],
        &grad_psi_ghostbox_lower[2],
        &grad_psi_ghostbox_upper[2],
        &unit_tangent_fillbox_lower[0],
        &unit_tangent_fillbox_upper[0],
        &unit_tangent_fillbox_lower[1],
        &unit_tangent_fillbox_upper[1],
        &unit_tangent_fillbox_lower[2],
        &unit_tangent_fillbox_upper[2],
        dX);

    }  // end loop over PatchLevel
  }  // end loop over PatchHierarchy

}


/* initializeVariables() */
void DislocationDynamicsModule::initializeVariables()
{
  // setup ghost cell widths
  IntVector<3> zero_ghostcell_width(0);
  IntVector<3> one_ghostcell_width(1);
  int scratch_num_ghostcells = -1; // temporary value
  switch (d_spatial_derivative_type) {
    case ENO: {
      scratch_num_ghostcells = d_spatial_derivative_order;
      break;
    }
    case WENO: {
      scratch_num_ghostcells = d_spatial_derivative_order/2 + 1;
      break;
    }
    default:
      TBOX_ERROR("DislocationDynamicsModule::"
              << "initializeVariables(): "
              << "Unsupported spatial derivative type.  "
              << "Only ENO and WENO derivatives are supported."
              << endl );
  }
  d_level_set_fcn_scratch_ghostcell_width = 
    IntVector<3>(scratch_num_ghostcells); 

  // get pointer to VariableDatabase
  VariableDatabase<3> *var_db = VariableDatabase<3>::getDatabase();
  
  // get contexts used by dislocation dynamics module
  Pointer<VariableContext> lsmdd_context = 
    var_db->getContext("LSMDD CONTEXT");
  Pointer<VariableContext> lsmdd_scratch_context = 
    var_db->getContext("LSMDD SCRATCH CONTEXT");
  Pointer<VariableContext> plus_context = 
    var_db->getContext("LSMDD_PLUS_DERIVATIVE");
  Pointer<VariableContext> minus_context =
    var_db->getContext("LSMDD_MINUS_DERIVATIVE");
  Pointer<VariableContext> central_context =
    var_db->getContext("LSMDD_CENTRAL_DERIVATIVE");

  // phi scratch
  Pointer< CellVariable<3,double> > phi_variable = 
    new CellVariable<3,double>("phi (LSMDD)",1);
  d_phi_scratch_handle = var_db->registerVariableAndContext(
    phi_variable, lsmdd_scratch_context, 
    d_level_set_fcn_scratch_ghostcell_width);

  // psi scratch
  Pointer< CellVariable<3,double> > psi_variable =
    new CellVariable<3,double>("psi (LSMDD)",1);
  d_psi_scratch_handle = var_db->registerVariableAndContext(
    psi_variable, lsmdd_scratch_context, 
    d_level_set_fcn_scratch_ghostcell_width);

  // grad(phi)
  Pointer< CellVariable<3,double> > grad_phi_variable =
    new CellVariable<3,double>("grad phi (LSMDD)",3);
  d_grad_phi_plus_handle = var_db->registerVariableAndContext(
    grad_phi_variable, plus_context, zero_ghostcell_width);
  d_grad_phi_minus_handle = var_db->registerVariableAndContext(
    grad_phi_variable, minus_context, zero_ghostcell_width);
  d_grad_phi_central_handle = var_db->registerVariableAndContext(
    grad_phi_variable, central_context, zero_ghostcell_width);

  // grad(psi)
  Pointer< CellVariable<3,double> > grad_psi_variable =
    new CellVariable<3,double>("grad psi (LSMDD)",3);
  d_grad_psi_plus_handle = var_db->registerVariableAndContext(
    grad_psi_variable, plus_context, zero_ghostcell_width);
  d_grad_psi_minus_handle = var_db->registerVariableAndContext(
    grad_psi_variable, minus_context, zero_ghostcell_width);
  d_grad_psi_central_handle = var_db->registerVariableAndContext(
    grad_psi_variable, central_context, zero_ghostcell_width);

  // dislocation line field
  Pointer< CellVariable<3,double> > dislocation_line_variable =
    new CellVariable<3,double>("dislocation line field",3);
  d_dislocation_line_field_handle = var_db->registerVariableAndContext(
    dislocation_line_variable, lsmdd_context, zero_ghostcell_width);

  // velocity
  Pointer< CellVariable<3,double> > velocity_variable =
    new CellVariable<3,double>("velocity (LSMDD)",3);
  d_velocity_handle = var_db->registerVariableAndContext(
    velocity_variable, lsmdd_context, one_ghostcell_width);

  // auxiliary  stress field
  if (d_lsmdd_physics_strategy->providesAuxiliaryStressField()) {
    Pointer< CellVariable<3,double> > aux_stress_field_variable =
      new CellVariable<3,double>("auxiliary stress field (LSMDD)",6);
    d_aux_stress_field_handle = var_db->registerVariableAndContext(
      aux_stress_field_variable, lsmdd_context, zero_ghostcell_width);
  }

  // force
  Pointer< CellVariable<3,double> > force_variable =
    new CellVariable<3,double>("dislocation force (LSMDD)",3);
  d_force_handle = var_db->registerVariableAndContext(
    force_variable, lsmdd_context, one_ghostcell_width);

  // unit tangent vector
  Pointer< CellVariable<3,double> > unit_tangent_vector_variable =
    new CellVariable<3,double>("unit tangent vector(LSMDD)",3);
  for (int k=0; k < d_num_dislocation_lines; k++) {
    stringstream context_name("");
    context_name << "LSMDD_TANGENT_VECTOR" << k;
    d_tangent_vector_handles.push_back(
      var_db->registerVariableAndContext(
        unit_tangent_vector_variable, 
        var_db->getContext(context_name.str()),
        one_ghostcell_width) );
    d_tangent_vectors.setFlag( d_tangent_vector_handles[k] );
  }

  // distance to dislocation line
  Pointer< CellVariable<3,double> > distance_variable =
    new CellVariable<3,double>("distance to dislocation line (LSMDD)",1);
  d_distance_handle = var_db->registerVariableAndContext(
    distance_variable, lsmdd_context, one_ghostcell_width);

  // Burgers vectors for dislocation lines
  d_burgers_vectors.resizeArray(d_num_dislocation_lines);
  for (int i = 0; i < d_num_dislocation_lines; i++) {

    d_burgers_vectors[i] = 
      d_lsmdd_physics_strategy->getBurgersVector(i);

  }
}


/* initializeCommunicationObjects() */
void DislocationDynamicsModule::initializeCommunicationObjects()
{

  // get pointer to VariableDatabase
  VariableDatabase<3> *var_db = VariableDatabase<3>::getDatabase();

  /*
   * Look up refine operation
   */
  // get CellVariable associated with d_phi_scratch_handle
  Pointer< CellVariable<3,double> > phi_variable;
  Pointer< Variable<3> > tmp_variable;
  Pointer<VariableContext> tmp_context;
  if (var_db->mapIndexToVariableAndContext(d_phi_scratch_handle,
                                           tmp_variable, tmp_context)) {
    phi_variable = tmp_variable;
  } else {
    TBOX_ERROR(  "DislocationDynamics::"
              << "initializeCommunicationObjects(): "
              << "Specified field handle does not exist or does "
              << "not correspond to cell-centered data"
              << endl);
  }

  // lookup refine operations
  Pointer< RefineOperator<3> > refine_op =
    d_grid_geometry->lookupRefineOperator(phi_variable, "LINEAR_REFINE");


  // initialize communications objects used when computing the
  // unit tangent vector
  d_level_set_fcn_fill_bdry_alg = new RefineAlgorithm<3>;
  d_level_set_fcn_fill_bdry_sched.setNull();
  d_level_set_fcn_fill_bdry_alg->registerRefine(
    d_phi_scratch_handle,
    d_phi_scratch_handle,
    d_phi_scratch_handle,
    refine_op);
  d_level_set_fcn_fill_bdry_alg->registerRefine(
    d_psi_scratch_handle,
    d_psi_scratch_handle,
    d_psi_scratch_handle,
    refine_op);


  // initialize communications objects used to fill ghostcells for 
  // tangent vector
  d_tangent_fill_bdry_alg = new RefineAlgorithm<3>;
  d_tangent_fill_bdry_sched.setNull();
  for (int k = 0; k < d_num_dislocation_lines; k++) {
    d_tangent_fill_bdry_alg->registerRefine(
      d_tangent_vector_handles[k],
      d_tangent_vector_handles[k],
      d_tangent_vector_handles[k],
      refine_op);
  }


  // initialize communications objects used to fill ghostcells for force
  d_force_interp_fill_bdry_alg = new RefineAlgorithm<3>;
  d_force_interp_fill_bdry_sched.setNull();
  d_force_interp_fill_bdry_alg->registerRefine(
    d_force_handle,
    d_force_handle,
    d_force_handle,
    refine_op);

 
  // initialize d_hierarchy_configuration_needs_reset to true
  d_hierarchy_configuration_needs_reset = true;

  // configure communications schedules for ALL levels using the
  // specified PatchHierarchy
  resetHierarchyConfiguration(d_patch_hierarchy,
    0, d_patch_hierarchy->getFinestLevelNumber());
 
}


/* fillGhostCellsForLevelSetFunctions() */
void DislocationDynamicsModule::fillGhostCellsForLevelSetFunctions(
  const int line_handle, 
  const int phi_handle,
  const int psi_handle)
{

  // copy the (line-handle)-th component of phi and psi data to 
  // scratch space
   LevelSetMethodToolbox<3>::copySAMRAIData(
     d_patch_hierarchy,
     d_phi_scratch_handle, phi_handle,
     0, line_handle);
   LevelSetMethodToolbox<3>::copySAMRAIData(
     d_patch_hierarchy,
     d_psi_scratch_handle, psi_handle,
     0, line_handle);

  // fill ghostcells for computing grad(phi) and grad(psi)
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {
    // NOTE: 0.0 is "current time" and true indicates that physical
    //       boundary conditions should be set.
    d_level_set_fcn_fill_bdry_sched[ln]->fillData(0.0,true);
  }
  d_level_set_fcn_bc_module->imposeBoundaryConditions(
    d_phi_scratch_handle, 
    d_lower_bc_phi[line_handle],
    d_upper_bc_phi[line_handle],
    d_spatial_derivative_type,
    d_spatial_derivative_order,
    0);
  d_level_set_fcn_bc_module->imposeBoundaryConditions(
    d_psi_scratch_handle, 
    d_lower_bc_psi[line_handle],
    d_upper_bc_psi[line_handle],
    d_spatial_derivative_type,
    d_spatial_derivative_order,
    0);
}


/* writeOneDislocationLineToAsciiFile() */
void DislocationDynamicsModule::writeOneDislocationLineToAsciiFile(
  const string& base_name,
  const int line_handle,
  const bool overwrite_file)
{

  // argument check
  if ( (line_handle < 0) || (line_handle > d_num_dislocation_lines) ) {
     TBOX_ERROR(  "DislocationDynamicsModule::"
               << "writeOneDislocationLineToAsciiFile(): "
               << "line_handle out of bounds"
               << endl);
  }

  // set up filename for parallel output
  string file_name; 
  if (tbox::MPI::getNodes() > 1) {
    int rank = tbox::MPI::getRank();
    stringstream file_name_stream;
    char rank_buf[128];
    sprintf(rank_buf, "%05d",rank);
    file_name_stream << base_name << ".lsmdd." << rank_buf;
    file_name = file_name_stream.str();
  } else {
    stringstream file_name_stream;
    file_name_stream << base_name << ".lsmdd";
    file_name = file_name_stream.str();
  }

  // open file 
  ofstream outfile;
  if (overwrite_file) {
    outfile.open(file_name.c_str(), ios::out | ios::trunc);
  } else {
    outfile.open(file_name.c_str(), ios::out | ios::app);
  }
  if ( outfile.fail() ) {
     TBOX_ERROR(  "DislocationDynamicsModule::"
               << "writeOneDislocationLineToAsciiFile(): "
               << "Can't open " << file_name << " for writing! " 
               << endl);
  }


  /*
   * loop over PatchHierarchy and compute forces on the 
   * specified dislocation line 
   */
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {

    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);

    for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "writeOneDislocationLineToAsciiFile(): "
                  << "Cannot find patch. Null patch pointer."
                  << endl);
      }

      // get geometry
      Pointer< CartesianPatchGeometry<3> > patch_geom 
        = patch->getPatchGeometry();
      const double* dX = patch_geom->getDx();
      const double* X_lower = patch_geom->getXLower();

      // get PatchData
      Pointer< CellData<3,double> > phi_data =
        patch->getPatchData( d_phi_scratch_handle );
      Pointer< CellData<3,double> > psi_data =
        patch->getPatchData( d_psi_scratch_handle );

      // get index space information
      Box<3> phi_ghostbox = phi_data->getGhostBox();
      const IntVector<3> phi_ghostbox_dims = phi_ghostbox.numberCells();
      const IntVector<3> phi_ghostcell_width = phi_data->getGhostCellWidth();
      Box<3> psi_ghostbox = psi_data->getGhostBox();
      const IntVector<3> psi_ghostbox_dims = psi_ghostbox.numberCells();
      const IntVector<3> psi_ghostcell_width = psi_data->getGhostCellWidth();

      // compute fill box over which to calculate dislocation line.
      // NOTE:  to ensure that we reach the boundaries of the physical
      // domain, the loops over the grid includes fillbox plus one
      // ghostcell at the lower end of the index space in each
      // coordinate direction (i.e. loops run from -1 to (num_cells-1)
      // instead of from 0 to (num_cells-1) )
      Box<3> fillbox = phi_data->getBox();
      const IntVector<3> fillbox_dims = fillbox.numberCells();

      // get data pointers
      // NOTE:  data for the line_handle-th line has been copied
      //        to the 0-th component of the scratch space
      double *phi = phi_data->getPointer();
      double *psi = psi_data->getPointer();

      // grid index trackers
      int idx_phi = 0;
      int idx_psi = 0;
    
      // add ghostcell width in z-direction times number of cells in
      // xy-plane to get to starting plane of fill box
      idx_phi            += (phi_ghostcell_width(2) - 1)
                          * phi_ghostbox_dims(0)
                          * phi_ghostbox_dims(1);
      idx_psi            += (psi_ghostcell_width(2) - 1)
                          * psi_ghostbox_dims(0)
                          * psi_ghostbox_dims(1);
 
      for (int k = -1; k < fillbox_dims(2); k++) {
   
        // add ghostcell width in y-direction times number of cells in
        // x-direction to get to start of next plane of fill box
        idx_phi            += (phi_ghostcell_width(1) - 1)
                            * phi_ghostbox_dims(0);
        idx_psi            += (psi_ghostcell_width(1) - 1)
                            * psi_ghostbox_dims(0);
 
        for (int j = -1; j < fillbox_dims(1); j++) {

          // add ghostcell width in x-direction to get to starting
          // column of fill box 
          idx_phi            += (phi_ghostcell_width(0) - 1);
          idx_psi            += (psi_ghostcell_width(0) - 1);
 
          for (int i = -1; i < fillbox_dims(0); i++) {
 
            // compute coordinates of cell center
            double X[3];
            X[0] = X_lower[0] + (i + 0.5)*dX[0];
            X[1] = X_lower[1] + (j + 0.5)*dX[1];
            X[2] = X_lower[2] + (k + 0.5)*dX[2];
    
            /*
             * loop over six tetrahedra in the cell with corners given
             * by the centers of the cells in the index space
             * [(i,j,k),(i+1,j+1,k+1)]
             */
    
            for (int tet_num = 0; tet_num < 6; tet_num++) {
    
              double x1[3], x2[3], x3[3], x4[3];
              double endpt1[3], endpt2[3];
              double phi_tet[4], psi_tet[4];
    
              GET_TETRAHEDRON(x1, x2, x3, x4, phi_tet, psi_tet,
                              tet_num, i, j, k,
                              X, dX, phi, psi, idx_phi, idx_psi,
                              phi_ghostbox_dims, psi_ghostbox_dims);

              int num_intersections = LSM3D_findLineInTetrahedron(endpt1,
                                                                  endpt2,
                                                                  x1,
                                                                  x2,
                                                                  x3,
                                                                  x4,
                                                                  phi_tet,
                                                                  psi_tet);
 
              /*
               * if the dislocation line intersects the tetrahedron,
               * output dislocation line segment
               */
              if (num_intersections > 0) {  

                outfile << endpt1[0] << " "
                        << endpt1[1] << " "
                        << endpt1[2] << " "
                        << endpt2[0] << " "
                        << endpt2[1] << " "
                        << endpt2[2] << endl;

              } // end case: dislocation line intersects tetrahedron

            } // end loop over tetrahedra

            // update array indices
            idx_phi++;
            idx_psi++;
          }

          // add ghostcell width in x-direction to get to start of next
          // row of SAMRAI data
          idx_phi            += phi_ghostcell_width(0);
          idx_psi            += psi_ghostcell_width(0);

        }

        // add ghostcell width in y-direction times number of cells in
        // x-direction to get to start of next plane of SAMRAI data
        idx_phi            += phi_ghostcell_width(1)
                            * phi_ghostbox_dims(0);
        idx_psi            += psi_ghostcell_width(1)
                            * psi_ghostbox_dims(0);

      } // end loop over grid

    } // end loop over Patches

  } // end loop over PatchLevels

  // output a row of NaNs ending with the line_handle to indicate that 
  // the data for the specified dislocation is finished
  outfile << "NaN NaN NaN NaN NaN " << line_handle << endl;

  // close outfile
  outfile.close();

}


/* writeOneDislocationLineToBinaryFile() */
void DislocationDynamicsModule::writeOneDislocationLineToBinaryFile(
  const string& base_name,
  const int line_handle,
  const bool overwrite_file)
{

  // argument check
  if ( (line_handle < 0) || (line_handle > d_num_dislocation_lines) ) {
     TBOX_ERROR(  "DislocationDynamicsModule::"
               << "writeOneDislocationLineToBinaryFile(): "
               << "line_handle out of bounds"
               << endl);
  }

  // set up filename for parallel output
  string file_name; 
  if (tbox::MPI::getNodes() > 1) {
    int rank = tbox::MPI::getRank();
    stringstream file_name_stream;
    char rank_buf[128];
    sprintf(rank_buf, "%05d",rank);
    file_name_stream << base_name << "." << rank_buf << ".lsmdd";
    file_name = file_name_stream.str();
  } else {
    stringstream file_name_stream;
    file_name_stream << base_name << ".lsmdd";
    file_name = file_name_stream.str();
  }

  // open file and write meta-data
  fstream outfile;
  if (overwrite_file) {

    // open file
    outfile.open(file_name.c_str(), ios::binary | ios::out | ios::trunc);

    // write BINARY format version number
    outfile.write( (char*) &s_lsmdd_version, sizeof(int) ); 

    // write number of dislocations in output file
    int num_dislocations = 1;
    outfile.write( (char*) &num_dislocations, sizeof(int) ); 

    // leave space where meta-data about where data for 
    // each dislocation line begins in the file
      outfile.seekp( sizeof(int)*s_lsmdd_binary_output_max_num_dislocations,
                     ios::cur );

  } else {

    // open file and seek to beginning
    outfile.open(file_name.c_str(), ios::binary | ios::in | ios::out); 

    // check that output file version is consistent with
    // current file format version
    int version;
    outfile.read( (char*) &version, sizeof(int) ); 
    if (version != s_lsmdd_version) {
      TBOX_WARNING( "DislocationDynamicsModule::"
                  << "writeOneDislocationLineToBinaryFile(): "
                  << " existing output file (" 
                  << file_name 
                  << ") uses an older version of the file format..."
                  << endl
                  << "  Resulting output file may be corrupted."
                  << endl);
    }

    // update number of dislocations in output file
    int num_dislocations;
    outfile.read( (char*) &num_dislocations, sizeof(int) ); 
    num_dislocations++;
    outfile.seekp( -sizeof(int), ios::cur );  // skip version information
    outfile.write( (char*) &num_dislocations, sizeof(int) ); 

    // seek to end of file to begin writing data for current 
    // dislocation line
    outfile.seekp( 0 , ios::end );

  }
  if ( outfile.fail() ) {
     TBOX_ERROR(  "DislocationDynamicsModule::"
               << "writeOneDislocationLineToBinaryFile(): "
               << "Can't open " << base_name << " for writing! " 
               << endl);

  }

  // write line_handle to file
  fstream::pos_type start_current_data_pos = outfile.tellp();
  outfile.write( (char*) &line_handle , sizeof(int) );

  // leave space for number of dislocation line segments
  fstream::pos_type number_segment_pos = outfile.tellp();
  outfile.seekp( sizeof(int) , ios::cur );

  // initialize dislocation counter
  int num_dislocation_segments = 0;

  // cache the size of endpoint array
  int sizeof_endpt_array = 3*sizeof(double);

  /*
   * loop over PatchHierarchy and compute forces on the 
   * specified dislocation line 
   */
  const int num_levels = d_patch_hierarchy->getNumberLevels();
  for ( int ln=0 ; ln < num_levels; ln++ ) {

    Pointer< PatchLevel<3> > level = d_patch_hierarchy->getPatchLevel(ln);

    for (PatchLevelIterator<3> pi(level); pi; pi++) { // loop over patches
      const int patch_num = *pi;
      Pointer< Patch<3> > patch = level->getPatch(patch_num);
      if ( patch.isNull() ) {
        TBOX_ERROR(  "DislocationDynamicsModule::"
                  << "writeOneDislocationLineToBinaryFile(): "
                  << "Cannot find patch. Null patch pointer."
                  << endl);
      }

      // get geometry
      Pointer< CartesianPatchGeometry<3> > patch_geom 
        = patch->getPatchGeometry();
      const double* dX = patch_geom->getDx();
      const double* X_lower = patch_geom->getXLower();

      // get PatchData
      Pointer< CellData<3,double> > phi_data =
        patch->getPatchData( d_phi_scratch_handle );
      Pointer< CellData<3,double> > psi_data =
        patch->getPatchData( d_psi_scratch_handle );

      // get index space information
      Box<3> phi_ghostbox = phi_data->getGhostBox();
      const IntVector<3> phi_ghostbox_dims = phi_ghostbox.numberCells();
      const IntVector<3> phi_ghostcell_width = phi_data->getGhostCellWidth();
      Box<3> psi_ghostbox = psi_data->getGhostBox();
      const IntVector<3> psi_ghostbox_dims = psi_ghostbox.numberCells();
      const IntVector<3> psi_ghostcell_width = psi_data->getGhostCellWidth();

      // compute fill box over which to calculate dislocation line.
      // NOTE:  to ensure that we reach the boundaries of the physical 
      // domain, the loops over the grid includes fillbox plus one 
      // ghostcell at the lower end of the index space in each 
      // coordinate direction (i.e. loops run from -1 to (dim-1)
      // instead of from 0 to (dim-1) )
      Box<3> fillbox = phi_data->getBox();
      const IntVector<3> fillbox_dims = fillbox.numberCells();

      // get data pointers
      double *phi = phi_data->getPointer();
      double *psi = psi_data->getPointer();

      // grid index trackers
      int idx_phi = 0;
      int idx_psi = 0;
    
      // add ghostcell width in z-direction times number of cells in
      // xy-plane to get to starting plane of fill box
      idx_phi            += (phi_ghostcell_width(2) - 1)
                          * phi_ghostbox_dims(0)
                          * phi_ghostbox_dims(1);
      idx_psi            += (psi_ghostcell_width(2) - 1)
                          * psi_ghostbox_dims(0)
                          * psi_ghostbox_dims(1);
 
      for (int k = -1; k < fillbox_dims(2); k++) {
   
        // add ghostcell width in y-direction times number of cells in
        // x-direction to get to start of next plane of fill box
        idx_phi            += (phi_ghostcell_width(1) - 1)
                            * phi_ghostbox_dims(0);
        idx_psi            += (psi_ghostcell_width(1) - 1)
                            * psi_ghostbox_dims(0);
 
        for (int j = -1; j < fillbox_dims(1); j++) {

          // add ghostcell width in x-direction to get to starting
          // column of fill box 
          idx_phi            += (phi_ghostcell_width(0) - 1);
          idx_psi            += (psi_ghostcell_width(0) - 1);
 
          for (int i = -1; i < fillbox_dims(0); i++) {
 
            // compute coordinates of cell center
            double X[3];
            X[0] = X_lower[0] + (i + 0.5)*dX[0];
            X[1] = X_lower[1] + (j + 0.5)*dX[1];
            X[2] = X_lower[2] + (k + 0.5)*dX[2];
    
            /*
             * loop over six tetrahedra in the cell with corners given
             * by the centers of the cells in the index space
             * [(i,j,k),(i+1,j+1,k+1)]
             */
    
            for (int tet_num = 0; tet_num < 6; tet_num++) {
    
              double x1[3], x2[3], x3[3], x4[3];
              double endpt1[3], endpt2[3];
              double phi_tet[4], psi_tet[4];
    
              GET_TETRAHEDRON(x1, x2, x3, x4, phi_tet, psi_tet,
                              tet_num, i, j, k,
                              X, dX, phi, psi, idx_phi, idx_psi,
                              phi_ghostbox_dims, psi_ghostbox_dims);

              int num_intersections = LSM3D_findLineInTetrahedron(endpt1,
                                                                  endpt2,
                                                                  x1,
                                                                  x2,
                                                                  x3,
                                                                  x4,
                                                                  phi_tet,
                                                                  psi_tet);

              /*
               * if the dislocation line intersects the tetrahedron,
               * output dislocation line segment
               */
              if (num_intersections > 0) {  
   
                outfile.write( (char*) endpt1, sizeof_endpt_array ); 
                outfile.write( (char*) endpt2, sizeof_endpt_array ); 

                num_dislocation_segments++;

              } // end case: dislocation line intersects tetrahedron

            } // end loop over tetrahedra

            // update array indices
            idx_phi++;
            idx_psi++;
          }

          // add ghostcell width in x-direction to get to start of next
          // row of SAMRAI data
          idx_phi            += phi_ghostcell_width(0);
          idx_psi            += psi_ghostcell_width(0);

        }

        // add ghostcell width in y-direction times number of cells in
        // x-direction to get to start of next plane of SAMRAI data
        idx_phi            += phi_ghostcell_width(1)
                            * phi_ghostbox_dims(0);
        idx_psi            += psi_ghostcell_width(1)
                            * psi_ghostbox_dims(0);

      } // end loop over grid

      idx_phi            += phi_ghostcell_width(2)
                          * phi_ghostbox_dims(0)
                          * phi_ghostbox_dims(1);
      idx_psi            += psi_ghostcell_width(2)
                          * psi_ghostbox_dims(0)
                          * psi_ghostbox_dims(1);

    } // end loop over Patches
  } // end loop over PatchLevels

  // seek back to beginning of dislocation line segments and
  // write the number of dislocation line segments output
  outfile.seekp( number_segment_pos , ios::beg );
  outfile.write( (char*) &num_dislocation_segments, sizeof(int) );

  // write file position where data for (line_handle)-th 
  // dislocation line starts
  outfile.seekp( sizeof(int) * (2+line_handle) , ios::beg );
  outfile.write( (char*) &start_current_data_pos, sizeof(int) );

  // close outfile
  outfile.close();
}

} // end LSMDD namespace
