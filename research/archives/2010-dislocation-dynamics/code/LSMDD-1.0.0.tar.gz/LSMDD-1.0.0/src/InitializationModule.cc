/*
 * File:        InitializationModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 317 $
 * Modified:    $Date: 2007-07-06 23:22:25 -0400 (Fri, 06 Jul 2007) $
 * Description: Implementation file for the InitializationModule class
 */

#include "InitializationModule.h"

extern "C" {
  #include "lsmdd_initialization_fort.h"
}

// SAMRAI Headers
#include "CellData.h"
#include "CartesianPatchGeometry.h"

// namespaces
using namespace pdat;


namespace LSMDD {

void InitializationModule::initializeCircularDislocationLoopOnPatch(
  Patch<3> &patch,
  Pointer< CartesianGridGeometry<3> > grid_geometry,
  int phi_handle,
  int psi_handle,
  int line_num,
  double *normal, double *center, double radius)
{

  // get patch geometry
  Pointer< CartesianPatchGeometry<3> > patch_geometry =
    patch.getPatchGeometry();
  const double* dX = patch_geometry->getDx();
  const double* X_lower = patch_geometry->getXLower();
  
  // get PatchData for phi and psi
  Pointer< CellData<3,double> > phi_data = patch.getPatchData(phi_handle);
  Pointer< CellData<3,double> > psi_data = patch.getPatchData(psi_handle);

  // get index space information
  Box<3> phi_ghostbox = phi_data->getGhostBox();
  const IntVector<3> phi_ghostbox_lower = phi_ghostbox.lower();
  const IntVector<3> phi_ghostbox_upper = phi_ghostbox.upper();

  Box<3> psi_ghostbox = psi_data->getGhostBox();
  const IntVector<3> psi_ghostbox_lower = psi_ghostbox.lower();
  const IntVector<3> psi_ghostbox_upper = psi_ghostbox.upper();

  Box<3> fillbox = phi_data->getBox();
  const IntVector<3> fillbox_lower = fillbox.lower();
  const IntVector<3> fillbox_upper = fillbox.upper();


  // get pointers to data
  double *phi = phi_data->getPointer(line_num);
  double *psi = psi_data->getPointer(line_num);

  INITIALIZE_CIRCULAR_DISLOCATION_LOOP(
    phi,
    &phi_ghostbox_lower[0],
    &phi_ghostbox_upper[0],
    &phi_ghostbox_lower[1],
    &phi_ghostbox_upper[1],
    &phi_ghostbox_lower[2],
    &phi_ghostbox_upper[2],
    psi,
    &psi_ghostbox_lower[0],
    &psi_ghostbox_upper[0],
    &psi_ghostbox_lower[1],
    &psi_ghostbox_upper[1],
    &psi_ghostbox_lower[2],
    &psi_ghostbox_upper[2],
    &fillbox_lower[0],
    &fillbox_upper[0],
    &fillbox_lower[1],
    &fillbox_upper[1],
    &fillbox_lower[2],
    &fillbox_upper[2],
    normal, center, &radius,
    X_lower, dX);

}


void InitializationModule::initializeStraightDislocationLineOnPatch(
  Patch<3> &patch,
  Pointer< CartesianGridGeometry<3> > grid_geometry,
  int phi_handle,
  int psi_handle,
  int line_num,
  double *xi, double *pt)
{
  // get domain dimensions
  const double* domain_X_upper = grid_geometry->getXUpper();
  const double* domain_X_lower = grid_geometry->getXLower();
  double domain_dimensions[3]; 
  domain_dimensions[0] = domain_X_upper[0] - domain_X_lower[0];
  domain_dimensions[1] = domain_X_upper[1] - domain_X_lower[1];
  domain_dimensions[2] = domain_X_upper[2] - domain_X_lower[2];

  // get patch geometry
  Pointer< CartesianPatchGeometry<3> > patch_geometry =
    patch.getPatchGeometry();
  const double* dX = patch_geometry->getDx();
  const double* X_lower = patch_geometry->getXLower();
  
  // get PatchData for phi and psi
  Pointer< CellData<3,double> > phi_data = patch.getPatchData(phi_handle);
  Pointer< CellData<3,double> > psi_data = patch.getPatchData(psi_handle);

  // get index space information
  Box<3> phi_ghostbox = phi_data->getGhostBox();
  const IntVector<3> phi_ghostbox_lower = phi_ghostbox.lower();
  const IntVector<3> phi_ghostbox_upper = phi_ghostbox.upper();

  Box<3> psi_ghostbox = psi_data->getGhostBox();
  const IntVector<3> psi_ghostbox_lower = psi_ghostbox.lower();
  const IntVector<3> psi_ghostbox_upper = psi_ghostbox.upper();

  Box<3> fillbox = phi_data->getBox();
  const IntVector<3> fillbox_lower = fillbox.lower();
  const IntVector<3> fillbox_upper = fillbox.upper();


  // get pointers to data
  double *phi = phi_data->getPointer(line_num);
  double *psi = psi_data->getPointer(line_num);

  INITIALIZE_STRAIGHT_DISLOCATION_LINE(
    phi,
    &phi_ghostbox_lower[0],
    &phi_ghostbox_upper[0],
    &phi_ghostbox_lower[1],
    &phi_ghostbox_upper[1],
    &phi_ghostbox_lower[2],
    &phi_ghostbox_upper[2],
    psi,
    &psi_ghostbox_lower[0],
    &psi_ghostbox_upper[0],
    &psi_ghostbox_lower[1],
    &psi_ghostbox_upper[1],
    &psi_ghostbox_lower[2],
    &psi_ghostbox_upper[2],
    &fillbox_lower[0],
    &fillbox_upper[0],
    &fillbox_lower[1],
    &fillbox_upper[1],
    &fillbox_lower[2],
    &fillbox_upper[2],
    xi, pt,
    X_lower, 
    domain_dimensions,
    dX);

}


void InitializationModule::initializeDislocationArrayOnPatch(
  Patch<3> &patch,
  Pointer< CartesianGridGeometry<3> > grid_geometry,
  int phi_handle,
  int psi_handle,
  int line_num,
  double *xi, double *pt1, double *pt2)
{
  // get domain dimensions
  const double* domain_X_upper = grid_geometry->getXUpper();
  const double* domain_X_lower = grid_geometry->getXLower();
  double domain_dimensions[3]; 
  domain_dimensions[0] = domain_X_upper[0] - domain_X_lower[0];
  domain_dimensions[1] = domain_X_upper[1] - domain_X_lower[1];
  domain_dimensions[2] = domain_X_upper[2] - domain_X_lower[2];

  // get patch geometry
  Pointer< CartesianPatchGeometry<3> > patch_geometry =
    patch.getPatchGeometry();
  const double* dX = patch_geometry->getDx();
  const double* X_lower = patch_geometry->getXLower();
  
  // get PatchData for phi and psi
  Pointer< CellData<3,double> > phi_data = patch.getPatchData(phi_handle);
  Pointer< CellData<3,double> > psi_data = patch.getPatchData(psi_handle);

  // get index space information
  Box<3> phi_ghostbox = phi_data->getGhostBox();
  const IntVector<3> phi_ghostbox_lower = phi_ghostbox.lower();
  const IntVector<3> phi_ghostbox_upper = phi_ghostbox.upper();

  Box<3> psi_ghostbox = psi_data->getGhostBox();
  const IntVector<3> psi_ghostbox_lower = psi_ghostbox.lower();
  const IntVector<3> psi_ghostbox_upper = psi_ghostbox.upper();

  Box<3> fillbox = phi_data->getBox();
  const IntVector<3> fillbox_lower = fillbox.lower();
  const IntVector<3> fillbox_upper = fillbox.upper();


  // get pointers to data
  double *phi = phi_data->getPointer(line_num);
  double *psi = psi_data->getPointer(line_num);

  INITIALIZE_DISLOCATION_ARRAY(
    phi,
    &phi_ghostbox_lower[0],
    &phi_ghostbox_upper[0],
    &phi_ghostbox_lower[1],
    &phi_ghostbox_upper[1],
    &phi_ghostbox_lower[2],
    &phi_ghostbox_upper[2],
    psi, 
    &psi_ghostbox_lower[0],
    &psi_ghostbox_upper[0],
    &psi_ghostbox_lower[1],
    &psi_ghostbox_upper[1],
    &psi_ghostbox_lower[2],
    &psi_ghostbox_upper[2],
    &fillbox_lower[0],
    &fillbox_upper[0],
    &fillbox_lower[1],
    &fillbox_upper[1],
    &fillbox_lower[2],
    &fillbox_upper[2],
    xi, pt1, pt2,
    X_lower, 
    domain_dimensions,
    dX);

}

} // end LSMDD namespace
