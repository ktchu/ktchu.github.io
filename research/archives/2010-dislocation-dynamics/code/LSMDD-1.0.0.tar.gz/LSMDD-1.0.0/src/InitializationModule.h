/*
 * File:        InitializationModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 318 $
 * Modified:    $Date: 2007-07-19 14:13:46 -0400 (Thu, 19 Jul 2007) $
 * Description: Header file for the InitializationModule class
 */

/*! \file InitializationModule.h */

#ifndef included_InitializationModule_h
#define included_InitializationModule_h

/*! \class LSMDD::InitializationModule
 *
 * \brief
 * The InitializationModule provides a collection of static methods 
 * that can be used to initialize the level set functions for common
 * dislocation line configurations.
 * 
 */


// SAMRAI Headers
#include "SAMRAI_config.h"
#include "Patch.h"
#include "CartesianGridGeometry.h"
#include "tbox/Pointer.h"

// LSMDD Headers
#include "LSMDD_config.h"

// namespaces
using namespace SAMRAI;
using namespace geom;
using namespace hier;
using namespace tbox;


/******************************************************************
 *
 * InitializationModule Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class InitializationModule
{
public:

  /*!
   * initializeCircularDislocationLoopOnPatch() initializes phi and
   * psi for a circular dislocation loop with the specified position, 
   * orientation, and radius.
   *
   * Arguments:
   *  - patch (in/out):      Patch on which to initialize
   *                         level set functions
   *  - geometry (in):       grid geometry for simulation
   *  - phi_handle (in):     PatchData handle for phi data
   *  - psi_handle (in):     PatchData handle for psi data
   *  - line_num (in):       line number of dislocation line to initialize
   *  - normal (in):         coordinates of the normal to the plane
   *                         containing the dislocation loop
   *  - center (in):         coordinates of center of dislocation loop
   *  - radius (in):         radius of circular dislocation loop
   *
   * Return value:           none
   *
   * NOTES:
   *  - It is recommended that signed linear extrapolation boundary
   *    conditions are used for this dislocation configuration.
   *  - The direction of the loop is such that it satisfies the right-hand 
   *    rule with respect to the specified normal vector.
   *
   */
  static void initializeCircularDislocationLoopOnPatch(
    Patch<3> &patch,
    Pointer< CartesianGridGeometry<3> > geometry,
    int phi_handle, 
    int psi_handle, 
    int line_num,
    double *normal, double *center, double radius);

  /*!
   * initializeStraightDislocationLineOnPatch() initializes phi and psi 
   * for a straight dislocation line with the specified direction
   * and passing through the specified point.
   *
   * This function only supports dislocation line directions along one
   * of the three coordinate axes.  It may be used for other line
   * directions, but there is no guarantee that it will lead to the
   * desired results for arbitrary line directions.  In particular,
   * the boundary conditions may be difficult to prescribe.
   *
   * Arguments:
   *  - patch (in/out):   Patch on which to initialize
   *                      level set functions
   *  - geometry (in):    grid geometry for simulation
   *  - phi_handle (in):  PatchData handle for phi data
   *  - psi_handle (in):  PatchData handle for psi data
   *  - line_num (in):    line number of dislocation line to initialize
   *  - xi (in):          direction of dislocation line
   *  - pt (in):          coordinates of point that lies on the
   *                      dislocation line
   *
   * Return value:        none
   *
   * NOTES:
   *  - Boundary conditions should be set as follows for a dislocation line
   *    that is parallel to the x-axis:
   *    - phi x: periodic
   *    - phi y: periodic
   *    - phi z: anti-periodic
   *    - psi x: periodic
   *    - psi y: anti-periodic
   *    - psi z: periodic
   *    
   *    Boundary conditions for dislocation lines oriented along other
   *    axes are just cyclical shifts of the above.
   *
   */
  static void initializeStraightDislocationLineOnPatch(
    Patch<3> &patch,
    Pointer< CartesianGridGeometry<3> > geometry,
    int phi_handle,
    int psi_handle, 
    int line_num,
    double *xi, double *pt);

  /*!
   * initializeDislocationArrayOnPatch() initializes phi and psi for 
   * a periodic array of straight dislocations with the specified 
   * direction.  The distance/spacing between adjacent dislocation lines 
   * is set by specifying points on two immediately adjacent dislocation 
   * lines.
   *
   * This function only supports dislocation arrays that lie in one of 
   * the three coordinate planes (i.e. xy, yz, xz).  It may be used for 
   * orientations of the dislocation array, but there is no guarantee 
   * that it will lead to the desired results for arbitrarily oriented
   * dislocation arrays.  In particular, the boundary conditions may 
   * be difficult to prescribe.
   *
   * Arguments:
   *  - patch (in/out):      Patch on which to initialize
   *                         level set functions
   *  - geometry (in):       grid geometry for simulation
   *  - phi_handle (in):     PatchData handle for phi data
   *  - psi_handle (in):     PatchData handle for psi data
   *  - line_num (in):       line number of dislocation line to initialize
   *  - xi (in):             direction of dislocation lines
   *  - pt1 (in):            coordinates of first point that
   *                         dislocation array passes through
   *  - pt2 (in):            coordinates of second point that
   *                         dislocation array passes through
   *
   * Return value:           none
   *
   *
   * NOTES:
   *  - It is the users responsibility to ensure that placing
   *    dislocation lines passing through pt1 and pt2 leads to a
   *    dislocation array that is periodic with respect to the
   *    simulation box.
   *
   * - Boundary conditions should be set as follows.  Let N denote the
   *   direction perpendicular to the plane of the dislocation array.
   *   - if the line direction is parallel to one of the coordinate axes:
   *     - phi:
   *       - periodic in the direction of xi
   *       - anti-periodic in the direction of N
   *       - periodic in the direction of (xi cross N) if there are an
   *         even number of dislocation lines in the simulation cell;
   *         anti-periodic if there are an odd number.
   *     - psi:
   *       - periodic in the direction of xi and N
   *       - periodic in the direction of (xi cross N) if there are an
   *         even number of dislocation lines in the simulation cell;
   *         anti-periodic if there are an odd number.
   *   - if the line direction is not parallel to any of the coordinate axes:
   *     - phi:
   *       - anti-periodic in the direction of N
   *       - anti-periodic in both directions that lie in the plane of the
   *         dislocation array if there are an even number of dislocation
   *         lines in the simulation cell; periodic if there are an odd 
   *         number.
   *     - psi:
   *       - periodic in the direction of N
   *       - anti-periodic in both directions that lie in the plane of the
   *         dislocation array if there are an even number of dislocation
   *         lines in the simulation cell; periodic if there are an odd
   *         number.
   *
   */
  static void initializeDislocationArrayOnPatch(
    Patch<3> &patch,
    Pointer< CartesianGridGeometry<3> > geometry,
    int phi_handle, 
    int psi_handle,
    int line_num,
    double *xi, double *pt1, double *pt2);


private:

  /*
   * Private default constructor to prevent use.
   *
   * Arguments:  none
   *
   */
  InitializationModule(){}

  /*
   * Private copy constructor to prevent use.
   *
   * Arguments:
   *  - rhs (in):  InitializationModule object to copy
   *
   */
  InitializationModule(const InitializationModule& rhs){}

  /*
   * Private assignment operator to prevent use.
   *
   * Arguments:
   *  - rhs (in):   InitializationModule object to copy
   *
   * Return value:  *this
   *
   */
  const InitializationModule& operator=(
    const InitializationModule& rhs){ return *this; }

};

} // end LSMDD namespace


#endif
