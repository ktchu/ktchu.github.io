/*
 * File:        LSMDD_Parameters.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 379 $
 * Modified:    $Date: 2007-08-07 10:02:34 -0400 (Tue, 07 Aug 2007) $
 * Description: Header file for the LSMDD_Parameters class
 */

#ifndef included_LSMDD_Parameters_h
#define included_LSMDD_Parameters_h

/*! \class LSMDD::LSMDD_Parameters
 *
 * \brief
 * The LSMDD_Parameters holds physical and simulation parameters that 
 * are used by several classes within the Level Set Method Dislocation 
 * Dynamics (LSMDD) library. 
 *
 *
 * <h3> User-specified parameters (input database field) </h3>
 *
 * When using the LSMDD_Parameters, it is possible to modify the
 * data stored in the module through an input file.  The input data 
 * parameters available for/required by the user are described below. 
 * In the input file, the parameters for the components of the 
 * The input file should have the following form:
 *
 * <pre>
 * LSMDD_Parameters {
 *
 *   ... input parameters for LSMDD_Parameters ...
 *
 * } // end input database for LSMDD_Parameters
 * </pre>
 * 
 * <h4> LSMDD_Parameters Input Database Parameters </h4>
 * 
 * - shear_modulus                  = shear modulus of material
 * - poisson_ratio                  = poisson ratio of material
 * - glide_mobility                 = glide mobility for dislocations
 * - climb_mobility                 = climb mobility for dislocations
 * - core_radius                    = radius for dislocation core
 *                                    in units of length
 * - min_dislocation_segment_length = minimum length of dislocation 
 *                                    line segment for considering the
 *                                    two endpoints of the segment
 *                                    segment as numerically distinct
 *                                    (default = 1.0e-8)
 * - max_angle_for_pure_screw       = maximum angle between the Burgers
 *                                    vector and tangent vector for 
 *                                    considering a dislocation line 
 *                                    segment to be pure screw
 *                                    (default = 0.1)
 * - debug_on                       = flag indicating whether the
 *                                    simulation should be run in
 *                                    debug mode
 *                                    (default = FALSE)
 *
 * <h4> Sample Input File </h4>
 * 
 *  <pre>
 *  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *  LSMDD_Parameters { 
 *
 *    // elasticity parameters
 *    shear_modulus  = 1.0
 *    poisson_ratio  = 0.33
 *
 *    // dislocation parameters
 *    glide_mobility = 1.0
 *    climb_mobility = 0.1
 *    core_radius    = 3
 *
 *    // numerical parameters
 *    min_dislocation_segment_length = 1.0e-6
 *    max_angle_for_pure_screw       = 0.1
 * 
 *    // debug parameters
 *    debug_on = TRUE
 *
 *  } // end of DislocationDynanmicsModule database
 *
 *  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 *  </pre>
 *
 *
 * <h3> NOTES </h3>
 *  - The core_radius MUST be larger than 3 times the grid spacing  
 *    (i.e. max(dx,dy,dz)).  Otherwise, an unrecoverable error will
 *    be thrown.
 *
 */


// System Headers
#include <float.h>
#include <string>
#include <vector>

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "tbox/Database.h"
#include "tbox/Pointer.h"

// LSMDD Headers
#include "LSMDD_config.h"
#include "BurgersVector.h"

// namespaces
using namespace std;
using namespace SAMRAI;
using namespace tbox;


/******************************************************************
 *
 * LSMDD_Parameters Class Definition
 *
 ******************************************************************/

namespace LSMDD {

class LSMDD_Parameters
{
public:

  //! @{
  /*!
   ****************************************************************
   *
   * @name Constructor and destructor 
   *
   ****************************************************************/
 
  /*!
   * The default constructor initializes the class with default 
   * (physically meaningless) parameters.
   * 
   * Arguments:  none
   * 
   */
  LSMDD_Parameters() {
    d_shear_modulus  = 0.0;
    d_poisson_ratio  = 0.0;
    d_glide_mobility = 0.0;
    d_climb_mobility = 0.0;
    d_min_dislocation_segment_length = 0.0;
    d_max_angle_for_pure_screw = 0.0;
    d_lsmdd_debug_on = false;
  }

  /*!
   * The constructor initializes the class from the specified
   * input database.
   * 
   * Arguments:     
   *  - input_db (in):  input database containing
   *                    user-defined parameters for
   *                    the LSMDD_Parameters
   * 
   */
  LSMDD_Parameters(Pointer<Database> input_db);

  /*!
   * The destructor does nothing.
   */
  virtual inline ~LSMDD_Parameters(){}

  /*!
   * The copy constructor sets the new LSMDD_Parameters
   * equal to the specified LSMDD_Parameters object.
   *
   * Arguments:
   *  - rhs (in):   LSMDD_Parameters object to be copied
   *
   */
  LSMDD_Parameters( const LSMDD_Parameters& rhs ) {
    d_shear_modulus  = rhs.d_shear_modulus;
    d_poisson_ratio  = rhs.d_poisson_ratio;
    d_glide_mobility = rhs.d_glide_mobility;
    d_climb_mobility = rhs.d_climb_mobility;
    d_min_dislocation_segment_length = rhs.d_min_dislocation_segment_length;
    d_max_angle_for_pure_screw = rhs.d_max_angle_for_pure_screw; 
    d_lsmdd_debug_on = rhs.d_lsmdd_debug_on;
  }

  //! @}

  //! @{
  /*!
   ********************************************************************
   *
   * @name Method for initializing parameters from an Database
   *
   ********************************************************************/

  /*!
   * initializeParametersFromDatabase() sets the dislocation dynamics
   * parameters from the specified database.
   *
   * Arguments:     
   * - database (in):  pointer to Database containing parameters
   *
   * Return value:     none
   *
   */
  virtual void initializeParametersFromDatabase(Pointer<Database>);

  //! @}


  //! @{
  /*!
   ********************************************************************
   *
   * @name Accessor methods for material parameters
   *
   ********************************************************************/

  /*!
   * setShearModulus() sets the shear modulus for the material.
   *
   * Arguments:     
   * - shear_modulus (in):  shear modulus
   *
   * Return value:          none
   *
   */
  virtual inline void setShearModulus(double shear_modulus) {
    d_shear_modulus = shear_modulus;
  }

  /*!
   * getShearModulus() returns the shear modulus for the material.
   *
   * Arguments:     none
   *
   * Return value:  shear modulus
   *
   */
  virtual inline double getShearModulus() const {
    return d_shear_modulus;
  }

  /*!
   * setPoissonRatio() sets the Poisson ratio for the material.
   *
   * Arguments:     
   * - poisson_ratio (in):  Poisson ratio
   *
   * Return value:          none
   *
   */
  virtual inline void setPoissonRatio(double poisson_ratio) {
    d_poisson_ratio = poisson_ratio;
  }

  /*!
   * getPoissonRatio() returns the Poisson ratio for the material.
   *
   * Arguments:     none
   *
   * Return value:  Poisson ratio
   *
   */
  virtual inline double getPoissonRatio() const {
    return d_poisson_ratio;
  }

  //! @}


  //! @{
  /*!
   ********************************************************************
   *
   * @name Accessor methods for dislocation parameters
   *
   ********************************************************************/

  /*!
   * setGlideMobility() sets the glide mobility for dislocations.
   *
   * Arguments:     
   * - glide_mobility (in):  glide mobility
   *
   * Return value:           none
   *
   */
  virtual inline void setGlideMobility(double glide_mobility) {
    d_glide_mobility = glide_mobility;
  }

  /*!
   * getGlideMobility() returns the glide mobility for dislocations.
   *
   * Arguments:     none
   *
   * Return value:  glide mobility
   *
   */
  virtual inline double getGlideMobility() const {
    return d_glide_mobility;
  }

  /*!
   * setClimbMobility() sets the climb mobility for dislocations.
   *
   * Arguments:     
   * - climb_mobility (in):  climb mobility
   *
   * Return value:          none
   *
   */
  virtual inline void setClimbMobility(double climb_mobility) {
    d_climb_mobility = climb_mobility;
  }

  /*!
   * getClimbMobility() returns the climb mobility for dislocations.
   *
   * Arguments:     none
   *
   * Return value:  climb mobility
   *
   */
  virtual inline double getClimbMobility() const {
    return d_climb_mobility;
  }

  /*!
   * setCoreRadius() sets the core radius for dislocations.
   *
   * Arguments:     
   * - core_radius (in):  core radius
   *
   * Return value:        none
   *
   */
  virtual inline void setCoreRadius(double core_radius) {
    d_core_radius = core_radius;
  }

  /*!
   * getCoreRadius() returns the core radius for dislocations.
   *
   * Arguments:     none
   *
   * Return value:  core radius
   *
   */
  virtual inline double getCoreRadius() const {
    return d_core_radius;
  }

  //! @}


  //! @{
  /*!
   ********************************************************************
   *
   * @name Accessor methods for simulation parameters
   *
   ********************************************************************/

  /*!
   * activateDebugMode() activates debug mode.
   *
   * Arguments:     none
   *
   * Return value:  none
   *
   */
  virtual inline void activateDebugMode() {
    d_lsmdd_debug_on = true;
  }

  /*!
   * deactivateDebugMode() deactivates debug mode.
   *
   * Arguments:     none
   *
   * Return value:  none
   *
   */
  virtual inline void deactivateDebugMode() {
    d_lsmdd_debug_on = false;
  }

  /*!
   * debugOn() returns true if debugging is activated; 
   * returns false otherwise.
   *
   * Arguments:     none
   *
   * Return value:  debug mode
   *
   */
  virtual inline bool debugOn() const {
    return d_lsmdd_debug_on;
  }

  /*!
   * setMinDislocationSegmentLength() sets the minimum dislocation segment
   * length in order to consider the two end points of the segment to be
   * numerically distinct.
   *
   * Arguments:     
   * - min_dislocation_segment_length (in):  minimum dislocation segement 
   *                                         length
   *
   * Return value:                           none
   *
   */
  virtual inline void setMinDislocationSegmentLength(
    double min_dislocation_segment_length) {
      d_min_dislocation_segment_length = min_dislocation_segment_length;
  }

  /*!
   * getMinDislocationSegmentLength() returns the minimum dislocation 
   * segment length in order to consider the two end points of the segment 
   * to be numerically distinct.
   *
   * Arguments:     none
   *
   * Return value:  minimum dislocation segment length
   *
   */
  virtual inline double getMinDislocationSegmentLength() const {
    return d_min_dislocation_segment_length;
  }

  /*!
   * setMaxAngleForPureScrew() sets the maximum angle between the 
   * Burgers vector and tangent vector for considering a dislocation 
   * line segment to have pure screw character.
   *
   * Arguments:     
   * - max_angle_for_pure_screw (in):  maximum angle for segment to be 
   *                                   considered pure screw
   *
   * Return value:                     none
   *
   */
  virtual inline void setMaxAngleForPureScrew(
    double max_angle_for_pure_screw) {
      d_max_angle_for_pure_screw = max_angle_for_pure_screw;
  }

  /*!
   * getMaxAngleForPureScrew() returns the maximum angle between the 
   * Burgers vector and tangent vector for considering a dislocation 
   * line segment to have pure screw character.
   *
   * Arguments:     none
   *
   * Return value:  maximum angle for segment to be considered pure screw
   *
   */
  virtual inline double getMaxAngleForPureScrew() const {
    return d_max_angle_for_pure_screw;
  }

  //! @}


  //! @{
  /*!
   ********************************************************************
   *
   * @name Utility Methods
   *
   ********************************************************************/

  /*!
   * printClassData() prints the value of the data members for
   * an instance of the LSMDD_Parameters class.
   * 
   * Arguments:                               
   *  - os (in):    output stream to write object information
   *                                          
   * Return value:  none                      
   *                                          
   */                                         
  virtual void printClassData(ostream& os) const;
 
  //! @}


  //! @{
  /*!
   ********************************************************************
   *
   * @name Operators
   *
   ********************************************************************/

  /*!
   * The assignment operator sets the new LSMDD_Parameters
   * equal to the specified LSMDD_Parameters object.
   *
   * Arguments:
   *  - rhs (in):   LSMDD_Parameters object to be copied
   *
   * Return value:  reference to the new LSMDD_Parameters
   *
   */
  virtual inline const LSMDD_Parameters& operator=( 
    const LSMDD_Parameters& rhs ) {

      // check for assignment to self
      if (this == &rhs) return *this;
      
      d_shear_modulus  = rhs.d_shear_modulus;
      d_poisson_ratio  = rhs.d_poisson_ratio;
      d_glide_mobility = rhs.d_glide_mobility;
      d_climb_mobility = rhs.d_climb_mobility;
      d_lsmdd_debug_on       = rhs.d_lsmdd_debug_on;
      return *this;
  }

  //! @}

protected:

  /*
   * Data Members
   */

  // material parameters
  double d_shear_modulus;
  double d_poisson_ratio;

  // dislocation parameters
  double d_glide_mobility;
  double d_climb_mobility;
  double d_core_radius;       

  // minimum dislocation line segment length for considering the 
  // two endpoints of the segment to be numerically distinct
  double d_min_dislocation_segment_length;

  // maximum angle for considering a dislocation line segment
  // to be mixed vs. pure screw
  double d_max_angle_for_pure_screw;

  // simulation parameters
  bool d_lsmdd_debug_on;

};

} // end LSMDD namespace

#endif

