/*
 * File:        lsmdd_utilities.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Header file for level set method dislocation dynamics 
 *              utility subroutines
 */

#ifndef INCLUDED_LSMDD_UTILITIES
#define INCLUDED_LSMDD_UTILITIES

#ifdef __cplusplus
extern "C" {
#endif

/* Link between C/C++ and Fortran function names
 *
 *      name in                  name in
 *      C/C++ code               Fortran code
 *      ----------               ------------
 */
#define LSMDD_COMPUTE_DISLOCATION_LINE_FIELD                                 \
                                 lsmddcomputedislocationlinefield_
#define LSMDD_COMPUTE_UNIT_TANGENT_VECTOR_FIELD                              \
                                 lsmddcomputeunittangentvectorfield_

void LSMDD_COMPUTE_DISLOCATION_LINE_FIELD( 
  const double *disloc_line_x,
  const double *disloc_line_y,
  const double *disloc_line_z,
  const int *ilo_disloc_line_gb, 
  const int *ihi_disloc_line_gb,
  const int *jlo_disloc_line_gb, 
  const int *jhi_disloc_line_gb,
  const int *klo_disloc_line_gb, 
  const int *khi_disloc_line_gb,
  const double *phi,
  const int *ilo_phi_gb, 
  const int *ihi_phi_gb,
  const int *jlo_phi_gb, 
  const int *jhi_phi_gb,
  const int *klo_phi_gb, 
  const int *khi_phi_gb,
  const double *grad_phi_x,
  const double *grad_phi_y,
  const double *grad_phi_z,
  const int *ilo_grad_phi_gb, 
  const int *ihi_grad_phi_gb,
  const int *jlo_grad_phi_gb, 
  const int *jhi_grad_phi_gb,
  const int *klo_grad_phi_gb, 
  const int *khi_grad_phi_gb,
  const double *psi,
  const int *ilo_psi_gb, 
  const int *ihi_psi_gb,
  const int *jlo_psi_gb, 
  const int *jhi_psi_gb,
  const int *klo_psi_gb, 
  const int *khi_psi_gb,
  const double *grad_psi_x,
  const double *grad_psi_y,
  const double *grad_psi_z,
  const int *ilo_grad_psi_gb, 
  const int *ihi_grad_psi_gb,
  const int *jlo_grad_psi_gb, 
  const int *jhi_grad_psi_gb,
  const int *klo_grad_psi_gb, 
  const int *khi_grad_psi_gb,
  const int *ilo_fb, 
  const int *ihi_fb,
  const int *jlo_fb, 
  const int *jhi_fb,
  const int *klo_fb, 
  const int *khi_fb,
  const double *dX,
  const double *core_radius);

void LSMDD_COMPUTE_UNIT_TANGENT_VECTOR_FIELD( 
  const double *unit_tangent_x,
  const double *unit_tangent_y,
  const double *unit_tangent_z,
  const int *ilo_unit_tangent_gb, 
  const int *ihi_unit_tangent_gb,
  const int *jlo_unit_tangent_gb, 
  const int *jhi_unit_tangent_gb,
  const int *klo_unit_tangent_gb, 
  const int *khi_unit_tangent_gb,
  const double *grad_phi_x,
  const double *grad_phi_y,
  const double *grad_phi_z,
  const int *ilo_grad_phi_gb, 
  const int *ihi_grad_phi_gb,
  const int *jlo_grad_phi_gb, 
  const int *jhi_grad_phi_gb,
  const int *klo_grad_phi_gb, 
  const int *khi_grad_phi_gb,
  const double *grad_psi_x,
  const double *grad_psi_y,
  const double *grad_psi_z,
  const int *ilo_grad_psi_gb, 
  const int *ihi_grad_psi_gb,
  const int *jlo_grad_psi_gb, 
  const int *jhi_grad_psi_gb,
  const int *klo_grad_psi_gb, 
  const int *khi_grad_psi_gb,
  const int *ilo_fb, 
  const int *ihi_fb,
  const int *jlo_fb, 
  const int *jhi_fb,
  const int *klo_fb, 
  const int *khi_fb,
  const double *dX);


#ifdef __cplusplus
}
#endif

#endif
