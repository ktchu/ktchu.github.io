/*
 * File:        lsmdd_elastic_stress_routines.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Header file for level set method dislocation dynamics 
 *              utility subroutines
 */

#ifndef INCLUDED_LSMDD_ELASTIC_STRESS_ROUTINES_H
#define INCLUDED_LSMDD_ELASTIC_STRESS_ROUTINES_H

#ifdef __cplusplus
extern "C" {
#endif

/* Link between C/C++ and Fortran function names
 *
 *      name in                          name in
 *      C/C++ code                       Fortran code
 *      ----------                       ------------
 */
#define LSMDD_ADD_STRESS_COMPONENT       lsmddaddstresscomponent_

void LSMDD_ADD_STRESS_COMPONENT( 
  const double *total_stress,
  const int *ilo_total_stress_gb, 
  const int *ihi_total_stress_gb,
  const int *jlo_total_stress_gb, 
  const int *jhi_total_stress_gb,
  const int *klo_total_stress_gb, 
  const int *khi_total_stress_gb,
  const double *stress_contribution,
  const int *ilo_stress_contribution_gb, 
  const int *ihi_stress_contribution_gb,
  const int *jlo_stress_contribution_gb, 
  const int *jhi_stress_contribution_gb,
  const int *klo_stress_contribution_gb, 
  const int *khi_stress_contribution_gb,
  const int *ilo_fb, 
  const int *ihi_fb,
  const int *jlo_fb, 
  const int *jhi_fb,
  const int *klo_fb, 
  const int *khi_fb);


#ifdef __cplusplus
}
#endif

#endif
