/*
 * File:        lsmdd_initialization.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 1.2 $
 * Modified:    $Date: 2006/05/29 15:06:01 $
 * Description: Header file for routines to initialize level set functions
 *              for common dislocation configurations
 */

#ifndef INCLUDED_LSMDD_INITIALIZATION
#define INCLUDED_LSMDD_INITIALIZATION

#ifdef __cplusplus
extern "C" {
#endif

/* Link between C/C++ and Fortran function names
 *
 *      name in                              name in
 *      C/C++ code                           Fortran code
 *      ----------                           ------------
 */
#define INITIALIZE_CIRCULAR_DISLOCATION_LOOP initializecirculardislocationloop_
#define INITIALIZE_STRAIGHT_DISLOCATION_LINE initializestraightdislocationline_
#define INITIALIZE_DISLOCATION_ARRAY         initializedislocationarray_


/*!
 * INITIALIZE_CIRCULAR_DISLOCATION_LOOP() initializes phi and psi for 
 * a circular dislocation loop with the specified position, orientation,
 * and radius.
 *
 * Arguments:
 *  - phi (out):     phi data
 *  - psi (out):     psi data
 *  - normal (in):   coordinates of the normal to the plane
 *                   containing the dislocation loop
 *  - center (in):   coordinates of center of dislocation loop
 *  - radius (in):   radius of circular dislocation loop
 *  - *_gb (in):     ghostbox for phi and psi data
 *  - *_fb (in):     fillbox for phi and psi data
 *  - x_lower (in):  physical coordinates of lower corner of box
 *  - dx (in):       grid spacing
 *
 * Return value:     none
 * 
 * NOTES:
 *  - It is recommended that signed linear extrapolation boundary
 *    conditions are used for this initialization.
 *  - The direction of the loop is such that it satisfies the right-hand 
 *    rule with respect to the specified normal vector.
 * 
 */
void INITIALIZE_CIRCULAR_DISLOCATION_LOOP(
  const double* phi,
  const int* ilo_phi_gb,
  const int* ihi_phi_gb,
  const int* jlo_phi_gb,
  const int* jhi_phi_gb,
  const int* klo_phi_gb,
  const int* khi_phi_gb,
  const double* psi,
  const int* ilo_psi_gb,
  const int* ihi_psi_gb,
  const int* jlo_psi_gb,
  const int* jhi_psi_gb,
  const int* klo_psi_gb,
  const int* khi_psi_gb,
  const int* ilo_fb,
  const int* ihi_fb,
  const int* jlo_fb,
  const int* jhi_fb,
  const int* klo_fb,
  const int* khi_fb,
  const double* normal,
  const double* center,
  const double* radius,
  const double* x_lower,
  const double* dx);

/*!
 * INITIALIZE_STRAIGHT_DISLOCATION_LINE() initializes phi and psi
 * for a straight dislocation line with the specified direction
 * and passing through the specified point.
 *
 * This function only supports dislocation line directions along one
 * of the three coordinate axes.  It may be used for other line   
 * directions, but there is no guarantee that it will lead to the   
 * desired results for arbitrary line directions.  In particular,
 * the boundary conditions may difficult to prescribe.
 *
 * Arguments:
 *  - phi (out):          phi data
 *  - psi (out):          psi data
 *  - xi (in):            direction of dislocation line
 *  - pt (in):            coordinates of a point that lies on
                          the dislocation line
 *  - *_gb (in):          ghostbox for phi and psi data
 *  - *_fb (in):          fillbox for phi and psi data
 *  - x_lower (in):       physical coordinates of lower corner of box
 *  - domain_dims (in):   dimensions of physical domain
 *  - dx (in):            grid spacing
 *
 * Return value:          none
 *
 * NOTES:
 *  - Boundary conditions should be set as follows for a dislocation line
 *    that is parallel to the x-axis:
 *    * phi x: periodic
 *    * phi y: periodic   
 *    * phi z: anti-periodic   
 *    * psi x: periodic
 *    * psi y: anti-periodic
 *    * psi z: periodic
 *    
 *    Boundary conditions for dislocation lines oriented along other
 *    axes are just cyclical shifts of the above.
 *    
 */
void INITIALIZE_STRAIGHT_DISLOCATION_LINE(
  const double* phi,
  const int* ilo_phi_gb,
  const int* ihi_phi_gb,
  const int* jlo_phi_gb,
  const int* jhi_phi_gb,
  const int* klo_phi_gb,
  const int* khi_phi_gb,
  const double* psi,
  const int* ilo_psi_gb,
  const int* ihi_psi_gb,
  const int* jlo_psi_gb,
  const int* jhi_psi_gb,
  const int* klo_psi_gb,
  const int* khi_psi_gb,
  const int* ilo_fb,
  const int* ihi_fb,
  const int* jlo_fb,
  const int* jhi_fb,
  const int* klo_fb,
  const int* khi_fb,
  const double* xi,
  const double* pt,
  const double* x_lower,
  const double *domain_dims,
  const double* dx);

/*!
 * INITIALIZE_DISLOCATION_ARRAY() initializes phi and psi for a periodic
 * array of straight dislocations with the specified direction.
 * The distance/period between adjacent dislocation lines is set by
 * specifying points on two immediately adjacent dislocation lines.
 * 
 * This function only supports dislocation arrays that lie in one of
 * the three coordinate planes (i.e. xy, yz, xz).  It may be used for    
 * orientations of the dislocation array, but there is no guarantee    
 * that it will lead to the desired results for arbitrarily oriented    
 * dislocation arrays.  In particular, the boundary conditions may     
 * difficult to prescribe.
 *
 * Arguments:
 *  - phi (out):               phi data
 *  - psi (out):               psi data
 *  - xi (in):                 direction of dislocation lines
 *  - pt1 (in):                coordinates of first point that
 *                             dislocation array passes through
 *  - pt2 (in):                coordinates of second point that
 *                             dislocation array passes through
 *  - *_gb (in):               ghostbox for phi and psi data
 *  - *_fb (in):               fillbox for phi and psi data
 *  - x_lower (in):            physical coordinates of lower corner of
 *                             patch
 *  - domain_dimensions (in):  physical dimensions of domain
 *  - dx (in):                 grid spacing
 *
 * Return value:                none
 *
 *
 * NOTES:
 *  - It is the users responsibility to ensure that placing
 *    dislocation lines passing through pt1 and pt2 leads to a
 *    dislocation array that is periodic with respect to the
 *    simulation box.
 *
 *  - Boundary conditions should be set as follows.  Let N denote the
 *    direction perpendicular to the plane of the dislocation array.
 *    - if the line direction is parallel to one of the coordinate axes:
 *      - phi:
 *        - periodic in the direction of xi
 *        - anti-periodic in the direction of N
 *        - periodic in the direction of (xi cross N) if there are an
 *          even number of dislocation lines in the simulation cell;
 *          anti-periodic otherwise
 *      - psi:
 *        - periodic in the direction of xi and N
 *        - periodic in the direction of (xi cross N) if there are an
 *          even number of dislocation lines in the simulation cell;
 *          anti-periodic otherwise
 *    - if the line direction is not parallel to any of the coordinate axes:
 *      - phi:
 *        - anti-periodic in the direction of N
 *        - anti-periodic in both directions that lie in the plane of the
 *          dislocation array if there are an even number of dislocation
 *          lines in the simulation cell; periodic otherwise.
 *      - psi:
 *        - periodic in the direction of N
 *        - anti-periodic in both directions that lie in the plane of the
 *          dislocation array if there are an even number of dislocation
 *          lines in the simulation cell; periodic otherwise.
 *
 */
void INITIALIZE_DISLOCATION_ARRAY( 
  const double* phi,
  const int* ilo_phi_gb,
  const int* ihi_phi_gb,
  const int* jlo_phi_gb,
  const int* jhi_phi_gb,
  const int* klo_phi_gb,
  const int* khi_phi_gb,
  const double* psi,
  const int* ilo_psi_gb,
  const int* ihi_psi_gb,
  const int* jlo_psi_gb,
  const int* jhi_psi_gb,
  const int* klo_psi_gb,
  const int* khi_psi_gb,
  const int* ilo_fb,
  const int* ihi_fb,
  const int* jlo_fb,
  const int* jhi_fb,
  const int* klo_fb,
  const int* khi_fb,
  const double* xi,
  const double* pt1,
  const double* pt2,
  const double* x_lower,
  const double* domain_dimensions,
  const double* dx);


#ifdef __cplusplus
}
#endif

#endif
