/*
 * File:        BurgersVector.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 379 $
 * Modified:    $Date: 2007-08-07 10:02:34 -0400 (Tue, 07 Aug 2007) $
 * Description: Header file for the BurgersVector class
 */

#ifndef included_BurgersVector_h
#define included_BurgersVector_h


/*! \class LSMDD::BurgersVector
 *
 * \brief
 * The BurgersVector class stores the Burgers vector for a dislocation 
 * line.
 *
 * <h3> NOTES </h3>
 *
 *  - This class only implements the methods required so that it can be 
 *    used in the SAMRAI Array template.  STL was not used because the 
 *    operators required for the vector container template is not
 *    consistent across all compilers yet.
 * 
 */


// LSMDD Headers
#include "LSMDD_config.h"

namespace LSMDD {

class BurgersVector
{
public:

  /*!
   * The default constructor sets all of the components of the Burgers
   * vector to 0.0.
   */
  BurgersVector() {
    d_burgers_vector[0] = 0.0;
    d_burgers_vector[1] = 0.0;
    d_burgers_vector[2] = 0.0;
  }

  /*!
   * The copy constructor sets the new Burgers equal to the specified
   * Burgers vector.
   *
   * Arguments:
   *  - rhs (in):  Burgers vector to be copied
   *
   */
  BurgersVector(const BurgersVector& rhs) {
    d_burgers_vector[0] = rhs.d_burgers_vector[0];
    d_burgers_vector[1] = rhs.d_burgers_vector[1];
    d_burgers_vector[2] = rhs.d_burgers_vector[2];
  }

  /*!
   * The default destructor does nothing.
   */
  virtual ~BurgersVector() {}

  /*!
   * The assignment operator sets the new Burgers equal to the specified
   * Burgers vector.
   *
   * Arguments:
   *  - rhs (in):   Burgers vector to be copied
   *
   * Return value:  reference to the new Burgers vector
   *
   */
  virtual inline const BurgersVector& operator=( const BurgersVector& rhs ) {

    // check for assignment to self
    if (this == &rhs) return *this;

    d_burgers_vector[0] = rhs.d_burgers_vector[0];
    d_burgers_vector[1] = rhs.d_burgers_vector[1];
    d_burgers_vector[2] = rhs.d_burgers_vector[2];
    return *this;
  }

  /*!
   * Element access operator that returns a non-const reference.  
   *
   * Arguments:
   *  - i (in):     component of Burgers vector 
   *
   * Return value:  reference to specified component of Burgers vector
   *
   * NOTES:
   *  - No bounds checking is performed.
   *
   */
  virtual inline double& operator[]( const int i ) {
    return d_burgers_vector[i];
  }

  /*!
   * Element access operator that returns a const reference.  
   *
   * Arguments:
   *  - i (in):     component of Burgers vector 
   *
   * Return value:  reference to specified component of Burgers vector
   *
   * NOTES:
   *  - No bounds checking is performed.
   *
   */
  virtual inline const double& operator[]( const int i ) const {
    return d_burgers_vector[i];
  }

  /*!
   * Array access operator that returns a pointer to a double array
   * containing the Burgers vector.
   *
   * Arguments:     none
   *
   * Return value:  double pointer to Burgers vector data
   *
   */
  virtual inline const double* getPointer() const {
    return d_burgers_vector;
  }


protected:

  /***********************************************************
   *
   * Data Members
   *
   ***********************************************************/
  double d_burgers_vector[3];

};

} // end LSMDD namespace

#endif

