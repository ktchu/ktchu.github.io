=======================================================================

Level Set Method Dislocation Dynamics (LSMDD)
---------------------------------------------

Kevin T. Chu
Dept. of Mechanical and Aerospace Engineering, Princeton University
August 2007

Contributors:  
* Yang Xiang (Dept. of Mathematics, Hong Kong University of Science and
  Technology)
* Li-Tien Cheng (Dept. of Mathematics, University of California at
  San Diego)
* Jerry Quek (Institute for High Performance Computing, A*STAR, Singapore)

=======================================================================

Please see the HTML documentation for LSMDD in doc/lsmdd-dox/html.


=======================================================================

Acknowledgements
----------------

This software library was supported in part by the National Science 
Foundation and the Air Force Office of Scientific Research.


=======================================================================

Thanks for using LSMDD! 

=======================================================================
