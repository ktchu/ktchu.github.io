/*
 * File:        TestPatchModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Header for concrete subclass of UserDefinedPatchStrategy
 *              that computes test dislocation line data for the 
 *              PeriodicDislocationArrayElasticityModule test program
 */

#ifndef included_TestPatchModule_h
#define included_TestPatchModule_h

/*!
 * The TestPatchModule class provides routines for computing test
 * dislocation line data for the PeriodicDislocationArrayElasticityModule 
 * test program.
 */

// System Headers
#include <string>

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "IntVector.h"
#include "Patch.h"
#include "tbox/Database.h"
#include "tbox/Pointer.h"

// SAMRAI RDK Headers
#include "UserDefinedPatchStrategy.h"

// LSM Dislocation Dynamics Headers
#include "LSMDD_config.h"
#include "BurgersVector.h"
#include "PeriodicDislocationArrayElasticStressModule.h"
#include "LSMDD_Parameters.h"

using namespace std;
using namespace SAMRAI;
using namespace hier;
using namespace tbox;
using namespace LSMDD;

class TestPatchModule:
  public UserDefinedPatchStrategy<3>
{
public:

  /*!
   * This constructor sets the object name and dislocation line PatchData
   * handle.
   *
   * Arguments:
   *   input_db (in):                 pointer to database containing user 
   *                                  input
   *   dislocation_line_handle (in):  PatchData handle for dislocation line 
   *                                  data
   *   object_name (in):              string name for object
   *
   * Return value:            none
   *
   */
  TestPatchModule(
    Pointer<Database> input_db,
    const int dislocation_line_handle,
    const string& object_name = "TestPatchModule");

  /*!
   * Empty destructor.
   */
  virtual ~TestPatchModule() {};


  /****************************************************************
   *
   * Accessor Methods for Dislocation Line, Shear Modulus, 
   * and Poisson Ratio
   *
   ****************************************************************/

  /*!
   * getDislocationLineHandle() returns the dislocation line handle
   *
   * Arguments:     none
   *
   * Return value:  dislocation line PatchData handle
   *
   */
  virtual inline int getDislocationLineHandle() const {
    return d_dislocation_line_handle;
  }

  /*!
   * getBurgersVector() returns the Burgers vector for the dislocation
   * line
   *
   * Arguments:     none
   *
   * Return value:  Burgers vector
   *
   */
  virtual inline const BurgersVector& getBurgersVector() const {
    return d_burgers_vector;
  }

  /*!
   * getLSMDDParameters() returns a reference to the
   * LSMDD_Parameters object.
   * 
   *
   * Arguments:     none
   *
   * Return value:  reference to LSMDD_Parameters object
   *
   */
  virtual inline const LSMDD_Parameters& 
    getLSMDDParameters() const 
  {
    return d_lsmdd_parameters;
  }


  /****************************************************************
   *
   * Methods Inherited from UserDefinedPatchStrategy
   *
   ****************************************************************/

  /*!
   * initializeDataOnPatch() initializes the level set
   * function on the patch based on the value of 
   * "initial_level_set" in the input database.
   *
   * Arguments:
   *   patch (in):      patch to initialize data on
   *   data_time (in):  simulation time when data is to be initialized
   *
   * Return value:      none
   *
   */
  virtual void initializeDataOnPatch(Patch<3>& patch,
                                     const double data_time);

  /*!
   * setPhysicalBoundaryConditions() sets the data in ghost cells 
   * corresponding to physical boundary conditions.  
   */
  virtual void setPhysicalBoundaryConditions(
    Patch<3>& patch,
    const double fill_time,
    const int phi_handle,
    const int psi_handle,
    const IntVector<3>& ghost_width_to_fill);

  /*!
   * Print all data members for FluidSolver class.
   */
  void printClassData(ostream& os) const;

protected:
 
  /****************************************************************
   *            
   * Utility Methods
   *
   ****************************************************************/

  void getFromInput(Pointer<Database> db);


  /*
   * The object name is used for error/warning reporting and also as a
   * string label for restart database entries.
   */
  string d_object_name;

  // dislocation line direction (read from input file)
  double d_eta[3];

  // Burgers vector (read from input)
  BurgersVector d_burgers_vector;

  // dislocation line handle 
  int d_dislocation_line_handle;

  // LSMDD_Parameters object
  LSMDD_Parameters d_lsmdd_parameters;

};

#endif
