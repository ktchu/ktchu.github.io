/*
 * File:        TestElasticStressModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: test program for PeriodicDislocationArrayElasticStressModule
 */

/************************************************************************
 *
 * This program tests the PeriodicDislocationArrayElasticStressModule.  
 * Initialization of the dislocation line function is provided through the 
 * TestPatchModule class which wraps a simple fortran routine. 
 *
 ************************************************************************/

// System Headers
#include <vector>

// SAMRAI Headers
#include "SAMRAI_config.h"

// variables and variable management
#include "CellVariable.h"
#include "FaceVariable.h"
#include "VariableDatabase.h"

// geometry and patch hierarchy
#include "PatchHierarchy.h"

// basic SAMRAI classes
#include "tbox/Database.h" 
#include "tbox/InputDatabase.h" 
#include "tbox/MPI.h"
#include "tbox/PIO.h"
#include "tbox/Pointer.h"
#include "tbox/RestartManager.h"
#include "tbox/SAMRAIManager.h"
#include "tbox/Utilities.h"
#include "VisItDataWriter.h"

// external library headers
#include "DataManager.h"

// dislocation dynamics classes
#include "BurgersVector.h" 
#include "PeriodicDislocationArrayElasticStressModule.h" 
#include "TestPatchModule.h" 


// namespaces
using namespace std;
using namespace SAMRAI;
using namespace appu;
using namespace geom;
using namespace hier;
using namespace tbox;


// CONSTANTS
#define DIM   (3)

int main(int argc, char *argv[])
{

  /*
   * Initialize MPI and SAMRAI, enable logging, and process command line.
   */
  tbox::MPI::init(&argc, &argv);
  tbox::MPI::initialize();
  SAMRAIManager::startup();

 
  string input_filename;

  // process command-line arguments
  if (argc != 2) {
    pout << "USAGE:  " << argv[0] << " <input filename> "
         << "\n"
         << "  options:\n"
         << "  none at this time"
         << endl;
    tbox::MPI::abort();
    return (-1);
  } else {
    input_filename = argv[1];
  } 

  /*
   * Create input database and parse all data in input file.  
   */
  Pointer<Database> input_db = 
    DataManager<DIM>::processInputFile(input_filename);

  /*
   * Read in the input from the "Main" section of the input database.  
   */
  Pointer<Database> main_db = input_db->getDatabase("Main");

  /* 
   * The base_name variable is a base name for all name strings in 
   * this program.
   */
   string base_name = "unnamed";
   base_name = main_db->getStringWithDefault("base_name", base_name);

  /*
   * Start logging.
   */
   const string log_file_name = base_name + ".log";
   bool log_all_nodes = false;
   log_all_nodes = main_db->getBoolWithDefault("log_all_nodes", log_all_nodes);
   if (log_all_nodes) {
      PIO::logAllNodes(log_file_name);
   } else {
      PIO::logOnlyNodeZero(log_file_name);
   }

  // log the command-line args
  plog << "input_filename = " << input_filename << endl;

  /*
   * Create DataManager
   */
  DataManager<DIM> *data_manager = new DataManager<DIM>(
    input_db->getDatabase("DataManager"));
  plog << "DataManager:" << endl;
  data_manager->printClassData(plog);

  /*
   * Create and set up TestPatchModule
   */
  int ghostcell_width = 1;
  int depth = 3;
  int dislocation_line_handle = 
    data_manager->createVariable("dislocation_line", ghostcell_width, depth);
  TestPatchModule *patch_module = new TestPatchModule(
    input_db->getDatabase("TestPatchModule"),
    dislocation_line_handle);
  data_manager->registerUserDefinedPatchStrategy(patch_module);

  /*
   * Initialize PatchHierarchy
   */
  data_manager->initializePatchHierarchy();

  /*
   * Create PeriodicDislocationArrayElasticStressModule
   */
  Pointer< PatchHierarchy<DIM> > patch_hierarchy =
    data_manager->getPatchHierarchy();
  PeriodicDislocationArrayElasticStressModule *elastic_stress_module = 
    new PeriodicDislocationArrayElasticStressModule(
      input_db->getDatabase("PeriodicDislocationArrayElasticStressModule"),
      patch_hierarchy);
  elastic_stress_module->printClassData(plog);

  /*
   * Set up VisIt data writer
   */
  bool use_visit = false;
  int visit_number_procs_per_file = 1;
  if (main_db->keyExists("use_visit")) {
    use_visit = main_db->getBool("use_visit");
  }
  if (use_visit) {
    if (main_db->keyExists("visit_number_procs_per_file")) {
      visit_number_procs_per_file =
        main_db->getInteger("visit_number_procs_per_file");
    } 
  }

  // get PatchData handles
  int stress_field_handle = elastic_stress_module->getStressFieldHandle();


  // set up VisIt data writer
  Pointer<VisItDataWriter<DIM> > visit_data_writer = 0;
  if (use_visit) {
    string visit_data_dirname = base_name + ".visit";
    visit_data_writer = new VisItDataWriter<DIM>("TestLSM 3D VisIt Writer",
                                                  visit_data_dirname,
                                                  visit_number_procs_per_file);

    // register stress field for plotting
    visit_data_writer->registerPlotQuantity(
      "dislocation_line_x", "SCALAR", 
      dislocation_line_handle, 0, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "dislocation_line_y", "SCALAR", 
      dislocation_line_handle, 1, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "dislocation_line_z", "SCALAR", 
      dislocation_line_handle, 2, 1.0, "CELL");

    // register stress field for plotting
    visit_data_writer->registerPlotQuantity(
      "sigma_11", "SCALAR", 
      stress_field_handle, 0, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_22", "SCALAR", 
      stress_field_handle, 1, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_33", "SCALAR", 
      stress_field_handle, 2, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_23", "SCALAR", 
      stress_field_handle, 3, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_31", "SCALAR", 
      stress_field_handle, 4, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_12", "SCALAR", 
      stress_field_handle, 5, 1.0, "CELL");
  }  

  /*
   * Test computeStressField() method
   */
  dislocation_line_handle = patch_module->getDislocationLineHandle();
  BurgersVector burgers_vector = patch_module->getBurgersVector();

  int num_stress_calculations = 
    main_db->getIntegerWithDefault("num_stress_calculations",1);


  // zero out stress field
  elastic_stress_module->setStressFieldToZero();

  for (int i = 0; i < num_stress_calculations; i++) {
    elastic_stress_module->addStressFieldForDislocationLine(
      dislocation_line_handle, burgers_vector, 
      patch_module->getLSMDDParameters());
  }

  // write out stress field to VisIt data format
  if ( use_visit ) {
    visit_data_writer->writePlotData(patch_hierarchy, 0, 0.0);
  }


  /*
   * At conclusion of simulation, deallocate objects.
   */
  delete elastic_stress_module;

  SAMRAIManager::shutdown();
  tbox::MPI::finalize();

  return(0);
}
