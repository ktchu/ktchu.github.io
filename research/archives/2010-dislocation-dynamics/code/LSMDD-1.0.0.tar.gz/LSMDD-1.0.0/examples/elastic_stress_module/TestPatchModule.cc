/*
 * File:        TestPatchModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Implementation for concrete subclass of 
 *              UserDefinedPatchStrategy that computes the single 
 *              patch numerical routines for the level set method test problem
 */


#include "TestPatchModule.h"

// System Headers
extern "C" {
  #include <math.h>
}

// SAMRAI Headers
#include "Box.h"
#include "CartesianPatchGeometry.h"
#include "CellData.h"
#include "tbox/Utilities.h"

// headers for level set method numerical kernels
extern "C" {
  #include "elastic_stress_patchmodule_fort.h"
}

// SAMRAI namespaces
using namespace geom; 
using namespace pdat; 


/* Constructor() */
TestPatchModule::TestPatchModule(
  Pointer<Database> input_db,
  const int dislocation_line_handle,
  const string& object_name)
{
#ifdef DEBUG_CHECK_ASSERTIONS
  assert(!input_db.isNull());
  assert(dislocation_line_handle >= 0);
  assert(!object_name.empty());
#endif

  // set object name 
  d_object_name = object_name;

  // set dislocation line handle
  d_dislocation_line_handle = dislocation_line_handle;

  // read in input data
  getFromInput(input_db);

}


void TestPatchModule::initializeDataOnPatch(
  Patch<3>& patch,
  const double data_time)
{

  // initialize dislocation line
  Pointer< CellData<3,double> > dislocation_line_data =
    patch.getPatchData( d_dislocation_line_handle );

  // get geometry
  Pointer< CartesianPatchGeometry<3> > patch_geom 
    = patch.getPatchGeometry();
  const double* dx = patch_geom->getDx();
  const double* x_lower = patch_geom->getXLower();

  // get index space information
  Box<3> dislocation_line_box = dislocation_line_data->getBox();
  Box<3> dislocation_line_ghostbox = dislocation_line_data->getGhostBox();
  const IntVector<3> dislocation_line_box_lower = 
    dislocation_line_box.lower();
  const IntVector<3> dislocation_line_box_upper = 
    dislocation_line_box.upper();
  const IntVector<3> dislocation_line_ghostbox_lower = 
    dislocation_line_ghostbox.lower();
  const IntVector<3> dislocation_line_ghostbox_upper = 
    dislocation_line_ghostbox.upper();

  // get pointers to memory
  double* dislocation_line_x = dislocation_line_data->getPointer(0);
  double* dislocation_line_y = dislocation_line_data->getPointer(1);
  double* dislocation_line_z = dislocation_line_data->getPointer(2);

  INIT_DATA(
    dislocation_line_x,
    dislocation_line_y,
    dislocation_line_z,
    &dislocation_line_ghostbox_lower[0],
    &dislocation_line_ghostbox_upper[0],
    &dislocation_line_ghostbox_lower[1],
    &dislocation_line_ghostbox_upper[1],
    &dislocation_line_ghostbox_lower[2],
    &dislocation_line_ghostbox_upper[2],
    &dislocation_line_box_lower[0],
    &dislocation_line_box_upper[0],
    &dislocation_line_box_lower[1],
    &dislocation_line_box_upper[1],
    &dislocation_line_box_lower[2],
    &dislocation_line_box_upper[2],
    d_eta,
    x_lower,
    dx);

}

void TestPatchModule::setPhysicalBoundaryConditions(
    Patch<3>& patch,
    const double fill_time,
    const int phi_handle,
    const int psi_handle,
    const IntVector<3>& ghost_width_to_fill)
{
  // KTC - fill me in
}


void TestPatchModule::printClassData(ostream &os) const
{
  os << "\nTestPatchModule::printClassData..." << endl;
  os << "TestPatchModule: this = " << (TestPatchModule*)this << endl;
  os << "d_object_name = " << d_object_name << endl;
  os << "dislocation_line_handle = " 
     << d_dislocation_line_handle << endl;
  os << "Burgers vector = " << "(" << d_burgers_vector[0] 
                            << "," << d_burgers_vector[1] 
                            << "," << d_burgers_vector[2] 
                            << ")" << endl;
  os << "d_eta = " << "(" << d_eta[0] 
                   << "," << d_eta[1] 
                   << "," << d_eta[2] << ")" << endl;

  os << endl;
}

void TestPatchModule::getFromInput(
  Pointer<Database> db)
{
#ifdef DEBUG_CHECK_ASSERTIONS
  assert(!db.isNull());
#endif

  // get dislocation line direction (eta) 
  if (db->keyExists("eta")) {
    db->getDoubleArray("eta", d_eta, 3);
  } else {
    d_eta[0] = 1.0;
    d_eta[1] = 0.0;
    d_eta[2] = 0.0;
  }

  // normalize eta
  double norm_eta = 
    sqrt(d_eta[0]*d_eta[0]+d_eta[1]*d_eta[1]+d_eta[2]*d_eta[2]);
  if (norm_eta < 1.e-10) {
    TBOX_ERROR(  d_object_name
              << "::getFromInput()"
              << ": dislocation direction too close to zero..."
              << endl );
  }
  d_eta[0] /= norm_eta;
  d_eta[1] /= norm_eta;
  d_eta[2] /= norm_eta;

  // get burgers vector
  double burgers_vector[3];
  if (db->keyExists("burgers_vector")) {
    db->getDoubleArray("burgers_vector", burgers_vector, 3);
  } else {
    burgers_vector[0] = 1.0;
    burgers_vector[1] = 0.0;
    burgers_vector[2] = 0.0;
  }
  for (int i = 0; i < 3; i++) {
    d_burgers_vector[i] = burgers_vector[i];
  }

  // get shear modulus and poisson ratio
  double shear_modulus = db->getDoubleWithDefault("shear_modulus", 1.0);
  double poisson_ratio = db->getDoubleWithDefault("poisson_ratio", 1.0/3.0);
  d_lsmdd_parameters.setShearModulus(shear_modulus);
  d_lsmdd_parameters.setPoissonRatio(poisson_ratio);
}
