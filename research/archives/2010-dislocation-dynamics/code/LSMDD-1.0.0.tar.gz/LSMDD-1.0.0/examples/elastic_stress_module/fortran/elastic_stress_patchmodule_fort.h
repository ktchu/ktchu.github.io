/*
 * File:        test_patchmodule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Header file for patch module routines for ElasticityModule
 *              test program
 */

#ifndef included_patchmodule_h
#define included_patchmodule_h

/* Link between C/C++ and Fortran function names
 *
 *      name in               name in
 *      C/C++ code            Fortran code
 *      ----------            ------------
 */
#define INIT_DATA             initdata_

void INIT_DATA(
  const double* dislocation_line_x,
  const double* dislocation_line_y,
  const double* dislocation_line_z,
  const int* ilo_gb,
  const int* ihi_gb,
  const int* jlo_gb,
  const int* jhi_gb,
  const int* klo_gb,
  const int* khi_gb,
  const int* ilo_fb,
  const int* ihi_fb,
  const int* jlo_fb,
  const int* jhi_fb,
  const int* klo_fb,
  const int* khi_fb,
  const double* eta,
  const double* x_lower,
  const double* dx);

#endif
