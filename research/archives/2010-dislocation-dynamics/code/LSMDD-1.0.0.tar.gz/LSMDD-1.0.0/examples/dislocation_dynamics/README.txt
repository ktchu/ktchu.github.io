
Choice of Tangent Vector in Example Programs
--------------------------------------------

While there are many ways to choose the tangent vector that should be 
used at various stages of the dislocation dynamics algorithm, we have
chosen to use the following because they produce relatively stable
results.  Use of the tangent vector associated with the explicit "exact"
dislocation line can introduce noise due to numerical errors in the
direction of the "exact" dislocation line segments.


* Computation of dislocation line field:  
  grad(phi) cross grad(psi) with gradients computed using upwinding
  where the upwind direction is switched at every time step

* Computation of Peach-Kohler force:
  grad(phi) cross grad(psi) with gradients computed using central 
  differencing

* Interpolation of force to dislocation line:
  tangent vector computed from "exact" dislocation line

* Decomposition of force into glide and climb components:
  grad(phi) cross grad(psi) with gradients computed using central 
  differencing
