/*
 * File:        ArbitraryDislocationLinesModule.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 378 $
 * Modified:    $Date: 2007-08-07 10:02:13 -0400 (Tue, 07 Aug 2007) $
 * Description: Header for concrete subclass of LSMDD_PhysicsStrategy for 
 *              the arbitrary dislocation lines test problem
 */

#ifndef included_ArbitraryDislocationLinesModule_h
#define included_ArbitraryDislocationLinesModule_h

/*!
 * The ArbitraryDislocationLinesModule class provides the following 
 * functionality:
 *
 * - initializing and setting boundary conditions for the level set 
 *   functions that represent dislocation lines; and
 * - computing forces and velocities on dislocations lines due
 *   to interactions between dislocation lines.
 *
 *
 * <h3> NOTES </h3>
 *
 * - The fortran routines for this class currently only support
 *   initial dislocation line directions along the coordinate axes.
 *
 *
 * <h3> User-specified parameters (input database field) </h3>
 *
 * - max_dt                = maximum time step size
 *                           (default = 0.001)
 * - num_dislocation_lines = number of dislocation lines
 *                           (REQUIRED)
 * - burgers_vector_<i>    = Burgers vector for the i-th dislocation line
 *                           (REQUIRED)
 * - pt_<i>                = arbitrary point on the i-th initial dislocation 
 *                           line
 *                           (REQUIRED)
 * - dir_<i>               = direction of the i-th initial dislocation line
 *                           (REQUIRED)
 * - debug_on              = flag indicating whether debugging information
 *                           should be logged
 *                           (default = FALSE)
 *
 */


// System Headers
#include <string>

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "CartesianGridGeometry.h"
#include "CellData.h"
#include "IntVector.h"
#include "Patch.h"
#include "tbox/Array.h"
#include "tbox/Database.h"
#include "tbox/Pointer.h"

// Dislocation Dynamics Headers
#include "BurgersVector.h"
#include "LSMDD_PhysicsStrategy.h"

// namespaces
using namespace SAMRAI;
using namespace geom;
using namespace hier;
using namespace pdat;
using namespace tbox;
using namespace LSMDD;


class ArbitraryDislocationLinesModule:
  public LSMDD_PhysicsStrategy
{
public:

  /***********************************************************************
   * 
   * Constructor and destructor
   *                                   
   ***********************************************************************/

  /*!
   * The constructor initializes the ArbitraryDislocationLinesModule object 
   * using parameters read in from the specified input database.
   *
   * Arguments:
   *   input_db (in):       pointer to database containing user input
   *   grid_geometry (in):  pointer to CartesianGridGeometry object
   *
   * Return value:          none
   *
   */
  ArbitraryDislocationLinesModule(
    Pointer<Database> input_db,
    Pointer< CartesianGridGeometry<3> > grid_geometry);

  /*!
   * The destructor does nothing.
   */
  virtual ~ArbitraryDislocationLinesModule();


  /***********************************************************************
   * 
   * Methods for accessing dislocation line information
   *                                   
   ***********************************************************************/

  /*!
   * numberOfDislocationLines() returns the number of dislocation lines
   * with different Burgers vectors.
   *
   * Arguments:     none
   *
   * Return value:  number of dislocation lines with different Burgers 
   *                vectors
   *
   */
  virtual int numberOfDislocationLines() const;

  /*!
   * getBurgersVector() returns the Burgers vector of the specified
   * dislocation line.
   *
   * Arguments:     
   *  - dislocation_line_handle (in):  handle of the dislocation line
   *                                   of the requested Burgers vector
   *
   * Return value:                     Burgers vector
   *
   */
  virtual const BurgersVector& getBurgersVector(
    const int dislocation_line_handle) const;

  /*!
   * getBoundaryConditions() sets the boundary conditions for
   * for the specified dislocation line and level set function.
   *
   * Arguments:
   *  - lower_bc (out):                vector of integers specifying the
   *                                   type of boundary conditions to impose
   *                                   on the lower face of the computational
   *                                   domain in each coordinate direction.
   *                                   The i-th entry will be set to contain
   *                                   the type of boundary condition to
   *                                   impose at the lower boundary in the
   *                                   i-th coordinate direction.
   *  - upper_bc (out):                vector of integers specifying the
   *                                   type of boundary conditions to impose
   *                                   on the upper face of the computational
   *                                   domain in each coordinate direction.
   *                                   The i-th entry will be set to contain
   *                                   the type of boundary condition to
   *                                   impose at the upper boundary in the
   *                                   i-th coordinate direction.
   *  - dislocation_line_handle (in):  handle of the dislocation line
   *                                   for which boundary conditions
   *                                   have been requested
   *  - level_set_fcn (in):            level set function (i.e. LSMLIB::PHI
   *                                   or LSMLIB::PSI) for which to get
   *                                   boundary conditions
   *
   * Return value:                     none
   *
   * NOTES:
   *  - The dislocation line handles should lie in the range
   *    {0,..., number of dislocation lines}
   *
   *  - The boundary condition types are as follows:
   *    - NONE:                         0 
   *    - HOMOEGENEOUS_NEUMANN:         1 
   *    - LINEAR_EXTRAPOLATION:         2 
   *    - SIGNED_LINEAR_EXTRAPOLATION:  3 
   *    - ANTI_PERIODIC:                4 
   *
   *    For more information about these boundary conditions, see
   *    the BoundaryConditionModule class in LSMLIB.
   *
   *    By default, no boundary conditions are imposed at any
   *    non-periodic boundary of the computational domain.
   *
   *  - Non-periodic boundary conditions MAY be imposed at
   *    boundaries that are specified to be periodic directions
   *    for the GridGeometry object associated with the
   *    PatchHierarchy set in the constructor.  The non-periodic
   *    boundary conditions will override the periodic boundary
   *    conditions.
   *
   *  - In order to use custom boundary conditions at a particular
   *    boundary location, the boundary condition type for that
   *    boundary location MUST be set to NONE.  Otherwise, the
   *    boundary condition will be overwritten by specified boundary
   *    condition type.
   *
   */
  virtual void getBoundaryConditions(
    IntVector<3>& lower_bc,
    IntVector<3>& upper_bc,
    const int dislocation_line_handle,
    const LEVEL_SET_FCN_TYPE level_set_fcn) const;


  /***********************************************************************
   * 
   * Methods for setting initial and boundary conditions for the level
   * set functions that represent dislocation lines
   *                                   
   ***********************************************************************/

  /*!
   * initializeLevelSetFunctionsOnPatch() sets the initial values of the 
   * level set functions associated with ALL of the dislocation lines.
   *
   * Arguments:
   *  patch (in):             Patch on which to set initial values 
   *                          for level set functions
   *  time (in):              simulation time at which level set 
   *                          functions are initialized
   *  phi_handle (in):        PatchData handle for phi
   *  psi_handle (in):        PatchData handle for psi
   *
   * Return value:            none
   *
   */
  virtual void initializeLevelSetFunctionsOnPatch(
    Patch<3>& patch, 
    const double time,
    const int phi_handle,
    const int psi_handle);


  /***********************************************************************
   *
   * Methods related to auxiliary stress fields
   *
   ***********************************************************************/

  /*!
   * providesAuxiliaryStressField() returns true if the
   * LSMDD_PhysicsStrategy provides an auxiliary stress field.
   *
   * Arguments:     none
   *
   * Return value:  true
   *
   */
  virtual inline bool providesAuxiliaryStressField() const
  {
    return true;
  }

  /*!
   * computeAuxiliaryStressFieldOnPatch() computes the auxiliary 
   * stress field that should be added to the stress field due to 
   * the dislocations.
   *
   * Arguments:
   *  - patch (in):                      Patch on which to compute
   *                                     auxiliary stress field
   *  - auxiliary_stress_handle (out):   PatchData handle for
   *                                     auxiliary stress field
   *  - dislocation_stress_handle (in):  PatchData handle for
   *                                     stress field due to 
   *                                     dislocations
   *  - time (in):                       current simulation time
   *  - lsmdd_params (in):               parameters for dislocation
   *                                     dynamics simulation
   *
   * Return value:                       none
   *
   */
  virtual inline void computeAuxiliaryStressFieldOnPatch(
    Patch<3>& patch,
    const int auxiliary_stress_handle,
    const int dislocation_stress_handle,
    const double time,
    const LSMDD_Parameters& lsmdd_params);


  /***********************************************************************
   * 
   * Methods for computing forces and velocities on dislocation lines
   *
   ***********************************************************************/
 
  /*!
   * computeForceOnDislocationLineOnPatch() computes the force on
   * the specified dislocation line on a single patch.
   *
   * Arguments:
   *  - patch (in):                   Patch on which to compute force
   *                                  field
   *  - force_handle (out):           PatchData handle of the force field
   *  - stress_field_handle (in):     PatchData handle of the stress field
   *  - tangent_vector_handles (in):  PatchData handle of the tangent
   *                                  vector fields
   *  - phi_handle (in):              PatchData handle of the phi field
   *  - psi_handle (in):              PatchData handle of the psi field
   *  - line_handle (in):             handle of the dislocation line for
   *                                  which to compute velocity
   *  - time (in):                    time that force is to be computed
   *  - lsmdd_params (in):            parameters for dislocation
   *                                  dynamics simulation
   *
   * Return value:                    none
   *
   * NOTES:
   *  - This method is NOT responsible for filling the ghostcells
   *    of the force data.  Ghostcells for the force data are filled
   *    using the SAMRAI communication algorithms after the force data
   *    has been computed on all patches.
   *
   *  - It is safe to assume that the ghostcells of the tangent
   *    vector data have been filled.
   *
   *  - The number of ghostcells for the data associated with the
   *    PatchData handles are as follows:
   *    - force_handle:            1
   *    - stress_field_handle:     0
   *    - tangent_vector_handles:  1
   *
   */
  virtual void computeForceOnDislocationLineOnPatch(
    Patch<3>& patch,
    const int force_handle,
    const int stress_field_handle,
    const vector<int>& tangent_vector_handles,
    const int phi_handle,
    const int psi_handle,
    const int line_handle,
    const double time,
    const LSMDD_Parameters& lsmdd_params); 

  /*!
   * computeVelocityForDislocationLineOnPatch() computes the velocity for
   * the specified dislocation line on a single patch.
   *
   * Arguments:
   *  - patch (in):                   Patch on which to compute velocity
   *                                  field
   *  - velocity_handle (out):        PatchData handle for the velocity
   *                                  field
   *  - force_handle (in):            PatchData handle for the force
   *  - tangent_vector_handles (in):  PatchData handle for the tangent
   *                                  vector fields
   *  - distance_handle (in):         PatchData handle for the closest
   *                                  distance from the nearest
   *                                  dislocation line to the center of
   *                                  the grid cell
   *  - phi_handle (in):              PatchData handle for phi
   *  - psi_handle (in):              PatchData handle for psi
   *  - line_handle (in):             handle for the dislocation line
   *                                  for which to compute velocity
   *  - time (in):                    time that velocity is to be
   *                                  computed
   *  - lsmdd_params (in):            parameters for dislocation
   *                                  dynamics simulation
   *
   * Return value:                    none
   *
   * NOTES:
   *  - The number of ghostcells for the data associated with the
   *    PatchData handles are as follows:
   *    - velocity_handle:         1
   *    - force_handle:            1
   *    - tangent_vector_handles:  1
   *    - distance_handle:         1
   *    - phi_handle:            > 1
   *    - psi_handle:            > 1
   *
   *  - The data associated with phi_handle and psi_handle are stored
   *    in the zero-th component, NOT the (line_handle)-th component.
   *
   *  - The velocity and distance data are provided with a ghostcell
   *    width of one so that grid cells on faces, edges, and corners
   *    do NOT need to be treated as special cases when the nearest
   *    point on the dislocation line lies in a cell that includes
   *    the centers of ghostcells.
   *
   *  - The data associated with distance handle is guaranteed to be
   *    initialized to DBL_MAX.
   *
   */
  virtual void computeVelocityForDislocationLineOnPatch(
    Patch<3>& patch,
    const int velocity_handle,
    const int force_handle,
    const vector<int>& tangent_vector_handles,
    const int distance_handle,
    const int phi_handle,
    const int psi_handle,
    const int line_handle,
    const double time,
    const LSMDD_Parameters& lsmdd_params); 


  /***********************************************************************
   *
   * Methods related to time integration
   *
   ***********************************************************************/

  /*!
   * computeStableDtOnPatch() returns maximum time step size specified
   * in the input file.
   *
   * Arguments:
   *  - patch (in):  Patch on which to compute stable dt.
   *
   * Return value:   maximum time step size
   *
   */
  virtual inline double computeStableDtOnPatch(Patch<3>& patch)
  {
    return d_max_dt;
  }



protected:
 
  /****************************************************************
   *            
   * Utility Methods
   *
   ****************************************************************/

  void getFromInput(Pointer<Database> db);


  /****************************************************************
   *            
   * Data Members
   *            
   ****************************************************************/

  // grid geometry (used to determine size of physical domain)
  Pointer< CartesianGridGeometry<3> > d_grid_geometry;

  // number of dislocation lines in calculation
  int d_num_dislocation_lines;

  // pointers to tangent vector data
  Pointer< CellData<3,double> > *d_tangent_vector_data;
  double **d_tangent_vector_x;
  double **d_tangent_vector_y;
  double **d_tangent_vector_z;


  /*
   * Input parameters
   */

  // maximum time step size
  double d_max_dt;

  // burgers vectors
  Array< BurgersVector > d_burgers_vectors;

  // dislocation line parameters
  double *d_pts_x, *d_pts_y, *d_pts_z;
  double *d_dirs_x, *d_dirs_y, *d_dirs_z;

  // external stress field parameters
  double d_external_sigma_11;
  double d_external_sigma_22;
  double d_external_sigma_33;
  double d_external_sigma_23;
  double d_external_sigma_31;
  double d_external_sigma_12;

  // anti-periodic directions
  Array< IntVector<3> > d_lower_bc_phi;
  Array< IntVector<3> > d_upper_bc_phi;
  Array< IntVector<3> > d_lower_bc_psi;
  Array< IntVector<3> > d_upper_bc_psi;

  // debug flag
  bool d_debug_on;

};

#endif
