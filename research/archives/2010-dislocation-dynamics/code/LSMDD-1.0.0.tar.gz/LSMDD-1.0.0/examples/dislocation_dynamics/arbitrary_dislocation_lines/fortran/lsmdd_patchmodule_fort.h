/*
 * File:        lsmdd_patchmodule_fort.h
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: Header file for patch module routines for arbitrary 
 *              dislocation lines test problem
 */

#ifndef included_patchmodule_h
#define included_patchmodule_h

/* Link between C/C++ and Fortran function names
 *
 *      name in                              name in
 *      C/C++ code                           Fortran code
 *      ----------                           ------------
 */
#define INITIALIZE_STRAIGHT_LINE_DISLOCATION initializestraightlinedislocation_

void INITIALIZE_STRAIGHT_LINE_DISLOCATION( 
  const double* phi,
  const int* ilo_phi_gb,
  const int* ihi_phi_gb,
  const int* jlo_phi_gb,
  const int* jhi_phi_gb,
  const int* klo_phi_gb,
  const int* khi_phi_gb,
  const double* psi,
  const int* ilo_psi_gb,
  const int* ihi_psi_gb,
  const int* jlo_psi_gb,
  const int* jhi_psi_gb,
  const int* klo_psi_gb,
  const int* khi_psi_gb,
  const int* ilo_fb,
  const int* ihi_fb,
  const int* jlo_fb,
  const int* jhi_fb,
  const int* klo_fb,
  const int* khi_fb,
  const double* x_lower,
  const double* dx,
  const double* domain_dimensions,
  const double* pt_x,
  const double* pt_y,
  const double* pt_z,
  const double* dir_x,
  const double* dir_y,
  const double* dir_z);

#endif
