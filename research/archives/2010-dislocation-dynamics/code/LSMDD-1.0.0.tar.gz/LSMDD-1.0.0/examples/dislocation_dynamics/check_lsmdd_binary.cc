/*
 * File:         check_lsmdd_binary.cc
 * Copyright:    (c) 2005-2007 Princeton University
 * Author(s):    Kevin T. Chu
 * Revision:     $Revision: 376 $
 * Modified:     $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description:  program to check that a binary LSMDD output file is valid
 */

#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char **argv)
{
  ifstream file;

  if (argc != 2) {
    cerr << "Usage: " << argv[0] << " <lsmdd_output_file>" << endl;
    return -1;
  }

  // open lsmdd output file
  file.open(argv[1], ios::binary | ios::in);

  int version;
  file.read( (char*) &version, sizeof(int) );
  cout << "version = " << version << endl;

  int num_dislocations;
  file.read( (char*) &num_dislocations, sizeof(int) );
  cout << "num_dislocations = " << num_dislocations << endl;

  int file_position;
  int dislocation_number;
  int num_segments;
  for (int k = 0; k < num_dislocations; k++) {

    file.read( (char*) &file_position, sizeof(int) );
    cout << "file_position[" << k << "] = " << file_position << endl;

    int position_save = file.tellg();
    file.seekg( file_position );

    file.read( (char*) &dislocation_number, sizeof(int) );
    cout << "num segments[" << k << "] = " << dislocation_number << endl;
    file.read( (char*) &num_segments, sizeof(int) );
    cout << "num segments[" << k << "] = " << num_segments << endl;

    file.seekg( position_save );

  }

  
  return 0;
}
