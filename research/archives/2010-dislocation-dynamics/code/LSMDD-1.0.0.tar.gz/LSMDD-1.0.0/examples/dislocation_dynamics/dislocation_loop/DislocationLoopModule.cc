/*
 * File:        DislocationLoopModule.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 378 $
 * Modified:    $Date: 2007-08-07 10:02:13 -0400 (Tue, 07 Aug 2007) $
 * Description: Implementation for concrete subclass of LSMDD_PhysicsStrategy 
 *              for dislocation loop test problems
 */


#include "DislocationLoopModule.h"

// System Headers
#include <sstream>

extern "C" {
  #include <float.h>
  #include <math.h>
}

// SAMRAI Headers
#include "Box.h"
#include "CartesianPatchGeometry.h"
#include "CellData.h"
#include "tbox/Utilities.h"

// LSMDD Headers
#include "LSMDD_Types.h"
#include "LSMDD_Utilities.h"
#include "InitializationModule.h"
#include "BasicDislocationPhysicsModule.h"

// SAMRAI namespaces
using namespace geom; 
using namespace pdat; 


// Macros and Constants
#define DEFAULT_MAX_DT       (DBL_MAX)


DislocationLoopModule::DislocationLoopModule(
  Pointer<Database> input_db,
  Pointer< CartesianGridGeometry<3> > grid_geometry)
{
#ifdef DEBUG_CHECK_ASSERTIONS
  assert(!input_db.isNull());
  assert(!grid_geometry.isNull());
#endif

  // read in input data
  d_grid_geometry = grid_geometry;

  // set the number of dislocation lines to 1
  d_num_dislocation_lines = 1;

  // read in input data
  getFromInput(input_db);

  // allocate memory for pointers to tangent vector data
  d_tangent_vector_data = 
    new Pointer< CellData<3,double> >[d_num_dislocation_lines];
  d_tangent_vector_x = new double*[d_num_dislocation_lines];
  d_tangent_vector_y = new double*[d_num_dislocation_lines];
  d_tangent_vector_z = new double*[d_num_dislocation_lines];

}


DislocationLoopModule::~DislocationLoopModule()
{
  // deallocate memory for pointers to tangent vector data
  delete [] d_tangent_vector_data;
  delete [] d_tangent_vector_x;
  delete [] d_tangent_vector_y;
  delete [] d_tangent_vector_z;
}


int DislocationLoopModule::numberOfDislocationLines() const
{
  return d_num_dislocation_lines;
}


const BurgersVector& DislocationLoopModule::getBurgersVector(
  const int dislocation_line_handle) const
{
  if ( (dislocation_line_handle < 0) || 
       (dislocation_line_handle > d_num_dislocation_lines) ) {
     TBOX_ERROR(  "DislocationLoopModule::"
                  << "getBurgersVector(): "
                  << "dislocation_line_handle out of bounds"
                  << endl);
  }

  return d_burgers_vector;
}


void DislocationLoopModule::getBoundaryConditions(
  IntVector<3>& lower_bc,
  IntVector<3>& upper_bc,
  const int dislocation_line_handle,
  const LEVEL_SET_FCN_TYPE level_set_fcn) const
{
  if (level_set_fcn == LSMLIB::PHI) {
    lower_bc = d_lower_bc_phi[dislocation_line_handle];
    upper_bc = d_upper_bc_phi[dislocation_line_handle];
  } else {
    lower_bc = d_lower_bc_psi[dislocation_line_handle];
    upper_bc = d_upper_bc_psi[dislocation_line_handle];
  }
}


void DislocationLoopModule::initializeLevelSetFunctionsOnPatch(
  Patch<3>& patch,
  const double time,
  const int phi_handle,
  const int psi_handle)
{
  double normal[3] = {0.0, 0.0, 1.0};

  InitializationModule::initializeCircularDislocationLoopOnPatch(
    patch, d_grid_geometry,
    phi_handle, psi_handle, 
    0, // only one dislocation line in simulation
    normal, d_center, d_radius);
}


void DislocationLoopModule::computeAuxiliaryStressFieldOnPatch(
  Patch<3>& patch,
  const int auxiliary_stress_handle,
  const int dislocation_stress_handle,
  const double time,
  const LSMDD_Parameters& lsmdd_params)
{
  (void) time;

  Pointer< CellData<3,double> > auxiliary_stress_data =
    patch.getPatchData( auxiliary_stress_handle );

  // initialize external stress field to zero
  auxiliary_stress_data->fillAll(0.0);

  // set sigma
  auxiliary_stress_data->fill(d_external_sigma_11,LSMDD::SIGMA_11);
  auxiliary_stress_data->fill(d_external_sigma_22,LSMDD::SIGMA_22);
  auxiliary_stress_data->fill(d_external_sigma_33,LSMDD::SIGMA_33);
  auxiliary_stress_data->fill(d_external_sigma_23,LSMDD::SIGMA_23);
  auxiliary_stress_data->fill(d_external_sigma_31,LSMDD::SIGMA_31);
  auxiliary_stress_data->fill(d_external_sigma_12,LSMDD::SIGMA_12);
}


void DislocationLoopModule::computeForceOnDislocationLineOnPatch(
  Patch<3>& patch,
  const int force_handle,
  const int stress_field_handle,
  const vector<int>& tangent_vector_handles,
  const int phi_handle,
  const int psi_handle,
  const int line_handle,
  const double time,
  const LSMDD_Parameters& lsmdd_params)
{

  // argument check
  if ( (line_handle < 0) || (line_handle > d_num_dislocation_lines) ) {
     TBOX_ERROR(  "DislocationLoopModule::"
                  << "computeForceOnDislocationLineOnPatch():"
                  << "line_handle out of bounds"
                  << endl);
  }

  // get geometry
  Pointer< CartesianPatchGeometry<3> > patch_geom 
    = patch.getPatchGeometry();
  const double* dX = patch_geom->getDx();
  const double* X_lower = patch_geom->getXLower();

  // get PatchData
  Pointer< CellData<3,double> > force_data =
    patch.getPatchData( force_handle );
  Pointer< CellData<3,double> > stress_field_data =
    patch.getPatchData( stress_field_handle );
  for (int k = 0; k < d_num_dislocation_lines; k++) {
    d_tangent_vector_data[k] = patch.getPatchData( tangent_vector_handles[k] );
  }
  Pointer< CellData<3,double> > phi_data = patch.getPatchData( phi_handle );
  Pointer< CellData<3,double> > psi_data = patch.getPatchData( psi_handle );


  // get index space information
  Box<3> force_ghostbox = force_data->getGhostBox();
  const IntVector<3> force_ghostbox_dims = 
    force_ghostbox.numberCells();
  const IntVector<3> force_ghostcell_width = 
    force_data->getGhostCellWidth();

  Box<3> stress_field_ghostbox = stress_field_data->getGhostBox();
  const IntVector<3> stress_field_ghostbox_dims = 
     stress_field_ghostbox.numberCells();
  const IntVector<3> stress_field_ghostcell_width = 
    stress_field_data->getGhostCellWidth();

  Box<3> tangent_vector_ghostbox = d_tangent_vector_data[0]->getGhostBox();
  const IntVector<3> tangent_vector_ghostbox_dims = 
     tangent_vector_ghostbox.numberCells();
  const IntVector<3> tangent_vector_ghostcell_width = 
    d_tangent_vector_data[0]->getGhostCellWidth();

  Box<3> level_set_fcn_ghostbox = phi_data->getGhostBox();
  IntVector<3> level_set_fcn_box_dims = level_set_fcn_ghostbox.numberCells();
  IntVector<3> level_set_fcn_ghostcell_width = phi_data->getGhostCellWidth();

  // get fill box
  Box<3> fillbox = force_data->getBox();
  const IntVector<3> fillbox_dims = fillbox.numberCells();

  // get data pointers
  double *force_x = force_data->getPointer(0);
  double *force_y = force_data->getPointer(1);
  double *force_z = force_data->getPointer(2);
  double *sigma11 = stress_field_data->getPointer(LSMDD::SIGMA_11);
  double *sigma22 = stress_field_data->getPointer(LSMDD::SIGMA_22);
  double *sigma33 = stress_field_data->getPointer(LSMDD::SIGMA_33);
  double *sigma23 = stress_field_data->getPointer(LSMDD::SIGMA_23);
  double *sigma31 = stress_field_data->getPointer(LSMDD::SIGMA_31);
  double *sigma12 = stress_field_data->getPointer(LSMDD::SIGMA_12);
  for (int line_num = 0; line_num < d_num_dislocation_lines; line_num++) {

    d_tangent_vector_x[line_num] = 
      d_tangent_vector_data[line_num]->getPointer(0);
    d_tangent_vector_y[line_num] = 
      d_tangent_vector_data[line_num]->getPointer(1);
    d_tangent_vector_z[line_num] = 
      d_tangent_vector_data[line_num]->getPointer(2);
  }
  
  // grid index trackers
  int idx_force = 0;
  int idx_stress_field = 0;
  int idx_tangent_vector = 0;
   
  // add ghostcell width in z-direction times number of cells in
  // xy-plane to get to starting plane of interior data
  idx_force          += force_ghostcell_width(2)
                      * force_ghostbox_dims(0)
                      * force_ghostbox_dims(1);
  idx_stress_field   += stress_field_ghostcell_width(2)
                      * stress_field_ghostbox_dims(0)
                      * stress_field_ghostbox_dims(1);
  idx_tangent_vector += tangent_vector_ghostcell_width(2)
                      * tangent_vector_ghostbox_dims(0)
                      * tangent_vector_ghostbox_dims(1);
    
  for (int k = 0; k < fillbox_dims(2); k++) {
    
    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of interior data
    idx_force          += force_ghostcell_width(1)
                        * force_ghostbox_dims(0);
    idx_stress_field   += stress_field_ghostcell_width(1)
                        * stress_field_ghostbox_dims(0);
    idx_tangent_vector += tangent_vector_ghostcell_width(1)
                        * tangent_vector_ghostbox_dims(0);

    for (int j = 0; j < fillbox_dims(1); j++) {

      // add ghostcell width in x-direction to get to start of
      // interior data
      idx_force          += force_ghostcell_width(0);
      idx_stress_field   += stress_field_ghostcell_width(0);
      idx_tangent_vector += tangent_vector_ghostcell_width(0);

      for (int i = 0; i < fillbox_dims(0); i++) {

        // compute position
        double X[3];
        X[0] = X_lower[0] + (i+0.5)*dX[0];
        X[1] = X_lower[1] + (j+0.5)*dX[1];
        X[2] = X_lower[2] + (k+0.5)*dX[2];

        // get tangent vector corresponding to line_handle
        double active_tangent_vector_x = 
          d_tangent_vector_x[line_handle][idx_tangent_vector];
        double active_tangent_vector_y = 
          d_tangent_vector_y[line_handle][idx_tangent_vector];
        double active_tangent_vector_z = 
          d_tangent_vector_z[line_handle][idx_tangent_vector];
      
        // get Burgers vector
        double b_x = d_burgers_vector[0];
        double b_y = d_burgers_vector[1];
        double b_z = d_burgers_vector[2];
      
        // compute PK-force 
        BasicDislocationPhysicsModule::computePKForce(
          force_x[idx_force], force_y[idx_force], force_z[idx_force],
          b_x, b_y, b_z,
          active_tangent_vector_x,
          active_tangent_vector_y,
          active_tangent_vector_z,
          sigma11[idx_stress_field],
          sigma22[idx_stress_field],
          sigma33[idx_stress_field],
          sigma23[idx_stress_field],
          sigma31[idx_stress_field],
          sigma12[idx_stress_field],
          X, d_debug_on);
 
        // update array indices
        idx_force++;
        idx_stress_field++;
        idx_tangent_vector++;
      }

      // add ghostcell width in x-direction to get to start of next
      // row of SAMRAI data
      idx_force          += force_ghostcell_width(0);
      idx_stress_field   += stress_field_ghostcell_width(0);
      idx_tangent_vector += tangent_vector_ghostcell_width(0);

    }

    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of SAMRAI data
    idx_force          += force_ghostcell_width(1)
                        * force_ghostbox_dims(0);
    idx_stress_field   += stress_field_ghostcell_width(1)
                        * stress_field_ghostbox_dims(0);
    idx_tangent_vector += tangent_vector_ghostcell_width(1)
                        * tangent_vector_ghostbox_dims(0);

  } // end loop over grid
}


/*
 * NOTES:
 *  - all of the tangent vectors referred to in this method are
 *    normalized to unit length. 
 */
void DislocationLoopModule::computeVelocityForDislocationLineOnPatch(
  Patch<3>& patch,
  const int velocity_handle,
  const int force_handle,
  const vector<int>& tangent_vector_handles,
  const int distance_handle,
  const int phi_handle,
  const int psi_handle,
  const int line_handle,
  const double time,
  const LSMDD_Parameters& lsmdd_params)
{

  // argument check
  if ( (line_handle < 0) || (line_handle > d_num_dislocation_lines) ) {
     TBOX_ERROR(  "DislocationLoopModule::"
                  << "computeVelocityForDislocationLineOnPatch(): "
                  << "line_handle out of bounds"
                  << endl);
  }


  /*
   * Get grid information.
   */

  // get geometry
  Pointer< CartesianPatchGeometry<3> > patch_geom 
    = patch.getPatchGeometry();
  const double* dX = patch_geom->getDx();
  const double* X_lower = patch_geom->getXLower();

  // get PatchData
  Pointer< CellData<3,double> > velocity_data =
    patch.getPatchData( velocity_handle );
  Pointer< CellData<3,double> > force_data =
    patch.getPatchData( force_handle );
  Pointer< CellData<3,double> > phi_data =
    patch.getPatchData( phi_handle );
  Pointer< CellData<3,double> > psi_data =
    patch.getPatchData( psi_handle );
  Pointer< CellData<3,double> > tangent_vector_data =
    patch.getPatchData( tangent_vector_handles[line_handle] );
  Pointer< CellData<3,double> > distance_data =
    patch.getPatchData( distance_handle );

  // get index space information
  Box<3> velocity_ghostbox = velocity_data->getGhostBox();
  const IntVector<3> velocity_ghostbox_dims = 
    velocity_ghostbox.numberCells();
  const IntVector<3> velocity_ghostcell_width = 
    velocity_data->getGhostCellWidth();

  Box<3> force_ghostbox = force_data->getGhostBox();
  const IntVector<3> force_ghostbox_dims = 
    force_ghostbox.numberCells();
  const IntVector<3> force_ghostcell_width = 
    force_data->getGhostCellWidth();

  Box<3> phi_ghostbox = phi_data->getGhostBox();
  const IntVector<3> phi_ghostbox_dims = 
    phi_ghostbox.numberCells();
  const IntVector<3> phi_ghostcell_width = 
    phi_data->getGhostCellWidth();
  Box<3> psi_ghostbox = psi_data->getGhostBox();
  const IntVector<3> psi_ghostbox_dims = 
    psi_ghostbox.numberCells();
  const IntVector<3> psi_ghostcell_width = 
    psi_data->getGhostCellWidth();

  Box<3> tangent_vector_ghostbox = tangent_vector_data->getGhostBox();
  const IntVector<3> tangent_vector_ghostbox_dims = 
     tangent_vector_ghostbox.numberCells();
  const IntVector<3> tangent_vector_ghostcell_width = 
    tangent_vector_data->getGhostCellWidth();

  Box<3> distance_ghostbox = distance_data->getGhostBox();
  const IntVector<3> distance_ghostbox_dims = 
     distance_ghostbox.numberCells();
  const IntVector<3> distance_ghostcell_width = 
    distance_data->getGhostCellWidth();

  // get data pointers
  double *velocity_x = velocity_data->getPointer(0);
  double *velocity_y = velocity_data->getPointer(1);
  double *velocity_z = velocity_data->getPointer(2);
  double *force_x = force_data->getPointer(0);
  double *force_y = force_data->getPointer(1);
  double *force_z = force_data->getPointer(2);
  double *phi = phi_data->getPointer();
  double *psi = psi_data->getPointer();
  double *tangent_vector_x = tangent_vector_data->getPointer(0);
  double *tangent_vector_y = tangent_vector_data->getPointer(1);
  double *tangent_vector_z = tangent_vector_data->getPointer(2);
  double *distance = distance_data->getPointer();


  // compute fillbox over which to compute velocity
  // NOTE:  to ensure that we reach the boundaries of the physical 
  // domain, the loops over the grid includes fillbox plus one       
  // ghostcell at the lower end of the index space in each 
  // coordinate direction (i.e. loops run from -1 to (num_cells-1)
  // instead of from 0 to (num_cells-1) )

  Box<3> fillbox = velocity_data->getBox();
  const IntVector<3> fillbox_dims = fillbox.numberCells();


  // get glide and climb mobilities
  double glide_mobility = lsmdd_params.getGlideMobility();
  double climb_mobility = lsmdd_params.getClimbMobility();

  // get Burgers vector
  double b_x = d_burgers_vector[0];
  double b_y = d_burgers_vector[1];
  double b_z = d_burgers_vector[2];

  // get numerical parameters
  double min_segment_length = 
    lsmdd_params.getMinDislocationSegmentLength();
  double max_angle_for_pure_screw = 
    lsmdd_params.getMaxAngleForPureScrew();

  /*
   * Loop over grid and compute velocity for all grid cells.
   */

  // grid index trackers
  int idx_velocity = 0;
  int idx_force = 0;
  int idx_phi = 0;
  int idx_psi = 0;
  int idx_tangent_vector = 0;
  int idx_distance = 0;
   
  // add ghostcell width in z-direction times number of cells in
  // xy-plane to get to layer of cell just below the starting plane 
  // of interior data
  idx_velocity       += (velocity_ghostcell_width(2) - 1)
                      * velocity_ghostbox_dims(0)
                      * velocity_ghostbox_dims(1);
  idx_force          += (force_ghostcell_width(2) - 1)
                      * force_ghostbox_dims(0)
                      * force_ghostbox_dims(1);
  idx_phi            += (phi_ghostcell_width(2) - 1)
                      * phi_ghostbox_dims(0)
                      * phi_ghostbox_dims(1);
  idx_psi            += (psi_ghostcell_width(2) - 1)
                      * psi_ghostbox_dims(0)
                      * psi_ghostbox_dims(1);
  idx_tangent_vector += (tangent_vector_ghostcell_width(2) - 1)
                      * tangent_vector_ghostbox_dims(0)
                      * tangent_vector_ghostbox_dims(1);
  idx_distance       += (distance_ghostcell_width(2) - 1)
                      * distance_ghostbox_dims(0)
                      * distance_ghostbox_dims(1);

  
  for (int k = -1; k < fillbox_dims(2); k++) {
    
    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of interior data
    idx_velocity       += (velocity_ghostcell_width(1) - 1)
                        * velocity_ghostbox_dims(0);
    idx_force          += (force_ghostcell_width(1) - 1)
                        * force_ghostbox_dims(0);
    idx_phi            += (phi_ghostcell_width(1) - 1)
                        * phi_ghostbox_dims(0);
    idx_psi            += (psi_ghostcell_width(1) - 1)
                        * psi_ghostbox_dims(0);
    idx_tangent_vector += (tangent_vector_ghostcell_width(1) - 1)
                        * tangent_vector_ghostbox_dims(0);
    idx_distance       += (distance_ghostcell_width(1) - 1)
                        * distance_ghostbox_dims(0);

    for (int j = -1; j < fillbox_dims(1); j++) {

      // add ghostcell width in x-direction to get to start of
      // interior data
      idx_velocity       += velocity_ghostcell_width(0) - 1;
      idx_force          += force_ghostcell_width(0) - 1;
      idx_phi            += phi_ghostcell_width(0) - 1;
      idx_psi            += psi_ghostcell_width(0) - 1;
      idx_tangent_vector += tangent_vector_ghostcell_width(0) - 1;
      idx_distance       += distance_ghostcell_width(0) - 1;

      for (int i = -1; i < fillbox_dims(0); i++) {

        // compute coordinates of cell center
        double X[3];
        X[0] = X_lower[0] + (i + 0.5)*dX[0];
        X[1] = X_lower[1] + (j + 0.5)*dX[1];
        X[2] = X_lower[2] + (k + 0.5)*dX[2];

        /*
         * loop over six tetrahedra in the cell with corners given
         * by the centers of the cells in the index space
         * [(i,j,k),(i+1,j+1,k+1)]
         */

        for (int tet_num = 0; tet_num < 6; tet_num++) {

          double x1[3], x2[3], x3[3], x4[3];
          double endpt1[3], endpt2[3];
          double phi_tet[4], psi_tet[4];

          GET_TETRAHEDRON(x1, x2, x3, x4, phi_tet, psi_tet,
                          tet_num, i, j, k,
                          X, dX, phi, psi, idx_phi, idx_psi,
                          phi_ghostbox_dims, psi_ghostbox_dims);

          int num_intersections = LSM3D_findLineInTetrahedron(endpt1,
                                                              endpt2,
                                                              x1,
                                                              x2,
                                                              x3,
                                                              x4,
                                                              phi_tet,
                                                              psi_tet);

           /*
            * if the dislocation line intersects the tetrahedron,
            * compute velocity 
            */
           if (num_intersections > 0) {  

             /*
              * interpolate force and tangent vector to endpoints of 
              * dislocation line using trilinear interpolation
              */
             double force_x_endpt1, force_y_endpt1, force_z_endpt1;
             double force_x_endpt2, force_y_endpt2, force_z_endpt2;
             INTERPOLATE_FORCE(force_x_endpt1, force_y_endpt1, force_z_endpt1,
                               endpt1,
                               force_x, force_y, force_z,
                               X, dX,
                               idx_force, force_ghostbox_dims);
             INTERPOLATE_FORCE(force_x_endpt2, force_y_endpt2, force_z_endpt2,
                               endpt2,
                               force_x, force_y, force_z,
                               X, dX,
                               idx_force, force_ghostbox_dims);


             /*
              * update neighboring grid points from the set
              * [(i,j,k),(i+1,j+1,k+1)] if the current
              * dislocation line segment is closer than any 
              * previously examined dislocation line segment
              *
              * NOTE: in the following code, p will refer to 
              *       the center of the neighboring grid cell
              */
             double distance_to_dislocation_segment;
             double force_x_closest, force_y_closest, force_z_closest;
             double tangent_vector_x_neighbor; 
             double tangent_vector_y_neighbor;
             double tangent_vector_z_neighbor;

             double dislocation_segment_length;
             double dislocation_tangent_x = endpt2[0]-endpt1[0];
             double dislocation_tangent_y = endpt2[1]-endpt1[1];
             double dislocation_tangent_z = endpt2[2]-endpt1[2];
             dislocation_segment_length = 
               sqrt( dislocation_tangent_x*dislocation_tangent_x
                   + dislocation_tangent_y*dislocation_tangent_y
                   + dislocation_tangent_z*dislocation_tangent_z );

             for (int n_k = 0; n_k < 2; n_k++) {

               // skip update if grid index of neighbor
               // is outside of Patch interior
               if ( (k+n_k < 0) || (k+n_k >= fillbox_dims(2)) ) continue; 

               for (int n_j = 0; n_j < 2; n_j++) {

                 // skip update if grid index of neighbor
                 // is outside of Patch interior
                 if ( (j+n_j < 0) || (j+n_j >= fillbox_dims(1)) ) continue; 

                 for (int n_i = 0; n_i < 2; n_i++) {

                   // skip update if grid index of neighbor
                   // is outside of Patch interior
                   if ( (i+n_i < 0) || (i+n_i >= fillbox_dims(0)) ) continue; 

                   bool update_current_cell = false;
                   int idx_neighbor_distance = 
                     idx_distance + n_i + n_j*distance_ghostbox_dims(0) +
                     n_k*distance_ghostbox_dims(0)*distance_ghostbox_dims(1);
                   double X_neighbor[3];
                   X_neighbor[0] = (X[0] + n_i*dX[0]); 
                   X_neighbor[1] = (X[1] + n_j*dX[1]); 
                   X_neighbor[2] = (X[2] + n_k*dX[2]); 

                   CHECK_IF_CELL_NEEDS_VELOCITY_UPDATE(
                     update_cell, 
                     force_x_closest, force_y_closest, force_z_closest,
                     dislocation_tangent_x, 
                     dislocation_tangent_y, 
                     dislocation_tangent_z,
                     dislocation_segment_length, min_segment_length,
                     X_neighbor, dX, endpt1, endpt2,
                     force_x_endpt1, force_y_endpt1, force_z_endpt1,
                     force_x_endpt2, force_y_endpt2, force_z_endpt2,
                     distance, idx_neighbor_distance);

                   // update current neighbor grid cell if required 
                   // (i.e. if the distance to current dislocation line 
                   // segment is smaller than all previous closest 
                   // dislocation line segments
                   if (update_current_cell) {

                     int idx_neighbor_tangent_vector = 
                       idx_tangent_vector + n_i + 
                       n_j*tangent_vector_ghostbox_dims(0) +
                       n_k*tangent_vector_ghostbox_dims(0)
                          *tangent_vector_ghostbox_dims(1);
                     tangent_vector_x_neighbor = 
                       tangent_vector_x[idx_neighbor_tangent_vector];
                     tangent_vector_y_neighbor = 
                       tangent_vector_y[idx_neighbor_tangent_vector];
                     tangent_vector_z_neighbor = 
                       tangent_vector_z[idx_neighbor_tangent_vector];

                     int idx_velocity_neighbor = 
                       idx_velocity + n_i + n_j*velocity_ghostbox_dims(0) +
                       n_k*velocity_ghostbox_dims(0)*velocity_ghostbox_dims(1);

                     BasicDislocationPhysicsModule::
                       computeVelocityUsingBasicFormula(
                         velocity_x[idx_velocity_neighbor],
                         velocity_y[idx_velocity_neighbor],
                         velocity_z[idx_velocity_neighbor],
                         force_x_closest,
                         force_y_closest,
                         force_z_closest,
                         b_x, b_y, b_z,
                         tangent_vector_x_neighbor,
                         tangent_vector_y_neighbor,
                         tangent_vector_z_neighbor,
                         glide_mobility,
                         climb_mobility,
                         max_angle_for_pure_screw,
                         X_neighbor, d_debug_on);
 
                   } // end update of current cell

                 }
               }
             } // end loop over neighboring grid cells

          } // end case: dislocation line intersects tetrahedron

        } // end loop over tetrahedra

        // update array indices
        idx_velocity++;
        idx_force++;
        idx_phi++;
        idx_psi++;
        idx_tangent_vector++;
        idx_distance++;
      }

      // add ghostcell width in x-direction to get to start of next
      // row of SAMRAI data
      idx_velocity       += velocity_ghostcell_width(0);
      idx_force          += force_ghostcell_width(0);
      idx_phi            += phi_ghostcell_width(0);
      idx_psi            += psi_ghostcell_width(0);
      idx_tangent_vector += tangent_vector_ghostcell_width(0);
      idx_distance       += distance_ghostcell_width(0);

    }

    // add ghostcell width in y-direction times number of cells in
    // x-direction to get to start of next plane of SAMRAI data
    idx_velocity       += velocity_ghostcell_width(1)
                        * velocity_ghostbox_dims(0);
    idx_force          += force_ghostcell_width(1)
                        * force_ghostbox_dims(0);
    idx_phi            += phi_ghostcell_width(1)
                        * phi_ghostbox_dims(0);
    idx_psi            += psi_ghostcell_width(1)
                        * psi_ghostbox_dims(0);
    idx_tangent_vector += tangent_vector_ghostcell_width(1)
                        * tangent_vector_ghostbox_dims(0);
    idx_distance       += distance_ghostcell_width(1)
                        * distance_ghostbox_dims(0);

  } // end loop over grid

}


void DislocationLoopModule::getFromInput(
  Pointer<Database> db)
{
#ifdef DEBUG_CHECK_ASSERTIONS
  assert(!db.isNull());
#endif

  // get maximum time step size
  d_max_dt = db->getDoubleWithDefault("max_dt",DEFAULT_MAX_DT);

  // get center and radius of dislocation loop
  db->getDoubleArray("center", d_center, 3);
  d_radius = db->getDouble("radius");

  // get Burgers vector
  double burgers_vector[3];
  db->getDoubleArray("burgers_vector", burgers_vector, 3);
  for (int i = 0; i < 3; i++) {
    d_burgers_vector[i] = burgers_vector[i];
  }

  // initialize boundary conditions
  d_lower_bc_phi.resizeArray(d_num_dislocation_lines);
  d_upper_bc_phi.resizeArray(d_num_dislocation_lines);
  d_lower_bc_psi.resizeArray(d_num_dislocation_lines);
  d_upper_bc_psi.resizeArray(d_num_dislocation_lines);

  // read in boundary conditions
  for (int line_num=0; line_num < d_num_dislocation_lines; line_num++) {
    stringstream lower_bc_phi_key;
    lower_bc_phi_key << "lower_bc_phi_";
    lower_bc_phi_key << (line_num+1);

    int lower_bc[3];
    if (db->keyExists(lower_bc_phi_key.str())) {
      db->getIntegerArray(
        lower_bc_phi_key.str(), lower_bc, 3);
      for (int i = 0; i < 3; i++) {
        d_lower_bc_phi[line_num](i) = lower_bc[i];
      }
    }

    stringstream upper_bc_phi_key;
    upper_bc_phi_key << "upper_bc_phi_";
    upper_bc_phi_key << (line_num+1);

    int upper_bc[3];
    if (db->keyExists(upper_bc_phi_key.str())) {
      db->getIntegerArray(
        upper_bc_phi_key.str(), upper_bc, 3);
      for (int i = 0; i < 3; i++) {
        d_upper_bc_phi[line_num](i) = upper_bc[i];
      }
    }

    stringstream lower_bc_psi_key;
    lower_bc_psi_key << "lower_bc_psi_";
    lower_bc_psi_key << (line_num+1);

    if (db->keyExists(lower_bc_psi_key.str())) {
      db->getIntegerArray(
        lower_bc_psi_key.str(), lower_bc, 3);
      for (int i = 0; i < 3; i++) {
        d_lower_bc_psi[line_num](i) = lower_bc[i];
      }
    }

    stringstream upper_bc_psi_key;
    upper_bc_psi_key << "upper_bc_psi_";
    upper_bc_psi_key << (line_num+1);

    if (db->keyExists(upper_bc_psi_key.str())) {
      db->getIntegerArray(
        upper_bc_psi_key.str(), upper_bc, 3);
      for (int i = 0; i < 3; i++) {
        d_upper_bc_psi[line_num](i) = upper_bc[i];
      }
    }
  }


  // get external stress field parameters
  d_external_sigma_11 = db->getDoubleWithDefault("sigma_11", 0.0);
  d_external_sigma_22 = db->getDoubleWithDefault("sigma_22", 0.0);
  d_external_sigma_33 = db->getDoubleWithDefault("sigma_33", 0.0);
  d_external_sigma_23 = db->getDoubleWithDefault("sigma_23", 0.0);
  d_external_sigma_31 = db->getDoubleWithDefault("sigma_31", 0.0);
  d_external_sigma_12 = db->getDoubleWithDefault("sigma_12", 0.0);

  // get debug flag
  d_debug_on = db->getBoolWithDefault("debug_on", false);

}
