/*
 * File:        DislocationDynamicsSimulation.cc
 * Copyright:   (c) 2005-2007 Princeton University
 * Author(s):   Kevin T. Chu
 * Revision:    $Revision: 376 $
 * Modified:    $Date: 2007-08-06 19:10:55 -0400 (Mon, 06 Aug 2007) $
 * Description: main program for two dislocation line test problem
 */

/************************************************************************
 *
 * This program tests the DislocationDynamicsModule.  Initialization of
 * the two crossing dislocation lines is provided through the 
 * TwoDislocationLinesModule class which wraps a simple fortran routine.
 *
 ************************************************************************/


// System Headers
#include <sstream>

// SAMRAI Headers
#include "SAMRAI_config.h"
#include "IntVector.h"

// variables and variable management
#include "CellVariable.h"
#include "FaceVariable.h"
#include "VariableDatabase.h"

// geometry and patch hierarchy
#include "CartesianGridGeometry.h" 
#include "PatchHierarchy.h"

// basic SAMRAI classes
#include "tbox/Database.h" 
#include "tbox/InputDatabase.h" 
#include "tbox/InputManager.h" 
#include "tbox/MPI.h"
#include "tbox/PIO.h"
#include "tbox/Pointer.h"
#include "tbox/RestartManager.h"
#include "tbox/SAMRAIManager.h"
#include "tbox/Utilities.h"
#include "VisItDataWriter.h"

// dislocation dynamics classes
#include "LSMDD_config.h" 
#include "DislocationDynamicsModule.h" 
#include "PeriodicDislocationArrayElasticStressModule.h" 
#include "TwoDislocationLinesModule.h" 


// namespaces
using namespace std;
using namespace SAMRAI;
using namespace appu;
using namespace geom;
using namespace hier;
using namespace tbox;


// CONSTANTS
#define DIM   (3)

int main(int argc, char *argv[])
{

  /*
   * Initialize MPI and SAMRAI, enable logging, and process command line.
   */
  tbox::MPI::init(&argc, &argv);
  tbox::MPI::initialize();
  SAMRAIManager::startup();

 
  string input_filename;
  string restart_read_dirname;
  int restore_num = 0;

  bool is_from_restart = false;

  if ( (argc != 2) && (argc != 4) ) {
    pout << "USAGE:  " << argv[0] << " <input filename> "
         << "\n"
         << "<restart dir> <restore number> [options]\n"
         << "  options:\n"
         << "  none at this time"
         << endl;
    tbox::MPI::abort();
    return (-1);
  } else {
    input_filename = argv[1];
    if (argc == 4) {
      restart_read_dirname = argv[2];
      restore_num = atoi(argv[3]);
      is_from_restart = true;
    }
  }


  /*
   * Create input database and parse all data in input file.
   */
  Pointer<Database> input_db = new InputDatabase("input_db");
  InputManager::getManager()->parseInputFile(input_filename, input_db);

  /*
   * Read in the input from the "Main" section of the input database.  
   */
  Pointer<Database> main_db = input_db->getDatabase("Main");

  /* 
   * The base_name variable is a base name for all name strings in 
   * this program.
   */
   string base_name = "unnamed";
   base_name = main_db->getStringWithDefault("base_name", base_name);

  /*
   * Start logging.
   */
   const string log_file_name = base_name + ".log";
   bool log_all_nodes = false;
   log_all_nodes = main_db->getBoolWithDefault("log_all_nodes", log_all_nodes);
   if (log_all_nodes) {
      PIO::logAllNodes(log_file_name);
   } else {
      PIO::logOnlyNodeZero(log_file_name);
   }

  int restart_interval = 0;
  if (main_db->keyExists("restart_interval")) {
    restart_interval = main_db->getInteger("restart_interval");
  } 
  string restart_write_dirname = base_name + ".restart";
  const bool write_restart = (restart_interval > 0); 
  
  /*
   * Get the restart manager and root restart database.  If run is from
   * restart, open the restart file.
   */

  RestartManager* restart_manager = RestartManager::getManager();
  if (is_from_restart) {
    restart_manager->
       openRestartFile(restart_read_dirname, restore_num,
                       tbox::MPI::getNodes() );
  }

  // log the command-line args
  plog << "input_filename = " << input_filename << endl;

  /*
   * Create PatchHierarchy and CartesianGridGeometry 
   */
  Pointer< CartesianGridGeometry<3> > grid_geometry =
    new CartesianGridGeometry<3>(
      base_name+"::CartesianGeometry",
      input_db->getDatabase("CartesianGeometry"));
  plog << "CartesianGridGeometry:" << endl;
  grid_geometry->printClassData(plog);

  Pointer< PatchHierarchy<3> > patch_hierarchy =
    new PatchHierarchy<3>(base_name+"::PatchHierarchy",
                             grid_geometry);

  /*
   * Create and set up TwoDislocationLinesModule
   */
  TwoDislocationLinesModule *patch_module = 
    new TwoDislocationLinesModule(
      input_db->getDatabase("TwoDislocationLinesModule"),
      grid_geometry);

  /*
   * Create DislocationDynamicsModule
   */
  PeriodicDislocationArrayElasticStressModule *elastic_stress_module = 
   new PeriodicDislocationArrayElasticStressModule(
     input_db->getDatabase("ElasticStressModule"), patch_hierarchy);
  elastic_stress_module->printClassData(plog);

  /*
   * Create DislocationDynamicsModule
   */
  DislocationDynamicsModule *lsmdd_module = 
    new DislocationDynamicsModule(
      input_db->getDatabase("DislocationDynamicsModule"),
      patch_hierarchy,
      elastic_stress_module,
      patch_module);
  lsmdd_module->printClassData(plog);

  /*
   * Set up VisIt data writer
   */
  bool use_visit = false;
  bool output_dislocation_line_data = false;
  int viz_write_interval = -1;
  int visit_number_procs_per_file = 1;
  if (main_db->keyExists("use_visit")) {
    use_visit = main_db->getBool("use_visit");
  }
  if (use_visit) {
    if (main_db->keyExists("visit_number_procs_per_file")) {
      visit_number_procs_per_file =
        main_db->getInteger("visit_number_procs_per_file");
    } 
  }
  string dislocation_data_basename(""); 
  if (main_db->keyExists("dislocation_data_basename")) {
    dislocation_data_basename = 
      main_db->getString("dislocation_data_basename");
  }
  output_dislocation_line_data = !dislocation_data_basename.empty();
  if (use_visit || output_dislocation_line_data) {
    if (main_db->keyExists("viz_write_interval")) {
      viz_write_interval =
        main_db->getInteger("viz_write_interval");
    }
  }

  /*
   * Initialize dislocation dynamics simulation
   */

  // initialize dislocation level set functions
  lsmdd_module->initializeDislocationLevelSetFunctions();


  /*
   * Close restart file before starting main time-stepping loop.
   */
  restart_manager->closeRestartFile();


  // get PatchData handles
  int phi_handle = lsmdd_module->getPhiPatchDataHandle();
  int psi_handle = lsmdd_module->getPsiPatchDataHandle();
  int stress_field_handle = elastic_stress_module->getStressFieldHandle();

  // set up VisIt data writer
  Pointer<VisItDataWriter<DIM> > visit_data_writer = 0;
  if ( use_visit ) {
    string visit_data_dirname = base_name + ".visit";
    visit_data_writer = new VisItDataWriter<DIM>("TestLSM 3D VisIt Writer",
                                                  visit_data_dirname,
                                                  visit_number_procs_per_file);

    for (int k = 0; k < patch_module->numberOfDislocationLines(); k++) {

      // register phi and psi for plotting
      stringstream phi_name;
      phi_name << "phi" << k;
      stringstream psi_name;
      psi_name << "psi" << k;
      visit_data_writer->registerPlotQuantity(
        phi_name.str(), "SCALAR",
        phi_handle, k, 1.0, "CELL");
      visit_data_writer->registerPlotQuantity(
        psi_name.str(), "SCALAR",
        psi_handle, k, 1.0, "CELL");
    }

    // register velocity data for plotting
    if (input_db->getDatabase("DislocationDynamicsModule")
                ->getBoolWithDefault("use_persistent_velocity_data", false)) {

      int velocity_handle = lsmdd_module->getVelocityPatchDataHandle();
      visit_data_writer->registerPlotQuantity(
        "vel_x", "SCALAR",
        velocity_handle, 0, 1.0, "CELL");
      visit_data_writer->registerPlotQuantity(
        "vel_y", "SCALAR",
        velocity_handle, 1, 1.0, "CELL");
        visit_data_writer->registerPlotQuantity(
        "vel_z", "SCALAR",
        velocity_handle, 2, 1.0, "CELL");
    }

    // register stress field for plotting
    visit_data_writer->registerPlotQuantity(
      "sigma_11", "SCALAR",
      stress_field_handle, 0, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_22", "SCALAR",
      stress_field_handle, 1, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_33", "SCALAR",
      stress_field_handle, 2, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_12", "SCALAR",
      stress_field_handle, 3, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_23", "SCALAR",
      stress_field_handle, 4, 1.0, "CELL");
    visit_data_writer->registerPlotQuantity(
      "sigma_13", "SCALAR",
      stress_field_handle, 5, 1.0, "CELL");

  }  

  /*************************************
   * Main time loop
   *************************************/
  int count = 0;
  int max_num_time_steps = main_db->getIntegerWithDefault("max_iterations",10);
  double current_time = lsmdd_module->getCurrentTime();
  int cur_integrator_step = lsmdd_module->numSimulationStepsTaken();

  /*
   * Output initial conditions (if this run is not from restart).
   */
  if ( write_restart && (!is_from_restart) ) {
    restart_manager->writeRestartFile(restart_write_dirname,
                                      cur_integrator_step);
  }

  // write out visualization data if this is the first time step
  if (!is_from_restart) {

    // write out dislocation lines
    if ( output_dislocation_line_data ) {
      char filename_buf[128];
      sprintf(filename_buf,"%s_%05d",
        dislocation_data_basename.c_str(), cur_integrator_step);
      string filename(filename_buf);
      lsmdd_module->writeAllDislocationLinesToFile(filename);
    }

    // write out stress field to VisIt data format
    if ( use_visit ) {
      visit_data_writer->writePlotData(patch_hierarchy, cur_integrator_step,
                                       current_time);
    }
  }

  while ( !lsmdd_module->endTimeReached() && 
          ((max_num_time_steps <= 0) || (count < max_num_time_steps)) ) {

    // output status 
    pout << "=============================" << endl;
    pout << "  Time step (in current run): " << count << endl;
    pout << "  Integrator time step: " << cur_integrator_step << endl;
    pout << "  Current time:  " << lsmdd_module->getCurrentTime() << endl;

    // compute stable dt for next step
    double dt = lsmdd_module->computeNextDt();
    double end_time = lsmdd_module->getEndTime();
    current_time = lsmdd_module->getCurrentTime();
    if (end_time - current_time < dt) dt = end_time - current_time;
    pout << "  dt:  " << dt << endl;

    // advance dislocations
    lsmdd_module->advanceDislocations(dt);

    // finish status output for current time step
    pout << "=============================" << endl << endl;


    /*
     * output data for current time step if this is the
     * initial time step or if the next write interval has
     * been reached
     */
    cur_integrator_step = lsmdd_module->numSimulationStepsTaken();

    // write restart file
    if ( write_restart && (0==cur_integrator_step%restart_interval) ) {
      restart_manager->writeRestartFile(restart_write_dirname,
                                        cur_integrator_step);
    }

    if ( cur_integrator_step % viz_write_interval == 0 ) {

      // write out dislocation lines
      if ( output_dislocation_line_data ) {
        char filename_buf[128];
        sprintf(filename_buf,"%s_%05d",
          dislocation_data_basename.c_str(), cur_integrator_step);
        string filename(filename_buf);
        lsmdd_module->writeAllDislocationLinesToFile(filename);
      }
  
      // write out stress field to VisIt data format
      if ( use_visit ) {
        visit_data_writer->writePlotData(patch_hierarchy, cur_integrator_step,
                                         lsmdd_module->getCurrentTime());
      }
    } // end visualization output 

    // update count
    count++;
  }

  /*
   * output final solution 
   */
  pout << "=============================" << endl;
  pout << "  Final time step (in current run): " << count << endl;
  pout << "  Final integrator time step: " << cur_integrator_step << endl;
  pout << "  Current time:  " << lsmdd_module->getCurrentTime() << endl;

  // write restart file for final time step
  if ( write_restart && (0!=cur_integrator_step%restart_interval) ) {
    restart_manager->writeRestartFile(restart_write_dirname,
                                      cur_integrator_step);
  }

  if (0!=cur_integrator_step%viz_write_interval) {

    // write out dislocation lines
    if ( output_dislocation_line_data ) {
      char filename_buf[128];
      sprintf(filename_buf,"%s_%05d",
        dislocation_data_basename.c_str(), cur_integrator_step);
      string filename(filename_buf);
      lsmdd_module->writeAllDislocationLinesToFile(filename);
    }
  
    // write out stress field to VisIt data format
    if ( use_visit ) {
      visit_data_writer->writePlotData(patch_hierarchy, cur_integrator_step, 
                                       lsmdd_module->getCurrentTime());
    }
  }
  
  // write out an extra line for aesthetic purposes
  pout << "=============================" << endl;

  /*
   * At conclusion of simulation, deallocate objects.
   */
  delete lsmdd_module;
  delete patch_module;
  delete elastic_stress_module;

  SAMRAIManager::shutdown();
  tbox::MPI::finalize();

  return(0);
}
